#!/usr/bin/env node
/* Static/data smoke checks. This does not substitute for manual browser gameplay. */
const fs = require('fs');
const path = require('path');
const vm = require('vm');
const { spawnSync } = require('child_process');
const root = path.resolve(__dirname, '..');
const fail = [];
const pass = (label) => console.log(`PASS ${label}`);
const check = (ok, label) => ok ? pass(label) : fail.push(label);

const html = fs.readFileSync(path.join(root, 'index.html'), 'utf8');
const engine = fs.readFileSync(path.join(root, 'js/engine.js'), 'utf8');
const css = fs.readFileSync(path.join(root, 'css/main.css'), 'utf8');
const scriptPaths = [...html.matchAll(/<script\s+src="([^"]+)"/g)].map(m => m[1]);
for (const src of scriptPaths) check(fs.existsSync(path.join(root, src)), `script path exists: ${src}`);
check(!html.includes('data/pages/starter.js'), 'obsolete starter.js is not loaded');
check(scriptPaths.includes('js/easter-eggs/easter-eggs.js'), 'separate Easter egg module is loaded before engine');
check(scriptPaths.includes('js/data/canon.js') && scriptPaths.indexOf('js/data/canon.js') < scriptPaths.indexOf('js/engine.js'), 'canonical story outcome module loads before the engine');
check(engine.includes('window.CityCanon?.migrate?.(S.flags)') && engine.includes('window.CityCanon?.commitMission?.(S.flags,missionId,selectedOutcome)'), 'canonical fates persist and migrate with save data');
check(engine.includes('window.cityCharacterFate = characterId => window.CityCanon?.fateFor?.(S?.flags, characterId)'), 'future story scripts can query saved fate without altering replay state');
check(scriptPaths.includes('data/abnormalities/fairy-festival.js') && scriptPaths.includes('data/pages/equipment.js'), 'Abnormality and body-equipment data load before the engine');
check(engine.includes("reputationHistory[missionId]=delta") && engine.includes("!S.flags.reputationApplied[missionId]"), 'reputation changes are recorded once on first canonical office completion');
check(engine.includes("['yunOffice','brotherhood','hookOffice'].every(id=>(S.flags.completedMissions||[]).includes(id))") && engine.includes("'🜂 Enter Urban Myth · Hana Association examination'"), 'Urban Myth doorway unlocks from the apartment after all three office storylines');
check(engine.includes("['pages','Combat Pages'],['keys','Key Pages']") && engine.includes("['body','Body Gear'],['status','Status']"), 'inventory adds separate Body Gear and Status tabs');
check(engine.includes("id==='kcorp_ampule'"), 'K Corp Ampule is supported as a full-HP consumable');
check(engine.includes("function startUrbanMythPrologue()") && engine.includes("buildHanaExamination") && fs.readFileSync(path.join(root,'data/dialogues/Urban-Myth/hana-examination.js'),'utf8').includes("{ k: 'hanaReveal' }") && fs.readFileSync(path.join(root,'data/dialogues/Urban-Myth/hana-examination.js'),'utf8').includes("encounter: 'fairyFestival'"), 'Urban Myth progresses from the black-screen report to the Hana examination');
check(engine.includes("urbanMythExamCleared=true") && engine.includes("missionId==='urbanMythExam'"), 'Fairy Festival exam completion is tracked separately from Canard rewards');
check(css.includes('.bg-hana') && css.includes('.urban-myth-test #vnActors .vn[data-id="zevelyn"]') && css.includes('.urban-myth-test #vnActors .vn[data-id="han-ul"].talk'), 'Hana background and left/right examiner dialogue staging are styled');
check(css.includes('#battle.urban-myth-exam #bActors') && css.includes('.bodyModel.shape-male') && css.includes('.bodyModel.shape-female'), 'Fairy Festival is centered in the exam battle and body silhouettes are available');
check(engine.includes('const post=mission?.post||mission?.postReplay') && engine.includes('const post=window.POST_RATS||window.POST_RATS_REPLAY'), 'replays reuse in-world story aftermaths without meta replay narration');
check(engine.includes('script=[...m.start]') && engine.includes('Completed receptions replay their original in-world dialogue and choices'), 'replayed receptions retain their original story dialogue and branching choices');
check(engine.includes('No pending encounter wave to resume') && engine.includes('B.pendingWaveIndex=1'), 'Brotherhood Arnold wave transition recovers from interrupted legacy saves');
check(fs.readFileSync(path.join(root,'js/data/canon.js'),'utf8').includes('canonicalRefreshPending') && fs.readFileSync(path.join(root,'js/data/canon.js'),'utf8').includes('storyReworkVersion = 2'), 'existing saves are prompted to replay each previously completed office once for story-data registration');
const yunStory=fs.readFileSync(path.join(root,'data/dialogues/Canard/Yun-Office/missions.js'),'utf8');
const yunRoutes=fs.readFileSync(path.join(root,'data/dialogues/Canard/Yun-Office/routes.js'),'utf8');
check(yunStory.includes("C('How do you resolve the ledger dispute?'") && yunStory.includes("route:'yun_fight'") && yunStory.includes("route:'yun_help'"), 'Yun reception gives reachable fight and help choices');
check(yunRoutes.includes("id:'yunOffice',outcome:'helped'") && fs.readFileSync(path.join(root,'data/dialogues/Canard/Brotherhood-of-Iron/missions.js'),'utf8').includes("route:'iron_help'") && fs.readFileSync(path.join(root,'data/dialogues/Canard/Hook-Office/missions.js'),'utf8').includes("route:'hook_help'"), 'all three office receptions expose nonlethal helping routes');

check(engine.includes('window.CityEasterEggs?.messageFor?.(name)') && engine.includes('api?.buffFor'), 'engine delegates Easter egg data to separate module');
check(!fs.existsSync(path.join(root, 'data/pages/starter.js')), 'obsolete starter.js is removed');
check(html.includes('id="loadEnter"'), 'preloader requires explicit enter action');
check(engine.includes("enter.onclick=()=>") && engine.includes("ld.style.display='none'"), 'preloader only hides after user action');
check(html.includes('id="bLightDots"') && css.includes('.lightHex.filled'), 'Light hex-pip UI exists');
check(html.includes('id="bSceneSign"') && html.includes('id="bKills"'), 'scene sign and defeated counter exist');
check(html.includes('id="bStartClash"') && css.includes("../assets/icon/start-clash.webp"), 'image-backed Start Clash control exists');
check(css.includes("../assets/icon/stagger.webp"), 'transparent Stagger asset path is used');
check(engine.includes('tryAssignStaggeredPage') && engine.includes('resolveStaggeredAttack'), 'staggered enemies can be assigned unopposed attacks');
check(engine.includes('getEncounterWaves') && engine.includes('B.bookDrops'), 'multi-Act encounters and cumulative Books are supported');
check(engine.includes("activeMission='rats'") && engine.includes('grantStarterInventory()'), 'starter pages are issued by inventory when job is accepted');
check(engine.includes('filter(p=>p.equipped).slice(0,9)'), 'combat bookshelf limits equipped pages to nine');
check(engine.includes('slots.findIndex(w=>!w)'), 'weapon inventory enforces two slots');
check(engine.includes('Math.random()<.32'), 'Key Page extraction chance is implemented');
check(engine.includes('status-${escapeHTML(st.id)}') && engine.includes('potency') && engine.includes('count') && engine.includes('effectIconsMarkup'), 'potency/count statuses and emoji page icons are rendered');
check(engine.includes('🩸') && engine.includes('🫨') && engine.includes('🔋') && !engine.includes('No status effects</div>'), 'status HUD uses emoji icons rather than written status names');
check(engine.includes('triggerAttackStatuses') && engine.includes('triggerHitStatuses') && engine.includes('consumeDiceStatus'), 'Bleed, Rupture, and Paralysis have distinct triggers');
check(engine.includes('consumeHitStatuses(B.player);') && engine.includes('consumeHitStatuses(en);'), 'Fragile and Protection Count decrease when either side is hit');
check(engine.indexOf('if(en.hp>0)triggerHitStatuses(en);') < engine.indexOf("if(en.hp>0)applyPageEffects(page,en,'hit',attacker,dmgType);"), 'existing Rupture triggers before new on-hit status application');
check(engine.includes('if(B.player.hp>0)triggerHitStatuses(B.player);'), 'Rupture also triggers when the player is hit');
check(engine.includes("dmgType==='pierce'") && engine.includes("applyPageEffects(page,en,'hit',attacker,dmgType)"), 'Pierce-only Key Page passive checks the actual resolving die type');


check(engine.includes("fairyFestival:'assets/abnormalities/fairy-festival.webp'"), 'Fairy Festival sprite finder uses the dedicated abnormality asset folder');
check(html.includes('data/dialogues/Urban-Myth/hana-examination.js'), 'Urban Myth examination dialogue loads from its dedicated story folder');
check(fs.existsSync(path.join(root,'assets/abnormalities/fairy-festival.webp')) && !fs.existsSync(path.join(root,'assets/sprites/fairy-festival.webp')), 'Fairy Festival sprite is located only in the abnormality asset folder');
check((fs.readFileSync(path.join(root,'data/pages/equipment.js'),'utf8').match(/nestOnly:true/g)||[]).length>=5, 'Nest-only authorized body equipment catalogue exists');

const weaponDataText=fs.readFileSync(path.join(root,'data/pages/weapons.js'),'utf8');
check(['nest_issue_blade','nest_precision_spear','nest_guard_baton'].every(id=>weaponDataText.includes(id)), 'three official Nest-only weapons are defined');
check(engine.includes("filter(w=>w.nestOnly).map(w=>({id:w.id,name:w.n,price:w.price,desc:w.desc,kind:'weapon'}))") && engine.includes("else if(item.kind==='weapon')S.inventory.weapons.push"), 'Nest authorized counter sells the special weapons into the existing two-slot inventory');
const storyTiers=['Canard','Urban-Myth','Urban-Legend','Urban-Plague','Urban-Nightmare','Star-of-the-City','Impuritas-Civitatis'];
check(storyTiers.every(tier=>['Associations','Fingers','Wings'].every(group=>fs.existsSync(path.join(root,'data/dialogues',tier,group,'README.txt')))), 'future story-tier folders exist for Associations, Fingers, and Wings through Impuritas Civitatis');
check(fs.existsSync(path.join(root,'assets/abnormalities/README.txt')) && fs.existsSync(path.join(root,'data/abnormalities/README.txt')), 'abnormality art and definition folders are documented separately');
check(fs.existsSync(path.join(root,'data/factions/README.txt')) && fs.statSync(path.join(root,'data/factions/README.txt')).isFile(), 'faction taxonomy readme is a file, not a nested folder');

check(['Urban-Myth','Urban-Legend','Urban-Plague','Urban-Nightmare','Star-of-the-City','Impuritas-Civitatis'].every(tier=>fs.existsSync(path.join(root,'data/story-arcs',tier,'README.txt'))), 'future story arc folders are prepared without being unlocked');
check(['Hana','Zwei','Liu','Shi','Seven'].every(name=>fs.existsSync(path.join(root,'data/factions/associations',name,'README.txt'))) && ['Thumb','Index','Middle','Ring','Pinky'].every(name=>fs.existsSync(path.join(root,'data/factions/fingers',name,'README.txt'))) && ['K-Corp','R-Corp','W-Corp'].every(name=>fs.existsSync(path.join(root,'data/factions/wings',name,'README.txt'))), 'Association, Five Finger, and Wing organization folders are prepared');
check(['Syndicate','Fixer','Fixer-Association','Wing-Facility-Worker','LobCorp-LCE-Extraction','R-Corp-Employee','W-Corp-Cleanup','Nest-Administrator'].every(name=>fs.existsSync(path.join(root,'data/careers',name,'README.txt'))), 'future career/job folders are prepared without adding unplanned mechanics');



// Parse every project script independently.
const jsFiles = [];
for (const folder of ['js', 'data']) {
  const walk = dir => fs.readdirSync(dir, {withFileTypes:true}).forEach(d => {
    const full = path.join(dir, d.name);
    if (d.isDirectory()) walk(full); else if (d.name.endsWith('.js')) jsFiles.push(full);
  });
  walk(path.join(root, folder));
}
for (const file of jsFiles) {
 const result = spawnSync(process.execPath, ['--check', file], {encoding:'utf8'});
 check(result.status === 0, `JavaScript syntax: ${path.relative(root, file)}`);
 if (result.status !== 0) console.error(result.stderr || result.stdout);
}

// Verify the separate Easter egg module runs and normalizes names/buffs as intended.
try {
 const eggContext = vm.createContext({window:{}});
 vm.runInContext(fs.readFileSync(path.join(root,'js/easter-eggs/easter-eggs.js'),'utf8'), eggContext, {filename:'js/easter-eggs/easter-eggs.js'});
 const api=eggContext.window.CityEasterEggs;
 check(!!api && api.normalizeName('Bamboo-Hatted Kim')==='bamboohattedkim', 'Easter egg module normalizes spaces and punctuation');
 check(api.messageFor('ROLAND')==='Truly a washed up grade 9 fixer' && api.messageFor('Kali').startsWith('IS THAT THE RED MIST'), 'Easter egg module preserves the supplied editable messages');
 check(api.buffFor('KALI').expMultiplier===1.5 && api.buffFor('Rodion').ahnMultiplier===1.25, 'Easter egg gameplay buffs are read from the separate config');
} catch(e) { fail.push('Easter egg module runtime ('+e.message+')'); }

// Test the status helper functions in isolation (not a full browser/combat simulation).
try {
 const statusStart=engine.indexOf('// Statuses use potency + count.');
 const statusEnd=engine.indexOf('/* ---------- summary ---------- */',statusStart);
 const statusSource=engine.slice(statusStart,statusEnd);
 const statusContext=vm.createContext({window:{},B:{player:{name:'Tester'}},S:{name:'Tester'},Math,escapeHTML:s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])),isDef:t=>['block','evade'].includes(t),logMsg:()=>{},dealStaggerDamage:()=>{},combatLevel:()=>1,drawPage:()=>{},currentPassive:()=>({})});
 vm.runInContext(statusSource,statusContext,{filename:'status-helper-test.js'});
 const verdict=vm.runInContext(`(()=>{const u={name:'Status Test',hp:20,alive:true,statuses:[]};addStatus(u,'bleed',1,2);addStatus(u,'bleed',2,3);const merged=unitStatus(u,'bleed')===3&&statusCount(u,'bleed')===5;const p={name:'Paralysis Test',statuses:[]};addStatus(p,'paralysis',2,1);const before=unitStatus(p,'paralysis');consumeDiceStatus(p,{t:'slash'});const spent=statusCount(p,'paralysis')===0;const b={name:'Buff Test',statuses:[]};addStatus(b,'strength',1,2);tickStatuses(b);const decayed=statusCount(b,'strength')===1;const bleedCount=statusCount(u,'bleed')===5;const html=statusMarkup(u);const icons=html.includes('🩸')&&!html.includes('>Bleed ');return {merged,paralysis:before===2&&spent,decayed,bleedCount,icons}})()`,statusContext);
 check(verdict.merged,'status potency and count stack independently');
 check(verdict.paralysis,'Paralysis Count is consumed by one offensive die');
 check(verdict.decayed&&verdict.bleedCount,'scene buffs expire at Scene end while Bleed Count waits for its trigger');
 check(verdict.icons,'visible status tags use emoji icons and potency/count numbers');
} catch(e) { fail.push('status helper behavior ('+e.message+')'); }

// Load data in actual script order and validate every referenced page/book/encounter.
const context = vm.createContext({window:{}, console, Math, Date});
for (const rel of [
 'js/helpers.js','js/data/canon.js','data/pages/skill1/pages.js','data/pages/skill2/pages.js',
 'data/dialogues/Urban-Myth/hana-examination.js','data/pages/enemies-rats.js','data/pages/enemies-canard.js','data/abnormalities/fairy-festival.js','data/pages/equipment.js','data/pages/keypages.js',
 'data/pages/weapons.js','js/data/story.js','data/dialogues/Canard/Backstreets-Rats/dialogue.js','data/dialogues/Canard/Yun-Office/routes.js','data/dialogues/Canard/Brotherhood-of-Iron/routes.js','data/dialogues/Canard/Hook-Office/routes.js','data/dialogues/Canard/Yun-Office/missions.js','data/dialogues/Canard/Brotherhood-of-Iron/missions.js','data/dialogues/Canard/Hook-Office/missions.js'
]) {
 try { vm.runInContext(fs.readFileSync(path.join(root,rel),'utf8'), context, {filename:rel,timeout:3000}); }
 catch (e) { fail.push(`data load executes: ${rel} (${e.message})`); }
}
const w = context.window;
check(Object.values(w.WEAPON_DATA||{}).filter(item=>item.nestOnly).length===3, 'Nest-only weapons load into the existing weapon database');
check(Object.keys(w.PAGES||{}).length >= 30, 'page database includes baseline and Canard pools');
try {
 const dialogue = w.URBAN_MYTH_DIALOGUE?.buildHanaExamination({playerName:'Tester', reputation:80, flags:{canonicalReceptionOutcomes:{yunOffice:'helped',brotherhood:'fight',hookOffice:'helped'},canonicalFates:{yun:'alive',eri:'alive',finn:'alive',mo:'dead',consta:'dead',arnold:'alive',naoki:'alive',mccullin:'alive',taein:'alive'}}});
 check(Array.isArray(dialogue) && dialogue.some(x=>x.k==='battle'&&x.encounter==='fairyFestival'), 'Urban Myth dialogue builder includes the Fairy Festival exam');
 const textBlob=(dialogue||[]).map(x=>x.t||'').join(' ');
 check(!/Rats/i.test(textBlob), 'Hana Association report intentionally excludes the Rats');
 check((dialogue||[]).some(x=>(x.t||'').toLowerCase().includes('street talk likes them')||(x.t||'').toLowerCase().includes('helped people')), 'high reputation creates extra Urban Myth dialogue');
 check((textBlob.includes('Mo, Consta')||textBlob.includes('Dead listed: Mo, Consta')) && (textBlob.includes('Arnold')&&(textBlob.includes('walked away')||textBlob.includes('survived')||textBlob.includes('Incomplete'))), 'Hana report distinguishes dead Brotherhood members from Arnold');
 const lowDialogue = w.URBAN_MYTH_DIALOGUE?.buildHanaExamination({playerName:'Tester', reputation:20, flags:{canonicalReceptionOutcomes:{yunOffice:'fight',brotherhood:'fight',hookOffice:'fight'},canonicalFates:{yun:'dead',eri:'dead',finn:'alive',mo:'dead',consta:'dead',arnold:'alive',naoki:'dead',mccullin:'dead',taein:'dead'}}});
 const lowText=(lowDialogue||[]).map(x=>x.t||'').join(' ');
 check((lowText.toLowerCase().includes('reputation')&&(lowText.toLowerCase().includes('dirt')||lowText.toLowerCase().includes('fallen'))) && (lowText.includes('Finn')&&(lowText.includes('walked away')||lowText.includes('survived'))), 'low Reputation and partial-survivor outcomes generate accurate Hana dialogue');
 const mixedDialogue = w.URBAN_MYTH_DIALOGUE?.buildHanaExamination({playerName:'Tester', reputation:58, flags:{canonicalReceptionOutcomes:{yunOffice:'fight',brotherhood:'helped',hookOffice:'helped'},canonicalFates:{yun:'dead',eri:'dead',finn:'alive',mo:'alive',consta:'alive',arnold:'alive',naoki:'alive',mccullin:'alive',taein:'alive'}}});
 const mixedText=(mixedDialogue||[]).map(x=>x.t||'').join(' ');
 check(mixedText.includes("Yun's Office") && !mixedText.includes('Brotherhood of Iron') && !mixedText.includes('Hook Office'), 'Hana casualty dialogue names only the office with deaths when the other offices were helped');
 check(!mixedText.includes('Rats'), 'mixed-outcome Hana report continues to exclude the Rats');
} catch(e) { fail.push('Urban Myth dialogue builder behavior ('+e.message+')'); }

const pageEffects = id => (w.PAGES?.[id]?.effects||[]);
check(pageEffects('lightAtk').some(f=>f.type==='restoreLight'&&f.amount===2) && pageEffects('quickness').some(f=>f.type==='draw'&&f.amount===1), 'basic pages support Light restoration and drawing a Combat Page');
check(pageEffects('dodgeStrike').some(f=>f.status==='paralysis') && pageEffects('parry').some(f=>f.status==='strength'), 'baseline Combat Pages can inflict Paralysis and grant Strength');
check(pageEffects('parry').some(f=>f.trigger==='use'&&f.status==='strength') && pageEffects('quickStep').some(f=>f.status==='haste'&&f.count===2), 'Strength applies before dice roll and Haste lasts into the next Speed roll');
check(pageEffects('shiv').every(f=>!f.status||f.status==='bleed') && pageEffects('ratsGuide').every(f=>!f.status||f.status==='bleed'), 'Rats apply Bleed rather than unrelated status buffs');
check(pageEffects('ledgerRead').some(f=>f.status==='haste') && pageEffects('feeCollection').some(f=>f.status==='rupture'), 'Yun Office pages apply Haste and Rupture');
check(pageEffects('cChargeUp').some(f=>f.status==='charge') && pageEffects('bBlowItUp').some(f=>f.status==='tremor') && pageEffects('cChop').some(f=>f.type==='tremorBurst'), 'Brotherhood pages build Charge and trigger Tremor Burst');
check(pageEffects('hookCut').some(f=>f.status==='bleed') && pageEffects('hookCut').some(f=>f.type==='heal'), 'Hook Office pages combine Bleed with self-healing');
const enemyPickerSource = engine.slice(engine.indexOf('function pickEnemyPage(enemy){'), engine.indexOf('function intentText(enemy){'));
try {
 vm.runInContext('function diceSlots(){return 1}; function rollSpeeds(){return [1]};\n'+enemyPickerSource, context, {filename:'enemy-page-picker-test.js'});
 const probe={pages:['bBlowItUp','cChargeUp'],pageCursor:0};
 const sequence=[context.pickEnemyPage(probe)?.id,context.pickEnemyPage(probe)?.id,context.pickEnemyPage(probe)?.id];
 check(sequence.join(',')==='bBlowItUp,cChargeUp,bBlowItUp','enemy page picker cycles in assigned order without randomization');
} catch (e) { fail.push('enemy page picker behavior test ('+e.message+')'); }

const skill3Source = fs.readFileSync(path.join(root, 'data/pages/skill3/pages.js'), 'utf8');
check(!scriptPaths.includes('data/pages/skill3/pages.js') && /relentless:/.test(skill3Source) && /breakLine:/.test(skill3Source) && /unyielding:/.test(skill3Source), 'Skill 3 pages exist as source-only future content and are not loaded at Canard');
const enc = w.ENCOUNTERS || {};
for (const [encId, encounter] of Object.entries(enc)) {
 const waves = encounter.waves || [encounter.enemies || []];
 for (const [wi,wave] of waves.entries()) for (const e of wave) {
  check(!!e.id && Number(e.hp)>0 && Number(e.stagger)>0, `valid enemy stats: ${encId}/wave${wi+1}/${e.id}`);
  for (const pageId of (e.pages||[])) check(!!w.PAGES[pageId], `enemy page exists: ${encId}/${e.id}/${pageId}`);
  if (e.book) check(!!w.BOOK_DATA?.[e.book], `enemy book exists: ${encId}/${e.id}/${e.book}`);
 }
}
for (const [bookId, book] of Object.entries(w.BOOK_DATA||{})) {
 for (const pageId of (book.pages||[])) check(!!w.PAGES[pageId], `book page exists: ${bookId}/${pageId}`);
 if (book.key) check(!!w.KEY_PAGES?.[book.key], `book Key Page exists: ${bookId}/${book.key}`);
}
for(const encounter of Object.values(w.ENCOUNTERS||{})){const waves=encounter.waves||[encounter.enemies||[]];for(const wave of waves)for(const enemy of wave){if(!enemy.book)continue;for(const pageId of (w.BOOK_DATA?.[enemy.book]?.pages||[]))check(!!enemy.pages?.includes(pageId),`Book pool matches actual used page: ${enemy.book}/${pageId}`)}}
for (const id of (w.CANARD_MISSION_ORDER||[])) {
 const m=w.CANARD_MISSIONS?.[id];
 check(!!m, `Canard chain entry exists: ${id}`);
 if(m) check(!!enc[m.encounter], `mission encounter exists: ${id}/${m.encounter}`);
}
for (const route of ['rat_direct','rat_calm','rat_silent']) {
 const branches=w.RAT_ROUTES?.[route]||[];
 const choices=branches.find(n=>n.k==='ch');
 check(!!choices && choices.o.length===3, `first encounter branch has three unique follow-up choices: ${route}`);
 for(const op of (choices?.o||[])) check(!!w.RAT_ROUTES?.[op.route], `first encounter route target exists: ${route} -> ${op.route}`);
}

// Narrative progression, stagger timing, player pronouns, market locality and interrupted-battle recovery.
const yunFinal = w.CANARD_MISSIONS?.yunOffice;
check(html.includes("window.CANARD_MISSION_ORDER = ['yunOffice','brotherhood','hookOffice']"), 'Canard contains only the Yun ledger, Brotherhood, and Hook missions after the Rats contract');
check(!w.CANARD_MISSIONS?.yunOfficeFixers && !w.CANARD_MISSIONS?.finnRookie, 'redundant Yun delivery and rookie missions are removed');
check(!!yunFinal && yunFinal.start.some(n=>n.who==='Finn') && (enc.yunOffice?.enemies||[]).some(e=>e.id==='finn'), 'Finn remains in the final Yun ledger story and encounter');
check((w.BOOK_DATA?.book_yun?.pages||[]).every(id=>!['bBlowItUp','cChargeUp'].includes(id)), 'Yun book pool excludes Brotherhood Combat Pages');
check((w.BOOK_DATA?.book_yun?.pages||[]).every(id=>(enc.yunOffice?.enemies||[]).find(e=>e.id==='yun')?.pages.includes(id)), 'Yun book pool matches Yun’s own assigned pages');
check(engine.includes('staggeredThisScene') && engine.includes('if(e.staggeredThisScene)e.staggeredThisScene=false;else{e.stunTurns--'), 'stagger duration ignores the Scene in which stagger was first inflicted');
check(engine.includes("const interruptedBattle=(snap.screen==='battle'||!!snap.battle||!!S.pendingMission)"), 'Continue detects saved combat and provisional victory as interrupted work');
check(engine.includes("else script=[{k:'missionPost',id:missionId}]") && engine.includes('mission?.post'), 'post-fight mission report is chosen before the contract is officially closed');
check(engine.includes('S.flags.activeMission=null;S.pendingMission=null;') && engine.includes('Your last encounter was interrupted before the contract was officially completed'), 'interrupted encounter returns home without completion or reward');
check(engine.includes("window.addEventListener('pagehide',saveSnapshot)") && engine.includes("document.visibilityState==='hidden'"), 'autosave runs on page hide and hidden-tab transitions');
check(engine.includes("}else if(current.key==='market')") && engine.includes('MARKET CATALOGUE') && engine.includes('Market Street') && engine.includes('marketGoods') && engine.includes('Nest Transit Ticket'), 'expanded item descriptions and the Nest ticket are local to Market Street');
check(engine.includes('function pickEnemyPage(enemy)') && engine.includes('enemy.pageCursor%pages.length') && !engine.includes('Math.random()<0.82?simple:pages'), 'enemies cycle only through their explicitly assigned Combat Pages');
check(engine.includes('pageGroups=new Map()') && engine.includes('pageGroups.values()') && engine.includes('stackCount') && engine.includes('duplicate copy stacked'), 'duplicate Combat Pages and Key Pages are displayed as stacks');
check(engine.includes('const plannedLight=') && engine.includes("dot.classList.add('planned')") && css.includes('.lightHex.planned'), 'planned Light spend is highlighted before the Scene starts');
check(engine.includes('Assigned page cancelled and returned to the hand') && engine.includes('tryAssignStaggeredPage'), 'a second tap cancels an assigned page and staggered enemies accept direct attacks');
check(engine.includes('travelPanel') && engine.includes('travelGrid') && engine.includes("home:['back']") && engine.includes("checkpoint:['back',...(isAllowedNest?['nest']:[])]") && !engine.includes("['hook','🪝 Hook Office Passage'") && !engine.includes("['junction','🚉 Inter-district Junction'"), 'travel routes use fixed slots, prerequisites, and no unused Hook Office alleyway');
const yunRoutesSource = fs.readFileSync(path.join(root, 'data/dialogues/Canard/Yun-Office/routes.js'), 'utf8');
check(engine.includes("S.pronouns=op.pronouns||'they/them'"), 'player pronouns are selected and substituted in dialogue');
check(engine.includes('nameEasterEgg(v)') && fs.readFileSync(path.join(root, 'js/easter-eggs/easter-eggs.js'), 'utf8').includes("roland: 'Truly a washed up grade 9 fixer'") && fs.readFileSync(path.join(root, 'js/easter-eggs/easter-eggs.js'), 'utf8').includes("kali: 'IS THAT THE RED MIST"), 'name Easter egg messages remain editable in the separate module');
const canonSource=fs.readFileSync(path.join(root,'js/data/canon.js'),'utf8');
check(canonSource.includes("rats: Object.freeze({ pete: 'dead', lenny: 'dead', mangchi: 'dead' })") && canonSource.includes("yunOffice: Object.freeze({ yun: 'dead', eri: 'dead', finn: 'alive' })") && canonSource.includes("brotherhood: Object.freeze({ mo: 'dead', consta: 'dead', arnold: 'alive' })") && canonSource.includes("hookOffice: Object.freeze({ taein: 'dead', mccullin: 'dead', naoki: 'dead' })"), 'canonical survivor/death outcomes match the four agreed receptions');
check(fs.readFileSync(path.join(root,'js/data/story.js'),'utf8').includes('window.POST_RATS_REPLAY') && fs.readFileSync(path.join(root,'data/dialogues/Canard/Yun-Office/missions.js'),'utf8').includes('postReplay') && fs.readFileSync(path.join(root,'data/dialogues/Canard/Brotherhood-of-Iron/missions.js'),'utf8').includes('postReplay') && fs.readFileSync(path.join(root,'data/dialogues/Canard/Hook-Office/missions.js'),'utf8').includes('postReplay'), 'all four receptions provide replay-safe canonical aftermaths');
check(fs.readFileSync(path.join(root,'data/dialogues/Canard/Brotherhood-of-Iron/missions.js'),'utf8').includes('shipment trail ends at Workshop Row') && fs.readFileSync(path.join(root,'data/dialogues/Canard/Hook-Office/missions.js'),'utf8').includes('Workshop inquiry closes with a report'), 'later reception introductions remain outcome-neutral and do not falsely declare assisted offices dead');
check(engine.includes('img.onerror=()=>d.remove()') && engine.includes('sprite.onerror=()=>sprite.remove()'), 'missing character artwork stays absent instead of using a placeholder sprite');

// Validate all asset declarations actually present in the project, report missing art explicitly.
const spriteMatches=[...engine.matchAll(/([a-zA-Z0-9_]+):'assets\/sprites\/([^']+)'/g)].map(m=>({key:m[1],file:`assets/sprites/${m[2]}`}));
const bgNames=[...css.matchAll(/url\(['"]?\.\.\/assets\/bg\/([^)'"\s]+)/g)].map(m=>`assets/bg/${m[1]}`);
const missing=[...new Set([...spriteMatches.map(x=>x.file),'assets/sprites/arnold.webp',...bgNames,'assets/icon/start-clash.webp','assets/icon/stagger.webp'])].filter(rel=>!fs.existsSync(path.join(root,rel)));
fs.writeFileSync(path.join(root,'ASSET_MANIFEST.txt'), [
 'THE CITY — ASSET MANIFEST',
 'Provide art using these exact relative file paths and extensions. Paths are case-sensitive on many hosts.',
 '', 'REQUIRED EXISTING CORE ART:',
 'assets/bg/menu.webp — title menu background',
 'assets/bg/city.webp — default Backstreets street/alley background',
 'assets/bg/apt.webp — apartment/home',
 'assets/bg/outplace.webp — Outskirts shelter',
 'assets/bg/school.webp — school scenes',
 'assets/bg/nest.webp — Nest scenes',
 'assets/bg/out.webp — general Outskirts',
 'assets/icon/start-clash.webp — transparent Start Clash emblem (provided in this revision)',
 'assets/icon/stagger.webp — transparent Stagger marker (provided in this revision)',
 'assets/sprites/pete.webp — Pete', 'assets/sprites/rat_a.webp — Lenny', 'assets/sprites/rat_b.webp — Mang Chi',
 '', 'USER-PROVIDED URBAN MYTH ART INCLUDED IN THIS REVISION:',
 'assets/bg/hana-association.webp — Hana Association examination hall',
 'assets/abnormalities/fairy-festival.webp — Fairy Festival abnormality combat sprite',
 'assets/sprites/han-ul.webp — Han-ul examiner',
 'assets/sprites/zevelyn.webp — Zevelyn, Grade 8 Fixer',
 '', 'OPTIONAL ART EXPECTED BY THIS BUILD (missing character sprites stay absent; unavailable location art uses fallback backgrounds):',
 'BACKGROUND FILES:',
 ...bgNames.filter(rel=>/assets\/bg\//.test(rel)).filter((x,i,a)=>a.indexOf(x)===i).filter(rel=>!fs.existsSync(path.join(root,rel))).map(rel=>`${rel} — ${rel.split('/').pop().replace('.webp','').replace(/-/g,' ')} location`),
 '', 'CHARACTER SPRITES:',
 ...spriteMatches.filter(x=>!fs.existsSync(path.join(root,x.file))).map(x=>`${x.file} — ${x.key}`),
 ...(!fs.existsSync(path.join(root,'assets/sprites/arnold.webp'))?['assets/sprites/arnold.webp — Arnold (Brotherhood of Iron)']:[]),
 '', 'NOTES:',
 '- Transparent character sprites should be WebP or converted to the exact .webp path above, with alpha retained.',
 '- Optional art is not a blocker. Missing character sprite paths do not show a placeholder or substitute character.',
 '- The preloader checks declared images, but hides the missing-file list before the title menu.',
 '- Missing-image list in this test run:',
 ...(missing.length?missing.map(x=>`  ${x}`):['  None'])
].join('\n')+'\n');


// Fixer progression, enemy levels, level-adjusted page stats, and defensive dice.
check(engine.includes('const PLAYER_LEVEL_CAP_BASE=30') && engine.includes('PLAYER_LEVEL_CAP_PROMOTED=50') && engine.includes('function playerLevelCap') && engine.includes('function xpToNextLevel'), 'Fixer progression: base cap 30, Grade 8 raises cap to 50');
check(engine.includes('function unitOffenseLevel') && engine.includes('function unitDefenseLevel') && engine.includes('const levelPower=Math.max(0,Math.floor((own-theirs)/3))'), 'Offense/Defense Levels give only the higher-level die a clash power bonus per three levels');
check(engine.includes('return Math.max(1,combatLevel(unit)+(Number(kp?.offLevel)||0)') && engine.includes('return Math.max(1,combatLevel(unit)+(Number(kp?.defLevel)||0)'), 'Offense/Defense Levels cannot fall below Level 1');
check(engine.includes('function levelDamageMultiplier') && engine.includes('diff/(Math.abs(diff)+25)'), 'Offense-vs-Defense level difference modifies attack damage with diminishing returns');
check(engine.includes('function dealStaggerDamage') && engine.includes('Block wins and deals'), 'Block can inflict direct Stagger damage independent of attack damage type');
check(engine.includes('playerQueue.push(playerItem)') && engine.includes('recycles behind the remaining dice') && engine.includes('defenseRoll>incomingRoll') && engine.includes('B.player.defenseStances=[]'), 'winning Evade recycles behind remaining dice and is spent on a tie/failure; Block is consumed');
check(engine.includes('dealStaggerDamage(en,blockStaggerAmount(B.player,ar-br))') && engine.includes('dealStaggerDamage(B.player,br-ar)') && engine.includes('dealStaggerDamage(en,blockStaggerAmount(B.player,ar))'), 'Block deals direct Stagger damage using the winning defensive roll or attack margin');
check(engine.includes('rollClashDie(playerDie,playerUnit,enemyUnit,playerPage,enemyPage,enemyDie)') && engine.includes('rollClashDie(enemyDie,enemyUnit,playerUnit,enemyPage,playerPage,playerDie)'), 'clash rolls include both dice for Offense/Defense Level comparisons');
check(engine.includes('A tie is a draw and consumes both dice') && !engine.includes('Tie — rerolling the clash'), 'clash ties are resolved as draws instead of rerolling until a winner appears');
check(engine.includes('if(B.player.defenseStances?.length&&!isDef(enemyQueue[0].die.t))') && engine.includes('if(en.defenseStances?.length&&!isDef(playerQueue[0].die.t))'), 'retained Evade/Block stances intercept the next incoming attack before fresh dice');
check(engine.includes("const resolvedKeys=new Set()") && engine.includes("if(resolvedKeys.has(en.id+'#'+di))continue;"), "enemy attacks that lose their assigned player clash after a Stagger still resolve unopposed");
check(engine.includes('dealStaggerDamage(en,blockStaggerAmount(B.player,ar-br))') && engine.includes('dealStaggerDamage(B.player,br-ar)') && engine.includes('Your Block wins against Block and deals ${blockStaggerAmount(B.player,ar)} Stagger damage'), 'Block Stagger damage is direct: attack clashes use the margin, defensive clashes use the winning Block roll');
check(engine.includes('exp_ticket_1') && engine.includes('exp_ticket_2') && engine.includes('exp_ticket_3') && engine.includes('Used ${item.n}: +${xp} EXP'), 'Tier I–III EXP Tickets can be purchased and manually consumed');
check(engine.includes('MISSION_LEVEL_REQUIREMENTS={yunOffice:8,brotherhood:13,hookOffice:18,urbanMythExam:22}') && engine.includes('Required Fixer Level'), 'mission progression gives explicit minimum level requirements');
check(engine.includes('Potential EXP') && engine.includes('expEarned') && engine.includes('applyExperience(expReward)'), 'EXP is provisional during combat and awarded only when a mission is officially completed');
check(engine.includes('×${c.count}') && engine.includes('stackMap=new Map()'), 'duplicate consumables merge into stacked inventory counts');
check(css.includes('scroll-snap-type:x proximity') && css.includes('touch-action:pan-x') && css.includes('#bConsumables{position:absolute;top:'), 'combat supplies are a horizontal swipe panel below the Scene sign');
for (const [id, encounter] of Object.entries(enc)) {const waves=encounter.waves||[encounter.enemies||[]];for(const [wi,wave] of waves.entries())for(const e of wave)check(Number(e.level)>=1,`enemy has a defined level: ${id}/wave${wi+1}/${e.id}`)}

const canonTest=spawnSync(process.execPath,[path.join(root,'tests/story-canon-check.js')],{encoding:'utf8'});
if(canonTest.stdout)process.stdout.write(canonTest.stdout);
if(canonTest.stderr)process.stderr.write(canonTest.stderr);
check(canonTest.status===0, 'canonical outcome unit tests pass');

if (fail.length) {
 console.error(`\nFAIL ${fail.length} smoke check(s):`);
 for (const item of fail) console.error(` - ${item}`);
 process.exitCode=1;
} else {
 console.log('\nAll static/data smoke checks passed. This is not a full browser/phone playtest.');
}
