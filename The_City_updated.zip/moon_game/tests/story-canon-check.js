#!/usr/bin/env node
/* Unit tests for persistent canonical outcomes and replay-safe state. */
const fs = require('fs');
const path = require('path');
const vm = require('vm');
const assert = require('assert');
const source = fs.readFileSync(path.join(__dirname, '..', 'js/data/canon.js'), 'utf8');
const context = { window: {} };
vm.runInNewContext(source, context, { filename: 'js/data/canon.js' });
const canon = context.window.CityCanon;

const fresh = { completedMissions: [], ratsCleared: false };
assert.strictEqual(canon.fateFor(fresh, 'pete'), 'unknown');
assert.strictEqual(canon.commitMission(fresh, 'rats'), true);
assert.deepStrictEqual(JSON.parse(JSON.stringify(fresh.canonicalFates)), {
  pete: 'dead', lenny: 'dead', mangchi: 'dead'
});
assert.strictEqual(canon.fateFor(fresh, 'rata'), 'dead');
assert.strictEqual(canon.fateFor(fresh, 'rat_b'), 'dead');
assert.strictEqual(canon.commitMission(fresh, 'rats'), false, 'a canonical outcome is committed once');

const fullProgress = {
  ratsCleared: true,
  completedMissions: ['yunOffice', 'brotherhood', 'hookOffice']
};
canon.migrate(fullProgress);
assert.strictEqual(canon.fateFor(fullProgress, 'pete'), 'dead');
assert.strictEqual(fullProgress.canonicalRefreshPending.yunOffice, true, 'existing completed Yun saves require one refresh run');
assert.strictEqual(fullProgress.canonicalRefreshPending.brotherhood, true, 'existing completed Brotherhood saves require one refresh run');
assert.strictEqual(fullProgress.canonicalRefreshPending.hookOffice, true, 'existing completed Hook saves require one refresh run');
assert.strictEqual(canon.isMissionCompleted(fullProgress, 'yunOffice'), false, 'pending refresh is treated as incomplete for one story replay');
assert.strictEqual(canon.fateFor(fullProgress, 'yun'), 'unknown', 'legacy assumed outcome is not treated as the new registered choice');
assert.strictEqual(canon.commitMission(fullProgress, 'yunOffice', 'helped'), true, 'refresh completion can replace a legacy assumed outcome');
assert.strictEqual(canon.fateFor(fullProgress, 'yun'), 'alive');
assert.strictEqual(fullProgress.canonicalRefreshPending.yunOffice, undefined, 'refresh clears after the outcome is registered');
assert.strictEqual(canon.isMissionCompleted(fullProgress, 'yunOffice'), true);

const midProgress = { ratsCleared: true, completedMissions: [] };
canon.migrate(midProgress);
assert.strictEqual(canon.fateFor(midProgress, 'pete'), 'dead');
assert.strictEqual(canon.fateFor(midProgress, 'yun'), 'unknown', 'unfinished future missions must not receive their outcomes early');
assert.strictEqual(canon.fateFor(midProgress, 'arnold'), 'unknown', 'unreached Brotherhood fate must stay unset until that reception is completed or save migration proves it was completed');

// The ability to replay is separate from the saved canon. Re-committing a mission
// after completion cannot alter the persistent fate record.
assert.strictEqual(canon.isMissionCompleted(fullProgress, 'rats'), true);
assert.strictEqual(canon.isMissionCompleted(fullProgress, 'yunOffice'), true);
fullProgress.canonicalFates.finn = 'dead';
assert.strictEqual(canon.commitMission(fullProgress, 'yunOffice'), false);
assert.strictEqual(canon.fateFor(fullProgress, 'finn'), 'dead', 'repeat clear must not overwrite canon state');

const helped = { completedMissions: [] };
assert.strictEqual(canon.commitMission(helped, 'yunOffice', 'helped'), true);
assert.strictEqual(canon.fateFor(helped, 'yun'), 'alive');
assert.strictEqual(canon.fateFor(helped, 'eri'), 'alive');
assert.strictEqual(canon.fateFor(helped, 'finn'), 'alive');
assert.strictEqual(helped.canonicalReceptionOutcomes.yunOffice, 'helped');
assert.strictEqual(canon.commitMission(helped, 'yunOffice', 'fight'), false, 'a later replay cannot overwrite the helpful canonical outcome');
assert.strictEqual(canon.fateFor(helped, 'yun'), 'alive');


for (const id of ['brotherhood', 'hookOffice']) {
  const members = id === 'brotherhood' ? ['mo', 'consta', 'arnold'] : ['naoki', 'taein', 'mccullin'];
  const save = { completedMissions: [] };
  assert.strictEqual(canon.commitMission(save, id, 'helped'), true, `${id} helpful route should commit`);
  for (const name of members) assert.strictEqual(canon.fateFor(save, name), 'alive', `${name} remains alive on helpful route`);
  assert.strictEqual(canon.commitMission(save, id, 'fight'), false, `${id} replay must not replace helpful canon`);
  for (const name of members) assert.strictEqual(canon.fateFor(save, name), 'alive', `${name} stays alive after replay`);
}

console.log('All canonical fate tests passed.');
