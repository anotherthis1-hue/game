
window.__spr={
 pete:'assets/sprites/pete.webp',rata:'assets/sprites/rat_a.webp',ratb:'assets/sprites/rat_b.webp',
 yun:'assets/sprites/yun.webp',finn:'assets/sprites/finn.webp',eri:'assets/sprites/eri.webp',
 mo:'assets/sprites/mo.webp',consta:'assets/sprites/consta.webp',arnold:'assets/sprites/arnold.webp',
 taein:'assets/sprites/taein.webp',mccullin:'assets/sprites/mccullin.webp',naoki:'assets/sprites/naoki.webp',
 fairyFestival:'assets/abnormalities/fairy-festival.webp',hanUl:'assets/sprites/han-ul.webp',zevelyn:'assets/sprites/zevelyn.webp'
};
const ISSUE_PAGES=['evade','lightAtk','lightAtk','lightDef','thrust','wallop','focused','quickness'];
const BG_KEYS=['void','city','back','apt','school','nest','out','outplace','office','workshop','brotherhood','hook','market','checkpoint','junction','hana'];
const $safe=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
function escapeHTML(s){return $safe(s)}
const $=s=>document.querySelector(s);
let speed=28,typing=null,ready=false,S,i,script,currentBg='back',bgSwapTimer=null,rollTimer=null;
// Future chronological story scripts can query a character's saved canon fate without touching replay state.
window.cityCharacterFate = characterId => window.CityCanon?.fateFor?.(S?.flags, characterId) || 'unknown';

/* ---------- prologue script ---------- */
// Dialogue helpers and story data are loaded before this runtime.



/* ---------- helpers ---------- */
function type(el,text,done){
 if(typing&&typing.t)clearTimeout(typing.t);
 typing=null;
 el.textContent='';let n=0;
 const run=()=>{
  if(n>=text.length){typing=null;done&&done();return}
  const c=text[n++];el.textContent+=c;
  // Ellipsis / trailing dots breathe; normal punctuation is a lighter hitch.
  let mult=1;
  if(c==='…')mult=14;
  else if(c==='.'){
   const runDots=(text[n]==='.'||text[n-2]==='.');
   mult=runDots?11:6;
  }else if(/[,!?—]/.test(c))mult=5;
  typing={el,text,done,t:setTimeout(run,Math.max(8,speed*mult))};
 };
 typing={el,text,done};run();
}
function complete(){if(!typing)return;clearTimeout(typing.t);const{el,text,done}=typing;typing=null;el.textContent=text;done&&done()}
function setBg(k, immediate=false){
 if(!BG_KEYS.includes(k))k='back';
 const front=$('#bg'),nextBg=$('#bgNext');
 // Track the requested location immediately so combat cannot inherit a stale key.
 currentBg=k;
 if(!front){return}
 if(immediate||!nextBg){
  clearTimeout(bgSwapTimer);bgSwapTimer=null;
  front.className='bg-'+k;
  if(nextBg){nextBg.style.transition='none';nextBg.style.opacity='0';nextBg.className='bg-'+k;}
  return;
 }
 if(k===front.className.replace(/^bg-/,'')&&!bgSwapTimer)return;
 clearTimeout(bgSwapTimer);
 nextBg.className='bg-'+k;
 nextBg.style.transition='none';nextBg.style.opacity='0';nextBg.offsetHeight;
 nextBg.style.transition='opacity .7s ease';nextBg.style.opacity='1';
 bgSwapTimer=setTimeout(()=>{
  front.className='bg-'+k;
  nextBg.style.transition='none';nextBg.style.opacity='0';
  bgSwapTimer=null;
 },720);
}
let fadeBusy=false,fadeTimer=null,transitionOutgoing=null,fadeQueue=[];
function show(id){
 const screens=[...document.querySelectorAll('.screen')];
 const incoming=screens.find(s=>s.id===id);
 screens.forEach(s=>{
  if(s===incoming){
   const wasOn=s.classList.contains('on');
   s.classList.add('on');s.classList.remove('transition-old','scene-fade-out');
   if(wasOn){s.classList.remove('scene-fade-in')}
   else{
    // Start transparent, then release next frame so the CSS opacity transition runs 0 -> 1.
    s.classList.add('scene-fade-in');void s.offsetWidth;
    const release=()=>s.classList.remove('scene-fade-in');
    requestAnimationFrame(()=>requestAnimationFrame(release));
    setTimeout(release,200); // fallback if animation frames are throttled
   }
  }
  else if(fadeBusy&&s===transitionOutgoing){s.classList.remove('on','scene-fade-in','scene-fade-out');s.classList.add('transition-old')}
  else{s.classList.remove('on','transition-old','scene-fade-in','scene-fade-out')}
 });
 if(id==='menu')updateContinueButton();
}
function fadeOverlay(el, to, ms){
 return new Promise(resolve=>{
  if(!el){resolve();return}
  const from=parseFloat(el.style.opacity||'0')||0;
  const t0=performance.now();
  el.style.pointerEvents=to>0.05?'auto':'none';
  const step=now=>{
   const p=Math.min(1,(now-t0)/ms);
   // smoothstep
   const e=p*p*(3-2*p);
   el.style.opacity=String(from+(to-from)*e);
   if(p<1)requestAnimationFrame(step);
   else{el.style.opacity=String(to);el.style.pointerEvents=to>0.05?'auto':'none';resolve()}
  };
  requestAnimationFrame(step);
 });
}
async function fadeTo(fn){
 if(fadeBusy)return new Promise(resolve=>fadeQueue.push({fn,resolve}));
 fadeBusy=true;
 const f=$('#fade');
 try{
  if(f){f.style.display='block';await fadeOverlay(f,1,380)}
  try{fn()}catch(e){console.error('Transition failed:',e)}
  await wait(50);
  if(f)await fadeOverlay(f,0,420);
 }finally{
  fadeBusy=false;transitionOutgoing=null;
  if(fadeTimer){clearTimeout(fadeTimer);fadeTimer=null}
  const queued=fadeQueue.shift();
  if(queued)fadeTo(queued.fn).then(queued.resolve);
 }
}

function pronounSet(){
 const raw=String(S?.pronouns||S?.gender||'they/them').toLowerCase();
 if(raw.includes('she')||raw==='girl')return {subj:'she',obj:'her',poss:'her',refl:'herself',be:'is',have:'has'};
 if(raw.includes('he')||raw==='boy')return {subj:'he',obj:'him',poss:'his',refl:'himself',be:'is',have:'has'};
 return {subj:'they',obj:'them',poss:'their',refl:'themself',be:'are',have:'have'};
}
function pronounLabel(){const p=pronounSet();return `${p.subj}/${p.obj}`}
function sub(s){
 const p=pronounSet();
 const values={name:S?.name||'the child',pronoun:p.subj,subject:p.subj,object:p.obj,possessive:p.poss,reflexive:p.refl,be:p.be,have:p.have,he:p.subj,she:p.subj,they:p.subj,him:p.obj,her:p.obj,them:p.obj,his:p.poss,their:p.poss,hers:p.poss,himself:p.refl,herself:p.refl,themself:p.refl};
 return String(s??'').replace(/\{(name|pronoun|subject|object|possessive|reflexive|be|have|he|she|they|him|her|them|his|their|hers|himself|herself|themself)\}/gi,(m,k)=>{
  let v=values[k.toLowerCase()]??m;
  return k[0]===k[0].toUpperCase()?v.charAt(0).toUpperCase()+v.slice(1):v;
 });
}
function activeNameBuff(){
 const api=window.CityEasterEggs;
 return api?.buffFor ? api.buffFor(S?.name||'') : {};
}
function nameBuffValue(key,fallback=0){
 const value=Number(activeNameBuff()[key]);
 return Number.isFinite(value)?value:fallback;
}
function nameBuffMultiplier(key){return Math.max(0,Number(nameBuffValue(key,1))||1)}
function nameEasterEgg(name){return window.CityEasterEggs?.messageFor?.(name)||''}

const DIST={
1:`The Head’s District, home of A Corp. It sits above every other Wing.`,
2:`A District under the Claw, one of the three highest powers in the City.`,
3:`A District under the Eye, one of the three highest powers in the City.`,
4:`D Corp’s District. It has a dark forest, and old G Corp soldiers live in its Backstreets.`,
8:`H Corp’s District. The whole place is one giant building, the Hongyuan Complex.`,
9:`I Corp’s District, known as the Streets of Music.`,
10:`J Corp’s District, the Nest of Gambling. Syndicates like Los Mariachis and the Tingtang Gang run its Backstreets.`,
11:`K Corp’s District. K Corp is known to work with N Corp, far away.`,
12:`L Corp’s District, where Lobotomy Corporation was built. It sits in the south of the City.`,
23:`WARP Corp’s District. Its Backstreets are called the Streets of Flavor, where cannibalism is openly practiced.`,
26:`This District exists, but it doesn’t show up on any map.`};
function finishDistrictRoll(){
 if(rollTimer){clearInterval(rollTimer);rollTimer=null}
 const d=S.district||1;
 const nestLine=(d<=3&&S.tags.includes('Nest-born'))?` The Nest here is far better than any other Nest.`:'';
 type($('#txt'),`District ${d}. `+(DIST[d]||`Not much is known about this District.`)+nestLine,()=>{ready=true;$('#next').style.visibility='visible'});
}
function roll(){
 if(rollTimer)clearInterval(rollTimer);
 const nestB=S.tags.includes('Nest-born');
 const d=nestB?(Math.random()<.04?1+Math.floor(Math.random()*3):4+Math.floor(Math.random()*23)):1+Math.floor(Math.random()*26);S.district=d;
 if(d<=3&&S.tags.includes('Nest-born'))S.tags.push('Top-tier Nest');
 $('#dlg').style.display='';$('#who span').textContent='District';$('#next').style.visibility='hidden';ready=false;
 let c=0;rollTimer=setInterval(()=>{
  $('#txt').textContent='Finding your District... '+(1+Math.floor(Math.random()*26));
  if(++c>14)finishDistrictRoll();
 },80);
}
/* ---------- engine ---------- */
function next(){
 i++;const n=script[i];if(!n){ready=false;return;}
 if(n.loc)$('#loc').textContent='Location: '+n.loc;
 if(n.k==='end'){fadeTo(toSoon);return}
 if(n.k==='homeHub'){fadeTo(()=>{B=null;closeEnemyPage();clearVN();showHub()});return}
 if(n.k==='roll'){roll();return}
 if(n.k==='ratsTalk'){ratsTalk();return}
 if(n.k==='battle'){fadeTo(()=>{if(n.bg)setBg(n.bg,true);clearVN();startBattle(n.encounter||'rats')});return}
 if(n.k==='resumeWave'){resumePendingWave();return}
 if(n.k==='missionEnd'){finishMission(n.id);return}
 if(n.k==='missionOutcome'){
  S.flags=S.flags||{};S.flags.pendingCanonicalOutcomes=S.flags.pendingCanonicalOutcomes||{};
  if(!window.CityCanon?.isMissionCompleted?.(S.flags,n.id)) S.flags.pendingCanonicalOutcomes[n.id]=n.outcome==='helped'?'helped':'fight';
  next();return;
 }
 if(n.k==='hanaReveal'){
  fadeTo(()=>{clearVN();$('#story').classList.remove('urban-myth-prologue');$('#story').classList.add('urban-myth-test');setBg('hana',true);$('#loc').textContent='Location: Hana Association — Examination Hall';$('#dlg').style.display='';$('#pick').style.display='none';ready=false;next();});return;
 }
 if(n.k==='urbanMythComplete'){
  S.flags=S.flags||{};S.flags.urbanMythPrologueSeen=true;S.flags.urbanMythStarted=true;
  if(!n.failed)S.flags.urbanMythExamCleared=true;
  $('#story').classList.remove('urban-myth-prologue','urban-myth-test');
  fadeTo(()=>{clearVN();showHub();$('#hubText').textContent=n.failed?'The exam attempt was not cleared. You can prepare at home and begin another attempt from the apartment.': `The Fairy Festival examination is recorded as complete. Your ${gradeTitle()} file and the broader Urban Myth evaluation remain under Hana Association review.`;saveSnapshot()});return;
 }
 if(n.k==='missionPost'){const mission=window.CANARD_MISSIONS?.[n.id];
  // Replays use the same in-world follow-up scene as the original reception.
  // Never insert meta narration about replaying or the fourth wall. Canonical fates
  // remain protected separately by CityCanon.commitMission.
  const post=mission?.post||mission?.postReplay;script=[...(post||[{k:'missionEnd',id:n.id}])];i=-1;ready=false;next();return}
 if(n.k==='fightHook'){fightHook(n);return}
 if(n.k==='fade'){fadeTo(()=>{clearVN();if(n.bg)setBg(n.bg,true);if(n.loc)$('#loc').textContent='Location: '+n.loc;ready=true;$('#next').style.visibility='visible'});return}
 if(n.bg)setBg(n.bg);
 $('#next').style.visibility='hidden';
 if(n.k==='in'||n.k==='ch'){
  clearVN();
  $('#dlg').style.display='none';
  const p=$('#pick');p.style.display='block';
  p.innerHTML=n.k==='in'?`<h2></h2><div class="row"><input maxlength="24" placeholder="Your name" aria-label="Your name"><button type="button" class="opt"><b>Confirm</b></button></div>`:`<h2></h2><div class="opts"></div>`;
  type(p.querySelector('h2'),n.p,()=>{
   if(n.k==='in'){
    const r=p.querySelector('.row');r.classList.add('show');const inp=r.querySelector('input');inp.focus();
    const ok=()=>{const v=inp.value.trim();if(!v)return;S.name=v;const joke=nameEasterEgg(v);if(joke)script.splice(i+1,0,{t:joke});p.style.display='none';next()};
    r.querySelector('button').onclick=ok;inp.onkeydown=e=>{e.stopPropagation();if(e.key==='Enter')ok()};
   }else{
    const o=p.querySelector('.opts');
    n.o.forEach(op=>{
     const b=document.createElement('button');b.type='button';b.className='opt';b.innerHTML=`<b>${op.t}</b>${op.d?`<small>${op.d}</small>`:''}`;
     b.onclick=()=>{
      if(n.key==='gender'){S.pronouns=op.pronouns||'they/them';S.gender=S.pronouns;S.bodyShape=S.pronouns.startsWith('he')?'male':(S.pronouns.startsWith('she')?'female':'bald');}
      if(op.flag){S.flags=S.flags||{};S.flags[op.flag]=op.value??true;}
      if(op.s)S.st[op.s]++;if(op.g)S.tags.push(op.g);
      if(op.tags)op.tags.forEach(t=>S.tags.push(t));
      if(op.bg)setBg(op.bg);
      p.style.display='none';
      if(op.route&&window.RAT_ROUTES&&window.RAT_ROUTES[op.route]){
       const chosen=Array.isArray(op.say)?op.say.join(' '):(op.say||op.t);
       const actionLine=op.narration===true||(/^\s*(you|your character)\b/i.test(chosen)&&op.speech!==true)?{t:chosen}:{who:S.name||'You',title:gradeTitle(),t:chosen};
       script=[actionLine,...window.RAT_ROUTES[op.route]];i=-1;ready=false;next();return;
      }
      if(op.route&&window.ROUTE_TABLE&&window.ROUTE_TABLE[op.route]){
       const chosen=Array.isArray(op.say)?op.say.join(' '):(op.say||op.t);
       const actionLine=op.narration===true||(/^\s*(you|your character)\b/i.test(chosen)&&op.speech!==true)?{t:chosen}:{who:S.name||'You',title:gradeTitle(),t:chosen};
       script=[actionLine,...window.ROUTE_TABLE[op.route]];i=-1;ready=false;next();return;
      }
      const lines=op.say?(Array.isArray(op.say)?op.say:[op.say]).map(t=>({t:'"'+t+'"'})):[{t:'"'+op.t+'"'}];
      const branch=op.go?(window.BR&&window.BR[op.go]):[];
      script.splice(i+1,0,...lines,...(Array.isArray(branch)?branch:[]));next();
     };o.appendChild(b);
    });
    o.classList.add('show');
   }
  });
  return;
 }
 $('#dlg').style.display='';
 const whoBox=$('#who');const whoEl=$('#who span');
 const rawText=String(n.t??'');
 const quoteMatch=rawText.match(/^\s*[\"“](.*?)[\"”]\s*$/s);
 const speaking=!!n.who&&n.who!=='Narrator'&&rawText.trim().length>0;
 const displayText=speaking?(quoteMatch?quoteMatch[1]:`“${rawText}”`):(quoteMatch?quoteMatch[1]:rawText);
 const isNarr=!speaking;
 whoBox.classList.toggle('narrator',isNarr);
 // clearStage: wipe all VN sprites (e.g. after Mo/Consta fall, before Arnold enters).
 if(n.clearStage)clearVN();
 if(isNarr){whoEl.textContent='';setSpeaker(null)}
 else{
  const title=n.title||'';
  whoEl.innerHTML=(title?`<small class="title">${escapeHTML(title)}</small>`:'')+escapeHTML(n.who);
  // Only enter this speaker now. Optional n.side: left | mid | right.
  // n.enter:false keeps them off-stage even if named (rare).
  if(n.enter===false)setSpeaker(null);
  else setSpeaker(n.who,n.side||null);
 }
 type($('#txt'),sub(displayText),()=>{
  // Brotherhood interlude: last Arnold line auto-starts wave 2 so the player cannot soft-lock.
  if(n.autoResumeWave&&B?.pendingWaveIndex!=null){
   ready=false;
   if($('#next'))$('#next').style.visibility='hidden';
   setTimeout(()=>resumePendingWave(),450);
   saveSnapshot();
   return;
  }
  ready=true;$('#next').style.visibility='visible';saveSnapshot();
 });
}
function advance(){
 if($('#pick')?.style.display==='block')return;
 // District roll can be clicked through immediately.
 if(rollTimer){finishDistrictRoll();saveSnapshot();return}
 // Fight-hook intro finished typing but battle fade stalled — force combat.
 if(S?._pendingFightHook&&!typing&&!fadeBusy){
  const enc=S._pendingFightHook;delete S._pendingFightHook;
  fadeTo(()=>{clearVN();startBattle(enc)});return;
 }
 // If interlude already finished typing its auto-resume line, force the handoff.
 if(B?.interludeActive&&B?.pendingWaveIndex!=null&&!typing){
  const cur=Array.isArray(script)?script[i]:null;
  if(cur?.autoResumeWave){resumePendingWave();return}
 }
 if(typing){complete();saveSnapshot();return}
 if(ready){ready=false;next();saveSnapshot()}
}
// System nodes that skip must not auto-loop past (player must land on them cleanly).
const SKIP_STOP_KEYS=new Set(['battle','resumeWave','missionEnd','homeHub','urbanMythComplete','hanaReveal','roll','ratsTalk','fightHook','in','ch','fade','end']);
// Skip jumps through plain dialogue only. Stops at choices and system keys so the story cannot soft-lock.
function skip(){
 if($('#pick')?.style.display==='block')return;
 if(rollTimer){finishDistrictRoll();}
 // Force pending fight into battle if the intro line is done or stuck.
 if(S?._pendingFightHook){
  complete();
  if(!typing){
   const enc=S._pendingFightHook;delete S._pendingFightHook;
   fadeTo(()=>{clearVN();startBattle(enc)});return;
  }
 }
 // Brotherhood interlude: skip can force the Arnold handoff.
 if(B?.interludeActive&&B?.pendingWaveIndex!=null){
  complete();
  const cur=Array.isArray(script)?script[i]:null;
  if(cur?.autoResumeWave||i>=(script?.length||0)-1){resumePendingWave();return}
 }
 if(fadeBusy){complete();return;}
 complete();
 let guard=0;
 while(guard++<200){
  if(fadeBusy)break;
  if($('#pick')?.style.display==='block')break;
  if(!$('#story')?.classList.contains('on'))break;
  if(!Array.isArray(script)||i>=script.length-1){
   if(!typing&&!ready){ready=true;if($('#next'))$('#next').style.visibility='visible';}
   break;
  }
  const cur=script[i]||null;
  if(cur?.autoResumeWave&&B?.pendingWaveIndex!=null){resumePendingWave();break}
  // ratsTalk is a one-shot stage cue: once it has run (ready), skip past it.
  if(cur?.k==='ratsTalk'&&ready){ready=false;next();complete();continue}
  // fightHook: run it once, then let the pending-battle path take over.
  if(cur?.k==='fightHook'){
   if(!S?._pendingFightHook){ready=false;next()}
   break;
  }
  // Choice / input panels must stop the skip loop.
  if(cur?.k==='ch'||cur?.k==='in')break;
  if(cur?.k&&SKIP_STOP_KEYS.has(cur.k)&&cur.k!=='ratsTalk')break;
  const upcoming=script[i+1];
  if(upcoming&&upcoming.k&&SKIP_STOP_KEYS.has(upcoming.k)){
   if(ready||!typing){ready=false;next()}
   break;
  }
  if(ready){ready=false;next();complete();continue}
  if(typing){complete();continue}
  ready=false;next();complete();
  break;
 }
 // Final recovery against soft-lock: re-enable advance if story is idle with no panel.
 if($('#story')?.classList.contains('on')&&$('#pick')?.style.display!=='block'&&!fadeBusy&&!typing&&!ready){
  const n=Array.isArray(script)?script[i]:null;
  if(!n||!n.k||n.k==='ratsTalk'){ready=true;if($('#next'))$('#next').style.visibility='visible';}
 }
 saveSnapshot();
}


/* ---------- VN dialogue sprites ---------- */
// Stage slots: left = already-known cast, mid = direct address / focus, right = new arrival.
const VN={
 pete:{spr:'pete',title:'Backstreets Rat — Leader'},
 lenny:{spr:'rata',title:'Backstreets Rat'},
 yun:{spr:'yun',title:'Office Operator'},
 eri:{spr:'eri',title:'Grade 8 Fixer'},
 finn:{spr:'finn',title:"Yun's Office — Grade 9 Fixer"},
 'mang chi':{spr:'ratb',title:'Backstreets Rat'},
 mo:{spr:'mo',title:'Brotherhood of Iron'},
 consta:{spr:'consta',title:'Brotherhood of Iron'},
 arnold:{spr:'arnold',title:'Brotherhood of Iron — Leader'},
 taein:{spr:'taein',title:'Hook Office'},
 mccullin:{spr:'mccullin',title:'Hook Office'},
 naoki:{spr:'naoki',title:'Hook Office'},
 zevelyn:{spr:'zevelyn',title:'Eden Office Fixer'},
 'han-ul':{spr:'hanUl',title:'Hana Association Examiner'}
};
let vnVisible=false;
// Only characters who have already entered the current scene (not the whole future script).
let vnPresent=[]; // [{id,key,spr,side}]
function spriteLabel(id){return String(id||'').replace(/[_-]+/g,' ').replace(/\b\w/g,m=>m.toUpperCase())}
function vnKey(who){return String(who||'').toLowerCase().trim().replace(/[’']/g,"'")}
function makeVnActor(id,spr,side){
 const d=document.createElement('div');
 d.className='vn dim vn-'+ (side||'left');
 d.dataset.id=id;d.dataset.side=side||'left';
 const img=document.createElement('img');img.src=window.__spr[spr]||`assets/sprites/${spr}.webp`;img.alt=spriteLabel(id);
 img.onerror=()=>d.remove();
 d.appendChild(img);return d;
}
function clearVN(){
 const box=$('#vnActors');if(box){box.innerHTML='';delete box.dataset.cast}
 const st=$('#vnStage');if(st){st.style.visibility='hidden';st.style.opacity='0';st.classList.remove('vn-has-mid','vn-has-right')}
 vnPresent=[];vnVisible=false;
}
function renderVNStage(){
 const box=$('#vnActors');const st=$('#vnStage');if(!box||!st)return;
 if(!vnPresent.length){box.innerHTML='';delete box.dataset.cast;st.style.visibility='hidden';st.style.opacity='0';vnVisible=false;return}
 st.style.visibility='visible';st.style.opacity='1';
 st.classList.toggle('vn-has-mid',vnPresent.some(x=>x.side==='mid'));
 st.classList.toggle('vn-has-right',vnPresent.some(x=>x.side==='right'));
 // Order on stage: left → mid → right
 const order={left:0,mid:1,right:2};
 const sorted=[...vnPresent].sort((a,b)=>(order[a.side]||0)-(order[b.side]||0));
 const signature=sorted.map(x=>x.id+':'+x.side+':'+x.spr).join('|');
 if(box.dataset.cast===signature)return;
 box.innerHTML='';
 sorted.forEach(x=>box.appendChild(makeVnActor(x.id,x.spr,x.side)));
 box.dataset.cast=signature;
 vnVisible=true;
}
// Enter a character only when the story actually reaches them.
// side: 'left' (known), 'mid' (direct focus), 'right' (new arrival). Default: first = left, later newcomers = right.
function enterVN(who,side){
 const key=vnKey(who);
 if(!key||key==='narrator'||key==='you'||key===String(S?.name||'').toLowerCase())return null;
 const cfg=VN[key]||VN[key.replace(/\s+/g,' ')];
 if(!cfg?.spr)return null;
 const id=key.replace(/\s+/g,'_');
 const existing=vnPresent.find(x=>x.id===id);
 if(existing){
  if(side&&existing.side!==side){existing.side=side;renderVNStage()}
  return existing;
 }
 let resolved=side;
 if(!resolved){
  if(!vnPresent.length)resolved='left';
  else if(!vnPresent.some(x=>x.side==='left'))resolved='left';
  else resolved='right'; // new face enters from the right
 }
 vnPresent.push({id,key,spr:cfg.spr,side:resolved});
 renderVNStage();
 return vnPresent[vnPresent.length-1];
}
function setSpeaker(who,side){
 if(!who){
  if(vnVisible)document.querySelectorAll('#vnActors .vn').forEach(el=>{el.classList.add('dim');el.classList.remove('talk')});
  return;
 }
 const key=vnKey(who);
 const cfg=VN[key]||VN[key.replace(/\s+/g,' ')];
 if(!cfg?.spr){
  if(vnVisible)document.querySelectorAll('#vnActors .vn').forEach(el=>{el.classList.add('dim');el.classList.remove('talk')});
  return;
 }
 enterVN(who,side);
 const id=key.replace(/\s+/g,'_');
 document.querySelectorAll('#vnActors .vn').forEach(el=>{
  const on=el.dataset.id===id;
  el.classList.toggle('talk',on);
  el.classList.toggle('dim',!on);
 });
}

/* ---------- combat data ---------- */
function diceStr(d){return d.map(x=>x.t[0].toUpperCase()+x.t.slice(1)+' '+x.lo+'–'+x.hi).join(' · ')}
function isDef(t){return t==='block'||t==='evade'}
// Level cap rises after Grade 8 promotion (Canard complete → Urban Myth / later receptions).
const PLAYER_LEVEL_CAP_BASE=30;
const PLAYER_LEVEL_CAP_PROMOTED=50;
const MISSION_LEVEL_REQUIREMENTS={yunOffice:8,brotherhood:13,hookOffice:18,urbanMythExam:22};
function playerLevelCap(){return S?.flags?.gradePromoted8?PLAYER_LEVEL_CAP_PROMOTED:PLAYER_LEVEL_CAP_BASE}
function playerLevel(){const cap=playerLevelCap();return Math.max(1,Math.min(cap,Math.floor(Number(S?.level)||1)))}
function playerGrade(){
 // Grade is narrative rank, separate from combat Level.
 // Starts at 9. Promoted to 8 after the three Canard office receptions are first-cleared.
 if(S?.flags?.gradePromoted8)return 8;
 return Math.max(1,Math.min(9,Math.floor(Number(S?.grade)||9)));
}
function gradeTitle(grade=playerGrade()){return `Grade ${grade} Fixer`}
function xpToNextLevel(level=playerLevel()){const cap=playerLevelCap();return level>=cap?0:100+Math.max(0,level-1)*25}
function scaledNominal(base,level,rate){return Math.max(1,Math.round((Number(base)||1)*(1+Math.max(0,(level||1)-1)*rate)))}
function equippedGear(){
 const body=S?.equipment?.body||{};return Object.values(body).filter(Boolean).map(id=>window.GEAR_DATA?.[id]).filter(Boolean);
}
function gearBonus(key){return equippedGear().reduce((sum,item)=>sum+(Number(item[key])||0),0)}
function keyPageVitals(keyPage=currentKeyPage(),level=playerLevel()){
 const baseHp=Number(keyPage.hp)||48,baseStagger=Number(keyPage.stagger)||26;
 const levelHp=scaledNominal(baseHp,level,.008),levelStagger=scaledNominal(baseStagger,level,.006);
 const hp=Math.max(1,Math.round(levelHp*(1+nameBuffValue('hpPercent')))+gearBonus('hpBonus'));
 const stagger=Math.max(1,Math.round(levelStagger*(1+nameBuffValue('staggerPercent')))+gearBonus('staggerBonus'));
 return {hp,stagger,hpBonus:hp-baseHp,staggerBonus:stagger-baseStagger};
}
function combatLevel(unit){return Math.max(1,Math.floor(Number(unit?.level)||(unit===B?.player?playerLevel():1)))}
function unitOffenseLevel(unit,page=null,die=null){
 const kp=unit===B?.player?currentKeyPage():null;
 return Math.max(1,combatLevel(unit)+(Number(kp?.offLevel)||0)+(Number(page?.offLevel)||0)+(Number(die?.offLevel)||0)+(Number(unit?.offLevel)||0)+(unit===B?.player?nameBuffValue('offenseLevel')+gearBonus('offLevel'):0));
}
function unitDefenseLevel(unit,page=null,die=null){
 const kp=unit===B?.player?currentKeyPage():null;
 return Math.max(1,combatLevel(unit)+(Number(kp?.defLevel)||0)+(Number(page?.defLevel)||0)+(Number(die?.defLevel)||0)+(Number(unit?.defLevel)||0)+(unit===B?.player?nameBuffValue('defenseLevel')+gearBonus('defLevel'):0));
}
function levelDamageMultiplier(attacker,attackPage,defender,defensePage=null,defenseDie=null,attackDie=null){
 if(!attacker||!defender)return 1;
 const off=unitOffenseLevel(attacker,attackPage,attackDie);
 const def=isDef(defenseDie?.t)?unitDefenseLevel(defender,defensePage,defenseDie):unitDefenseLevel(defender);
 const diff=off-def;
 const levelFactor=1+diff/(Math.abs(diff)+25);
 return attacker===B?.player?levelFactor*nameBuffMultiplier('damageMultiplier'):levelFactor;
}
function rollDie(d,unit=null){
 let v=d.lo+Math.floor(Math.random()*(d.hi-d.lo+1));
 if(unit){
  const offensive=!isDef(d.t);
  v+=unitStatus(unit,'strength');
  if(offensive)v-=unitStatus(unit,'disarm')+((statusCount(unit,'paralysis')>0)?unitStatus(unit,'paralysis'):0);
  if(unit===B?.player){
   for(const w of equippedWeapons()){
    if(d.t==='block'&&(w.blockBonus||0))v+=w.blockBonus;
    if(offensive&&(w.types||[]).includes(d.t))v+=w.attackBonus||0;
   }
   const passive=currentPassive();
   if(offensive&&passive.id==='corneredLeader'&&B.enemies.filter(e=>e.alive).length===1)v+=1;
  }
 }
 return Math.max(1,v);
}
function rollClashDie(d,unit,opponent,page=null,opponentPage=null,opponentDie=null){
 const own=isDef(d.t)?unitDefenseLevel(unit,page,d):unitOffenseLevel(unit,page,d);
 const theirs=opponentDie?(isDef(opponentDie.t)?unitDefenseLevel(opponent,opponentPage,opponentDie):unitOffenseLevel(opponent,opponentPage,opponentDie)):unitOffenseLevel(opponent,opponentPage);
 const levelPower=Math.max(0,Math.floor((own-theirs)/3));
 // Limbus Company rule: only the higher-level die gains +1 power per 3 level difference.
 return Math.max(1,rollDie(d,unit)+levelPower+(unit===B?.player?nameBuffValue('clashPower'):0));
}
function applyExperience(amount){
 ensureInventory();let remaining=Math.max(0,Math.floor((Number(amount)||0)*nameBuffMultiplier('expMultiplier')));if(!remaining)return {earned:0,levels:0};
 const before=keyPageVitals();S.level=playerLevel();S.exp=Math.max(0,Math.floor(Number(S.exp)||0));
 const cap=playerLevelCap();
 if(S.level>=cap){S.exp=0;return {earned:remaining,levels:0}}
 S.exp+=remaining;let levels=0;
 while(S.level<cap&&S.exp>=xpToNextLevel(S.level)){S.exp-=xpToNextLevel(S.level);S.level++;levels++}
 if(S.level>=cap)S.exp=0;
 const after=keyPageVitals();
 if(S.vitals){S.vitals.hp=Math.min(after.hp,Math.max(1,(Number(S.vitals.hp)||1)+after.hp-before.hp));S.vitals.stagger=Math.min(after.stagger,Math.max(1,(Number(S.vitals.stagger)||1)+after.stagger-before.stagger))}
 return {earned:remaining,levels};
}
function addWaitingDefense(unit,die,page){
 if(!unit||!isDef(die?.t))return;
 unit.defenseStances=Array.isArray(unit.defenseStances)?unit.defenseStances:[];
 unit.defenseStances.push({type:die.t,die:{...die},pageId:page?.id||null,pageName:page?.n||'Defense',roll:null,recycled:false});
}
function recoverStagger(unit,amount){if(!unit||amount<=0)return;unit.stagger=Math.min(unit.maxSt||unit.stagger,Math.max(0,unit.stagger||0)+Math.floor(amount))}
function blockStaggerAmount(unit,amount){return Math.max(0,Math.round(amount*(unit===B?.player?nameBuffMultiplier('blockStaggerMultiplier'):1)))}
function dealStaggerDamage(unit,amount){
 if(!unit||(!unit.alive&&unit!==B?.player))return;
 unit.stagger=Math.max(0,(unit.stagger||0)-Math.max(0,Math.floor(amount||0)));
 if(unit.stagger<=0&&!unit.stunned){unit.stagger=0;unit.stunned=true;unit.stunTurns=1;unit.staggeredThisScene=true;unit.defenseStances=[];logMsg(`${unit.name||S.name} is STAGGERED! The Scene that caused it does not consume the staggered turn.`)}
}
// Statuses use potency + count. A status's trigger/expiry rule depends on its type,
// but the battle UI deliberately uses icons instead of written status names.
const STATUS_DEFS={
 bleed:{label:'Bleed',icon:'🩸',lifecycle:'attack',hint:'Deals fixed HP damage when this unit rolls an offensive die; Count decreases on each trigger.'},
 rupture:{label:'Rupture',icon:'🗡️',lifecycle:'hit',hint:'Deals fixed HP damage when this unit is hit; Count decreases on each trigger.'},
 tremor:{label:'Tremor',icon:'🫨',lifecycle:'scene',hint:'Tremor Burst converts Potency into Stagger pressure; Count decreases at Scene end.'},
 charge:{label:'Charge',icon:'🔋',lifecycle:'scene',hint:'Charge Potency is spent by Charge-consuming pages; Count decreases at Scene end.'},
 strength:{label:'Strength',icon:'💪',lifecycle:'scene',hint:'Adds Potency to combat-die power until Count expires.'},
 haste:{label:'Haste',icon:'⚡',lifecycle:'scene',hint:'Adds Potency to Speed rolls until Count expires.'},
 paralysis:{label:'Paralysis',icon:'🌀',lifecycle:'die',hint:'Reduces offensive-die power by Potency; Count decreases on each affected offensive die.'},
 disarm:{label:'Disarm',icon:'🪓',lifecycle:'scene',hint:'Reduces offensive-die power by Potency until Count expires.'},
 protection:{label:'Protection',icon:'🛡️',lifecycle:'hit',hint:'Reduces incoming HP damage by Potency; Count decreases when hit.'},
 fragile:{label:'Fragile',icon:'💥',lifecycle:'hit',hint:'Increases incoming HP damage by Potency; Count decreases when hit.'},
 burn:{label:'Burn',icon:'🔥',lifecycle:'scene',hint:'Deals fixed HP damage equal to Potency at Scene end; Count decreases afterward.'}
};
const STATUS_LABELS=Object.fromEntries(Object.entries(STATUS_DEFS).map(([id,d])=>[id,d.label]));
function normalizeUnitStatuses(unit){
 if(!unit)return [];
 if(!Array.isArray(unit.statuses))unit.statuses=[];
 unit.statuses=unit.statuses.filter(Boolean).map(st=>{
  const {value,turns,...rest}=st;
  return {...rest,potency:Math.max(0,Math.floor(Number(st.potency??value)||0)),count:Math.max(0,Math.floor(Number(st.count??turns??1)||0))};
 }).filter(st=>st.potency>0&&st.count>0);
 return unit.statuses;
}
function getStatus(unit,id){return normalizeUnitStatuses(unit).find(st=>st.id===id&&st.potency>0&&st.count>0)||null}
function unitStatus(unit,id){return normalizeUnitStatuses(unit).filter(st=>st.id===id&&st.count>0).reduce((n,st)=>n+st.potency,0)}
function statusCount(unit,id){return normalizeUnitStatuses(unit).filter(st=>st.id===id&&st.count>0).reduce((n,st)=>n+st.count,0)}
function addStatus(unit,id,potency=1,count=1){
 if(!unit||!id||!STATUS_DEFS[id])return;
 potency=Math.max(0,Math.floor(Number(potency)||0));count=Math.max(0,Math.floor(Number(count)||0));
 if(potency<=0||count<=0)return;
 const statuses=normalizeUnitStatuses(unit);let st=statuses.find(x=>x.id===id);
 if(st){st.potency=Math.min(99,st.potency+potency);st.count=Math.min(99,st.count+count)}
 else statuses.push({id,potency:Math.min(99,potency),count:Math.min(99,count)});
}
function reduceStatusCount(unit,id,amount=1){
 const st=getStatus(unit,id);if(!st)return;
 st.count=Math.max(0,st.count-Math.max(1,Math.floor(Number(amount)||1)));
 unit.statuses=unit.statuses.filter(x=>x.count>0&&x.potency>0);
}
function consumeDiceStatus(unit,die){if(!unit||!die||isDef(die.t))return;reduceStatusCount(unit,'paralysis',1)}
function consumeHitStatuses(unit){reduceStatusCount(unit,'fragile',1);reduceStatusCount(unit,'protection',1)}
function statusTooltip(st){const d=STATUS_DEFS[st.id]||{label:st.id,hint:''};return `${d.label} · Potency ${st.potency} · Count ${st.count}. ${d.hint}`.trim()}
function statusMarkup(unit){
 const sts=normalizeUnitStatuses(unit);
 const tags=sts.map(st=>{const d=STATUS_DEFS[st.id]||{label:st.id,icon:'❔'};return `<span class="statusTag status-${escapeHTML(st.id)}" title="${escapeHTML(statusTooltip(st))}" aria-label="${escapeHTML(statusTooltip(st))}"><span aria-hidden="true">${d.icon}</span><small>${st.potency}·${st.count}</small></span>`});
 for(const stance of (unit?.defenseStances||[])){
  if(stance.type==='evade')tags.push(`<span class="statusTag status-evade" title="Evade stance remains active this Scene until it fails" aria-label="Evade stance">🌀</span>`);
  if(stance.type==='block')tags.push('<span class="statusTag status-block" title="Block is consumed by its first incoming attack this Scene" aria-label="Block stance">🛡️</span>');
 }
 return '<div class="statusRow" aria-label="Active status icons">'+tags.join('')+'</div>';
}
function effectIconInfo(fx){
 if(fx?.status&&STATUS_DEFS[fx.status]){const d=STATUS_DEFS[fx.status];return {icon:d.icon,title:`${d.label} · ${fx.potency??fx.value??1} Potency · ${fx.count??fx.duration??1} Count · ${fx.trigger||'effect'}`}}
 const typeMap={draw:{icon:'🃏',label:'Draw Combat Page'},restoreLight:{icon:'✨',label:'Restore Light'},heal:{icon:'💚',label:'Heal HP'},tremorBurst:{icon:'🫨',label:'Tremor Burst'},chargeBurst:{icon:'🔋',label:'Consume Charge for bonus damage'}};
 const d=typeMap[fx?.type];return d?{icon:d.icon,title:`${d.label} · ${fx.amount??''} · ${fx.trigger||'effect'}`.trim()}:null;
}
function effectIconsMarkup(page){
 const effects=(page?.effects||[]).map(effectIconInfo).filter(Boolean);const seen=new Set();
 return '<span class="pageEffectIcons">'+effects.filter(fx=>{const k=fx.icon+'|'+fx.title.split(' · ')[0];if(seen.has(k))return false;seen.add(k);return true}).map(fx=>`<span class="pageEffectIcon" title="${escapeHTML(fx.title)}" aria-label="${escapeHTML(fx.title)}">${fx.icon}</span>`).join('')+'</span>';
}
function currentKeyPage(){const id=S?.equipment?.keyPage||'grade9';return window.KEY_PAGES?.[id]||window.KEY_PAGES?.grade9||{id:'grade9',n:'Grade 9 Fixer',hp:48,stagger:26,res:{hp:{slash:1,pierce:1,blunt:1},st:{slash:1,pierce:1,blunt:1}}}}
function currentPassive(){return currentKeyPage().passive||{}}
function equippedWeapons(){return (S?.equipment?.weapons||[]).filter(Boolean).map(id=>window.WEAPON_DATA?.[id]).filter(Boolean)}
function plannedPageCost(){if(!B)return 0;return Object.values(B.assignments||{}).reduce((n,a)=>n+(window.PAGES[a.id]?.c||0),0)}
function markEnemyDown(unit,source='damage'){
 if(!unit||unit===B?.player||!('alive'in unit)||!unit.alive||unit.hp>0)return;
 unit.hp=0;unit.alive=false;unit.stunned=false;unit.defenseStances=[];
 if(B)B.expEarned=(B.expEarned||0)+20+combatLevel(unit)*15;
 logMsg(`${unit.name} is down (${source}).`);
}
function applyDirectStatusDamage(unit,amount,source){
 amount=Math.max(0,Math.floor(Number(amount)||0));if(!unit||amount<=0||unit.hp<=0||unit.alive===false)return 0;
 unit.hp=Math.max(0,unit.hp-amount);
 if(unit===B?.player)logMsg(`${unit.name||S.name} takes ${amount} ${source} damage.`);else markEnemyDown(unit,source);
 return amount;
}
function triggerAttackStatuses(unit,die){
 if(!unit||!die||isDef(die.t)||unit.hp<=0||unit.alive===false)return;
 const bleed=unitStatus(unit,'bleed');if(bleed>0&&statusCount(unit,'bleed')>0){applyDirectStatusDamage(unit,bleed,'Bleed');reduceStatusCount(unit,'bleed',1)}
}
function triggerHitStatuses(unit){
 if(!unit||unit.hp<=0||unit.alive===false)return;
 const rupture=unitStatus(unit,'rupture');if(rupture>0&&statusCount(unit,'rupture')>0){applyDirectStatusDamage(unit,rupture,'Rupture');reduceStatusCount(unit,'rupture',1)}
}
function applyPageEffects(page,target,trigger,attacker=B?.player,dmgType=null){
 if(!page||!target)return;
 for(const fx of page.effects||[]){if(fx.trigger!==trigger)continue;if(Math.random()>(fx.chance??1))continue;
  const recipient=fx.target==='self'?attacker:target;
  if(fx.status){addStatus(recipient,fx.status,fx.potency??fx.value??1,fx.count??fx.duration??1);continue}
  if(fx.type==='draw'){for(let i=0;i<Math.min(5,Math.max(0,Math.floor(fx.amount||1)));i++)drawPage();continue}
  if(fx.type==='restoreLight'){if(B)B.light=Math.min(B.maxLight,B.light+Math.max(0,Math.floor(fx.amount||1)));continue}
  if(fx.type==='heal'){if(recipient&&Number.isFinite(recipient.hp)){const max=recipient.maxHp||recipient.hp;recipient.hp=Math.min(max,recipient.hp+Math.max(0,Math.floor(fx.amount||1)))}continue}
  if(fx.type==='tremorBurst'){
   const tremor=unitStatus(target,'tremor');if(tremor>0){dealStaggerDamage(target,Math.max(1,Math.floor(tremor*(Number(fx.multiplier)||1))));logMsg(`${target.name||S.name} takes Tremor Burst pressure (${tremor}).`)}
   continue;
  }
  if(fx.type==='chargeBurst'){
   const charge=getStatus(attacker,'charge');if(charge){const spent=Math.min(charge.potency,Math.max(1,Math.floor(fx.amount||charge.potency)));reduceStatusCount(attacker,'charge',1);charge.potency=Math.max(0,charge.potency-spent);if(charge.potency<=0)attacker.statuses=attacker.statuses.filter(st=>st.id!=='charge');applyDirectStatusDamage(target,spent,'Charge');}
  }
 }
 const passive=currentPassive();
 if(attacker===B?.player&&trigger==='hit'){
  if(passive.id==='dirtyCut'&&dmgType==='pierce'&&!attacker.passiveUsedThisScene){addStatus(target,'bleed',1,1);attacker.passiveUsedThisScene=true;}
  if(passive.id==='shockRoutine'&&Math.random()<.25)addStatus(target,'paralysis',1,1);
 }
}
function tickStatuses(unit){
 if(!unit)return;const statuses=normalizeUnitStatuses(unit);
 for(const st of [...statuses]){
  const lifecycle=STATUS_DEFS[st.id]?.lifecycle||'scene';
  if(st.id==='burn')applyDirectStatusDamage(unit,st.potency,'Burn');
  if(lifecycle==='scene')reduceStatusCount(unit,st.id,1);
 }
 normalizeUnitStatuses(unit);
}

/* ---------- summary ---------- */
function toSoon(){ // now opens summary instead of dead end
 const st=S.st;ensureInventory();
 const home=S.tags.includes('Outskirts-born')?'Outskirts':(S.tags.includes('Nest-born')?'Nest':'Backstreets');const origin=S.tags.includes('Outskirts-born')?'Outskirts → Backstreets':(S.district?'District '+S.district+' · '+home:home);
 $('#sumMeta').innerHTML=`<b style="color:var(--ink)">${escapeHTML(S.name)}</b> · ${escapeHTML(S.pronouns||pronounLabel())}<br>${origin}<br>${S.tags.slice(0,6).join(' · ')}<br><br>You have been issued a <b style="color:var(--acc)">Grade 9 Fixer</b> license for a low-risk Backstreets job. A handful of Rats have been shaking down a corner near your route. Clear them out.`;
 $('#sumStats').innerHTML=['Might','Agility','Wit','Nerve'].map(k=>`<div class="stat"><b>${st[k]}</b><span>${k}</span></div>`).join('');
 {const sp=$('#sumPages');if(sp)sp.hidden=true;const tg=$('#shelfToggle');if(tg){tg.setAttribute('aria-expanded','false');tg.textContent='Combat Bookshelf ▸ (tap to view)'}}
 $('#sumPages').innerHTML=ISSUE_PAGES.map(id=>{
  const p=window.PAGES[id];
  return `<div class="pg"><b>${p.n}</b><small>Cost ${p.c} · ${diceStr(p.dice)} ${effectIconsMarkup(p)}</small></div>`;
 }).join('');
 show('summ');
}

/* ---------- chapter 2 story then battle ---------- */


function startJob(){
 ensureInventory();grantStarterInventory();S.pendingMission=null;S.flags.activeMission='rats';
 // Re-enter the original Rats story without meta replay commentary.
 script=[...window.JOB];
 fadeTo(()=>{clearVN();if(typing&&typing.t)clearTimeout(typing.t);typing=null;i=-1;ready=false;$('#dlg').style.display='';$('#pick').style.display='none';show('story');next()});
}

/* ---------- battle state ---------- */
let B=null,drag=null,previewPinned=false,previewDismissTimer=null,previewEnemyId=null;
// Queue hit reactions until after renderBattle replaces the affected DOM nodes.
const pendingEnemyHitFx=new Set();let pendingPlayerHitFx=false;

/* Ruina guest resistances (HP / Stagger multipliers by type) */
const RAT_RES={
 pete:{hp:{slash:1.5,pierce:1.0,blunt:2.0},st:{slash:1.5,pierce:1.0,blunt:2.0}},
 rata:{hp:{slash:1.0,pierce:2.0,blunt:1.5},st:{slash:1.0,pierce:2.0,blunt:1.5}}, // Lenny
 ratb:{hp:{slash:2.0,pierce:1.5,blunt:1.0},st:{slash:2.0,pierce:1.5,blunt:1.0}}  // Mang-chi
};
const RES_EMO={fatal:'☠️',weak:'⚠️',normal:'•',endure:'🛡️',ineffective:'⬜'};
function resLabel(mult){
 if(mult>=2)return RES_EMO.fatal+' Fatal';
 if(mult>=1.5)return RES_EMO.weak+' Weak';
 if(mult<=0.5)return RES_EMO.ineffective+' Ineffective';
 if(mult<1)return RES_EMO.endure+' Endured';
 return RES_EMO.normal+' Normal';
}
function resistLine(res){
 if(!res)return '';
 const h=res.hp||{},s=res.st||{};
 return `<div class="resistRow"><b>HP</b> ⚔️${resLabel(h.slash||1)} 🗡️${resLabel(h.pierce||1)} 🔨${resLabel(h.blunt||1)}<br><b>ST</b> ⚔️${resLabel(s.slash||1)} 🗡️${resLabel(s.pierce||1)} 🔨${resLabel(s.blunt||1)}</div>`;
}
function applyRes(amount,type,res,mode){
 if(!type||type==='block'||type==='evade')return amount;
 const table=(res&&res[mode])||{};
 const m=table[type]??1;
 return Math.max(0,Math.round(amount*m));
}
function emoNeed(level){return 3+level} // 0→1 needs 3, 1→2 needs 4 ...
function mkEmotion(){return {level:0,fill:0,maxLevel:5}}
function gainEmotion(unit,n){
 if(!unit.emo)unit.emo=mkEmotion();
 if(unit.emo.level>=unit.emo.maxLevel)return false;
 unit.emo.fill+=n;
 let up=false;
 while(unit.emo.level<unit.emo.maxLevel&&unit.emo.fill>=emoNeed(unit.emo.level)){
  unit.emo.fill-=emoNeed(unit.emo.level);
  unit.emo.level++;
  up=true;
 }
 return up;
}
function diceSlots(unit){
 // Emotion 0: 1 die. Each level adds a slot (cap 3 for this fight).
 const lv=(unit.emo&&unit.emo.level)||0;
 return Math.min(3,1+lv);
}
function mkEnemy(def){
 const res=def.res||RAT_RES[def.spr]||RAT_RES.pete,level=Math.max(1,Math.min(60,Math.floor(Number(def.level)||1)));
 const fixedAbnormality=def.passiveType==='fairyFestivalQueen';
 const hp=fixedAbnormality?Math.max(1,Number(def.hp)||1):scaledNominal(def.hp,level,.008),stagger=fixedAbnormality?Math.max(1,Number(def.stagger)||1):scaledNominal(def.stagger,level,.006);
 return {id:def.id,name:def.name,title:def.title,code:def.code||'',threat:def.threat||'',ability:def.ability||'',passiveType:def.passiveType||'',level,hp,maxHp:hp,stagger,maxSt:stagger,pages:def.pages||['shiv'],spr:def.spr,book:def.book,res,alive:true,
  speed:1+Math.floor(Math.random()*4),emo:mkEmotion(),stunned:false,stunTurns:0,staggeredThisScene:false,statuses:[],defenseStances:[],passiveUsedThisScene:false,ravenousnessTriggered:false,intent:null,intents:[],diceSpeeds:[],pageCursor:0};
}

function fightHook(n={}){
 const tags=S.tags||[];
 let line='Pete rolls his shoulder. The others stop pretending this is a conversation.';
 if(tags.includes('threat')) line='Pete’s smile dies. “Last warning,” he repeats. “All right.”';
 else if(tags.includes('bargain')) line='Pete laughs once. “You think this is a market?” The laugh is already gone.';
 else if(tags.includes('pride')) line='Pete steps in. “Then stop talking.”';
 else if(tags.includes('silent')) line='Your silence sits in the alley too long. Pete decides for both of you.';
 else if(tags.includes('calm')) line='“Messy it is,” Pete says, almost bored.';
 else if(tags.includes('direct')) line='Pete nods once, like he expected the line. “Then come take it.”';
 else if(tags.includes('observant')) line='Pete notices where you are looking. For the first time, his crew stops treating you like a nuisance.';
 $('#dlg').style.display='';$('#who').classList.add('narrator');$('#who span').textContent='';setSpeaker(null);ready=false;
 if($('#pick'))$('#pick').style.display='none';
 const goBattle=()=>{fadeTo(()=>{clearVN();startBattle(n.encounter||'rats')})};
 type($('#txt'),line,goBattle);
 // If typing never completes (or skip interrupts mid-line), still allow advance into battle.
 // Mark this node so skip/advance can force the handoff.
 S._pendingFightHook=n.encounter||'rats';
}

function pickEnemyPage(enemy){
 // Each enemy uses only the Combat Pages assigned to that guest in ENCOUNTERS.
 // Their assigned pages cycle in order; combat intent is not randomized from a shared pool.
 const pages=(enemy.pages||[]).map(id=>window.PAGES[id]).filter(Boolean);
 if(!pages.length)return null;
 if(!Number.isInteger(enemy.pageCursor)||enemy.pageCursor<0)enemy.pageCursor=0;
 const page=pages[enemy.pageCursor%pages.length];enemy.pageCursor++;
 return page;
}
function queueEnemyIntents(enemy){
 const count=Math.max(1,diceSlots(enemy));
 enemy.intents=Array.from({length:count},()=>pickEnemyPage(enemy)).filter(Boolean);
 enemy.intent=enemy.intents[0]||null;
 enemy.diceSpeeds=rollSpeeds(enemy);
 // Keep the intent queue and visible speed-die count identical after a load or level-up.
 if(enemy.intents.length<enemy.diceSpeeds.length){while(enemy.intents.length<enemy.diceSpeeds.length)enemy.intents.push(pickEnemyPage(enemy))}
 if(enemy.intents.length>enemy.diceSpeeds.length)enemy.intents=enemy.intents.slice(0,enemy.diceSpeeds.length);
 enemy.intent=enemy.intents[0]||enemy.intent;
}
function intentText(enemy){
 const all=enemy.intents?.length?enemy.intents:[enemy.intent].filter(Boolean);
 return all.map((p,i)=>`Speed ${i+1}: ${p.n} (${diceStr(p.dice)})`).join(' · ')||'No attack queued';
}
function getEncounterWaves(encounterId){
 const encounter=window.ENCOUNTERS?.[encounterId]||window.ENCOUNTERS?.rats;
 if(Array.isArray(encounter?.waves)&&encounter.waves.length)return encounter.waves;
 return [encounter?.enemies||[]];
}
function startBattle(encounterId='rats'){
 if(S)delete S._pendingFightHook;
 clearVN();closeEnemyPage();drag=null;ensureInventory();
 const might=S.st.Might|0,agi=S.st.Agility|0;
 const encounter=window.ENCOUNTERS?.[encounterId]||window.ENCOUNTERS?.rats;
 encounterId=window.ENCOUNTERS?.[encounterId]?encounterId:'rats';
 $('#battle').classList.toggle('urban-myth-exam',encounterId==='fairyFestival');
 const waves=getEncounterWaves(encounterId);
 const keyPage=currentKeyPage(),level=playerLevel(),scaled=keyPageVitals(keyPage,level);
 const baseHp=scaled.hp+might*2;
 const baseSt=scaled.stagger+agi*2;
 const stored=S.vitals&&Number.isFinite(S.vitals.hp)&&S.vitals.hp>0;
 const pages=(S.inventory.pages||[]).filter(p=>p.equipped).slice(0,9).map(p=>p.id).filter(id=>window.PAGES[id]);
 if(!pages.length)pages.push('evade','lightAtk','lightDef','thrust','lightAtk');
 B={encounterId,missionId:encounterId==='fairyFestival'?'urbanMythExam':(S.flags?.activeMission||(encounterId==='rats'?'rats':encounterId)),encounterName:encounter.name,
  waves,waveIndex:0,totalEnemies:waves.reduce((n,w)=>n+w.length,0),kills:0,bookDrops:[],won:false,
  scene:1,light:3,maxLight:3,
  player:{name:S.name,level,hp:stored?Math.min(baseHp,S.vitals.hp):baseHp,maxHp:baseHp,stagger:stored?Math.min(baseSt,S.vitals.stagger??baseSt):baseSt,maxSt:baseSt,
    speed:1+Math.floor(Math.random()*4),emo:mkEmotion(),stunned:false,stunTurns:0,staggeredThisScene:false,defenseStances:[],res:keyPage.res||{hp:{slash:1,pierce:1,blunt:1},st:{slash:1,pierce:1,blunt:1}},statuses:[],keyPage:keyPage.id,passiveUsedThisScene:false},
  deck:pages.slice(0,9),hand:[],discard:[],
  enemies:(waves[0]||[]).map(def=>mkEnemy(def)),target:null,selectedPage:null,assignments:{},busy:false,expEarned:0,pendingWaveIndex:null,interludeActive:false
 };
 // Brotherhood wave 1 must always be Mo + Consta together (never sequential single spawns).
 if(encounterId==='brotherhood'){
  const wave0=waves[0]||[];
  if(wave0.length<2){
   const roster=window.ENCOUNTERS.brotherhood;
   B.waves=[[...(roster.enemies||[])],[(roster.waves&&roster.waves[1]&&roster.waves[1][0])].filter(Boolean)];
   if(!B.waves[1].length&&window.ENCOUNTERS.brotherhood){
    /* keep existing waves if recovery fails */
   }
   B.enemies=(B.waves[0]||[]).map(def=>mkEnemy(def));
   B.totalEnemies=B.waves.reduce((n,w)=>n+w.length,0);
  }
 }
 B.enemies.forEach(queueEnemyIntents);
 B.player.diceSpeeds=rollSpeeds(B.player);
 for(let k=0;k<5;k++)drawPage();
 applyEmotionBonuses();
 if(encounterId==='brotherhood')applyBattleBackground('back');
 else applyBattleBackground(currentBg||'back');
 renderBattle();show('battle');saveSnapshot();
 const names=(B.enemies||[]).map(e=>e.name).join(' & ');
 logMsg(encounterId==='brotherhood'
  ?`Wave 1 — ${names||'Mo & Consta'} enter together. Defeat both to clear this stage.`
  :'Each enemy shows its queued page. Tap an intent card or speed die to inspect it, select a page, then assign it. Staggered foes can be attacked directly.');
}

function rollSpeeds(unit){
 const n=diceSlots(unit),haste=unitStatus(unit,'haste');
 return Array.from({length:n},()=>1+Math.floor(Math.random()*4)+haste);
}
function applyEmotionBonuses(){
 if(!B)return;const lv=B.player.emo.level;B.maxLight=3+lv;B.light=Math.min(B.maxLight,3+lv);
}
function onEmotionUp(who){
 if(who==='player'){
  // Each new player Emotion Level adds one Light to the current pool (up to the new cap),
  // not a full refill, so leveling cannot accidentally refund every spent page.
  B.maxLight=3+B.player.emo.level;
  B.light=Math.min(B.maxLight,B.light+1);
  drawPage();
  logMsg(`Emotion Level ${B.player.emo.level}! +1 Light, one extra draw, and another possible speed die next Scene.`);
  B.player.diceSpeeds=rollSpeeds(B.player);
 }else{
  logMsg(`${who.name} reaches Emotion Level ${who.emo.level}.`);
 }
}


function drawPage(){
 if(!B.deck.length){
  if(!B.discard.length)return;
  B.deck=B.discard.splice(0).sort(()=>Math.random()-0.5);
 }
 if(B.hand.length>=5)return;
 B.hand.push(B.deck.shift());
}

function logMsg(t){const el=$('#bLog');el.textContent=t}

function renderBattle(){
 if(!B)return;
 const list=$('#enemyList');list.innerHTML='';
 const actors=$('#bActors');actors.innerHTML='';
 B.enemies.forEach(e=>{
  const card=document.createElement('div');
  card.className='unitCard'+(B.target===e.id?' on':'')+(e.alive?'':' dead')+(e.stunned?' stunned':'');
  card.dataset.enemy=e.id;
  const emo=e.emo||mkEmotion(),need=emoNeed(emo.level),emoPct=emo.level>=emo.maxLevel?100:Math.min(100,(emo.fill/need)*100),intents=e.intents?.length?e.intents:[e.intent].filter(Boolean);
  card.innerHTML=`<div class="nm">${escapeHTML(e.name)}${e.stunned?' ⚡STAGGERED':''}</div><div class="tl">${escapeHTML(e.title)} · Lv ${combatLevel(e)} · OFF ${unitOffenseLevel(e)} / DEF ${unitDefenseLevel(e)}${e.code?`<br>CODE ${escapeHTML(e.code)} · THREAT ${escapeHTML(e.threat||'UNKNOWN')}`:''}${e.ability?`<br>ABILITY ${escapeHTML(e.ability)}`:''}</div>
   <div class="intentCard" role="button" tabindex="0" aria-label="Inspect ${escapeHTML(e.name)}'s intended attacks"><b>QUEUED ATTACKS · ${intents.length}</b>${intents.map((p,i)=>`<div class="intentLine"><b>${i+1}. ${escapeHTML(p.n)}</b><br>${escapeHTML(diceStr(p.dice))}${effectIconsMarkup(p)}</div>`).join('')}<small>Tap to inspect · tap a speed die to view its exact page</small></div>
   <div class="hpRow">HP ${Math.max(0,e.hp)}/${e.maxHp}</div><div class="hpBar"><i style="width:${Math.max(0,e.hp)/e.maxHp*100}%"></i></div>
   <div class="hpRow">Stagger ${Math.max(0,e.stagger)}/${e.maxSt}</div><div class="hpBar stBar"><i style="width:${Math.max(0,e.stagger)/e.maxSt*100}%"></i></div>
   <div class="emoLbl">Emotion Lv ${emo.level} · ${emo.level>=emo.maxLevel?'MAX':emo.fill+'/'+need}</div><div class="emoBar"><i style="width:${emoPct}%"></i></div>
   ${statusMarkup(e)}${resistLine(e.res)}`;
  card.onclick=ev=>{
   if(ev.target.closest('.intentCard')){ev.stopPropagation();if(!e.alive)return;if(e.stunned&&B.selectedPage){tryAssignStaggeredPage(B.selectedPage.id+'@'+B.selectedPage.hi,e.id);return}if(e.stunned){B.target=e.id;logMsg(e.name+' is staggered. Select a Combat Page, then tap this card or the character to attack without a clash.');renderBattle();return}showEnemyPage(e.id,card,true,0);return;}
   if(!e.alive)return;
   if(B.selectedPage){if(e.stunned)tryAssignStaggeredPage(B.selectedPage.id+'@'+B.selectedPage.hi,e.id);else{let di=0;while(Object.prototype.hasOwnProperty.call(B.assignments||{},e.id+'#'+di)&&di<diceSlots(B.player))di++;if(di<diceSlots(B.player))tryAssignToDie(B.selectedPage.id+'@'+B.selectedPage.hi,e.id,di);else{B.target=e.id;renderBattle();logMsg('All your attack slots are assigned. Tap a speed die to replace or inspect an assignment.')}}}
   else {B.target=e.id;renderBattle()}
  };
  const inspect=card.querySelector('.intentCard');inspect.onclick=ev=>{ev.stopPropagation();if(!e.alive)return;if(e.stunned&&B.selectedPage){tryAssignStaggeredPage(B.selectedPage.id+'@'+B.selectedPage.hi,e.id);return}if(e.stunned){B.target=e.id;logMsg(e.name+' is staggered. Select a Combat Page, then tap here to attack without a clash.');renderBattle();return}showEnemyPage(e.id,card,true,0)};inspect.onkeydown=ev=>{if(ev.key==='Enter'||ev.key===' '){ev.preventDefault();inspect.click()}};
  list.appendChild(card);

  const act=document.createElement('div');
  act.className='actor'+(e.alive?'':' dead')+(e.stunned?' staggered':'')+(B.target===e.id?' selected talk':(B.target?' dim':''));
  act.dataset.id=e.id;
  const speeds=e.diceSpeeds||[e.speed||1];
  const diceHtml=speeds.map((sp,di)=>{
    const key=e.id+'#'+di,assigned=B.assignments&&B.assignments[key];
    const cls='spdDie'+(assigned?' assigned lit':(B.selectedPage?' lit':''));
    return `<button type="button" class="${cls}" data-enemy="${escapeHTML(e.id)}" data-die="${di}" ${!e.alive?'disabled':''} title="${e.stunned?'Staggered — direct attack target':'Speed '+sp+' · '+((e.intents||[e.intent]).filter(Boolean)[di]?.n||'Queued attack')}">${sp}</button>`;
  }).join('');
  act.innerHTML=`<div class="spdRow">${diceHtml}</div><div class="staggerMark"><img src="assets/icon/stagger.webp" alt="Staggered"></div><img class="actorSprite" src="${escapeHTML(cssSpr(e.spr)||'')}" alt="${escapeHTML(e.name)}">`;
  const sprite=act.querySelector('.actorSprite');sprite.onerror=()=>sprite.remove();
  act.querySelectorAll('.spdDie').forEach(btn=>{
   btn.onclick=ev=>{ev.stopPropagation();if(B.busy||!e.alive)return;const di=+btn.dataset.die;if(e.stunned){if(B.selectedPage)tryAssignStaggeredPage(B.selectedPage.id+'@'+B.selectedPage.hi,e.id);else{B.target=e.id;logMsg(e.name+' is staggered. Select a Combat Page, then tap this target to attack without a clash.');renderBattle()}return}if(B.selectedPage)tryAssignToDie(B.selectedPage.id+'@'+B.selectedPage.hi,e.id,di);else if(previewPinned&&previewEnemyId===e.id)closeEnemyPage();else showEnemyPage(e.id,btn,true,di)};
   btn.onpointerenter=ev=>{const hoveredDie=Number(btn.dataset.die)||0;if(ev.pointerType==='mouse'&&!previewPinned&&!B.selectedPage&&e.alive&&!e.stunned)showEnemyPage(e.id,btn,false,hoveredDie)};
   btn.onpointerleave=ev=>{if(ev.pointerType==='mouse'&&!previewPinned)scheduleEnemyPageClose()};
  });
  act.onclick=()=>{if(B.busy||!e.alive)return;if(B.selectedPage){if(e.stunned)tryAssignStaggeredPage(B.selectedPage.id+'@'+B.selectedPage.hi,e.id);else{let di=0;while(Object.prototype.hasOwnProperty.call(B.assignments||{},e.id+'#'+di)&&di<diceSlots(B.player))di++;if(di<diceSlots(B.player))tryAssignToDie(B.selectedPage.id+'@'+B.selectedPage.hi,e.id,di);else{B.target=e.id;if(e.intent)showEnemyPage(e.id,act,true,0);renderBattle();logMsg('All attack slots are assigned; tap a speed die to inspect or replace one.')}}}else{B.target=e.id;if(e.intent)showEnemyPage(e.id,act,true,0);renderBattle()}};
  actors.appendChild(act);
 });
 const p=B.player,pemo=p.emo||mkEmotion(),pneed=emoNeed(pemo.level),pemoPct=pemo.level>=pemo.maxLevel?100:Math.min(100,(pemo.fill/pneed)*100);
 const keyPage=currentKeyPage();
 $('#playerPanel').innerHTML=`<div class="unitCard on ${p.stunned?'stunned':''}"><div class="nm">${escapeHTML(p.name)}${p.stunned?' ⚡STAGGERED':''}</div><div class="tl">${escapeHTML(keyPage.n||'Grade 9 Fixer')} · Lv ${combatLevel(p)} · OFF ${unitOffenseLevel(p)} / DEF ${unitDefenseLevel(p)}</div>
  <div class="hpRow">HP ${p.hp}/${p.maxHp}</div><div class="hpBar"><i style="width:${Math.max(0,p.hp)/p.maxHp*100}%"></i></div>
  <div class="hpRow">Stagger ${Math.max(0,p.stagger)}/${p.maxSt}</div><div class="hpBar stBar"><i style="width:${Math.max(0,p.stagger)/p.maxSt*100}%"></i></div>
  <div class="emoLbl">Emotion Lv ${pemo.level} · ${pemo.level>=pemo.maxLevel?'MAX':pemo.fill+'/'+pneed}</div><div class="emoBar"><i style="width:${pemoPct}%"></i></div>
  ${statusMarkup(p)}<div class="hpRow" style="margin-top:.6vh">Speed dice ×${diceSlots(p)}</div></div>`;
 const strip=$('#enemyStripList');
 if(strip)strip.innerHTML=B.enemies.map(e=>{
  if(!e.alive)return `<div class="unitCard dead"><div class="miniRow"><span>${escapeHTML(e.name)}</span><span>DOWN</span></div></div>`;
  return `<div class="unitCard${e.stunned?' stunned':''}" data-enemy="${escapeHTML(e.id)}"><div class="miniRow"><span>${escapeHTML(e.name)}${e.stunned?' ⚡':''}</span><span>${Math.max(0,e.hp)}/${e.maxHp}</span></div><div class="hpBar"><i style="width:${Math.max(0,e.hp)/e.maxHp*100}%"></i></div><div class="hpBar stBar" style="margin-top:2px"><i style="width:${Math.max(0,e.stagger)/e.maxSt*100}%"></i></div>${statusMarkup(e)}</div>`;
 }).join('');
 const consumableHost=$('#bConsumables');
 if(consumableHost){
  const items=ensureInventory().consumables.filter(c=>c&&c.count>0&&!String(c.id).startsWith('exp_ticket_'));
  consumableHost.innerHTML=items.length?`<span class="combatConsumableLabel">SUPPLIES ↔</span>`+items.map(c=>`<button type="button" class="combatConsumable" data-combat-consume="${escapeHTML(c.id)}" ${B.busy||B.player.hp<=0?'disabled':''}><b>${escapeHTML(c.n)}</b><span>×${c.count}</span></button>`).join(''):'<span class="combatConsumableLabel">NO SUPPLIES</span>';
  consumableHost.querySelectorAll('[data-combat-consume]').forEach(btn=>btn.onclick=()=>consumeCombatItem(btn.dataset.combatConsume));
 }
 const plannedLight=Object.values(B.assignments||{}).reduce((n,a)=>n+(window.PAGES[a.id]?.c||0),0);
 const lightDots=$('#bLightDots');if(lightDots){lightDots.innerHTML='';for(let x=0;x<B.maxLight;x++){const dot=document.createElement('i');dot.className='lightHex'+(x<B.light?' filled':'');if(x>=Math.max(0,B.light-plannedLight)&&x<B.light)dot.classList.add('planned');dot.setAttribute('aria-hidden','true');lightDots.appendChild(dot)}}
 const lc=$('#bLightCount');if(lc)lc.textContent=`${B.light}/${B.maxLight}${plannedLight?` · ${plannedLight} planned`:''}`;
 const scene=$('#bSceneNum');if(scene)scene.textContent=String(B.scene);
 const kills=$('#bKills');if(kills)kills.textContent=`${Math.min(B.totalEnemies,(B.kills||0)+B.enemies.filter(e=>!e.alive).length)}/${B.totalEnemies||B.enemies.length}`;
 const hand=$('#bHand');hand.classList.toggle('playerStaggered',!!p.stunned);hand.innerHTML='';
 if(p.stunned){hand.innerHTML='<div class="handMessage">STAGGERED — cannot play pages this Scene</div>'}
 else{
  B.hand.forEach((id,hi)=>{
   const pg=window.PAGES[id];if(!pg)return;
   const assignedTo=B.assignments&&Object.values(B.assignments).some(a=>a.id===id&&a.hi===hi);
   const el=document.createElement('div');el.className='card'+(assignedTo?' assigned':'');el.draggable=true;
   const targetName=assignedTo?(()=>{for(const k of Object.keys(B.assignments)){const a=B.assignments[k];if(a.id===id&&a.hi===hi){const eid=k.split('#')[0];return B.enemies.find(en=>en.id===eid)?.name}}return ''})():'';
   el.innerHTML=`<div class="cn">${escapeHTML(pg.n)}</div><div class="cc">Cost ${pg.c}</div><div class="cd">${diceStr(pg.dice)}</div>${effectIconsMarkup(pg)}${targetName?`<div class="assignedLabel">→ ${escapeHTML(targetName)}</div>`:''}`;
   el.onclick=ev=>{ev.stopPropagation();if(B.busy||B.player.stunned)return;if(pg.c>B.light){logMsg('Not enough Light.');return}const same=B.selectedPage&&B.selectedPage.id===id&&B.selectedPage.hi===hi;document.querySelectorAll('#bHand .card').forEach(c=>c.classList.remove('pulled','drag'));if(same){const assignedKeys=Object.keys(B.assignments||{}).filter(k=>B.assignments[k].id===id&&B.assignments[k].hi===hi);if(assignedKeys.length){assignedKeys.forEach(k=>delete B.assignments[k]);B.selectedPage=null;drag=null;logMsg('Assigned page cancelled and returned to the hand. Choose a new target or page.')}else{B.selectedPage=null;drag=null;logMsg('Selection cleared.')}updatePlanButton();renderBattle();saveSnapshot();return}B.selectedPage={id,hi};drag={id,hi};requestAnimationFrame(()=>requestAnimationFrame(()=>el.classList.add('pulled')));logMsg('Page selected — tap an enemy speed die, or a staggered enemy itself.');updatePlanButton();saveSnapshot()};
   hand.appendChild(el);if(B.selectedPage&&B.selectedPage.id===id&&B.selectedPage.hi===hi)requestAnimationFrame(()=>requestAnimationFrame(()=>el.classList.add('pulled')));
  });
 }
 updatePlanButton();
}
function parseHandToken(token){
 const [id,raw]=token.split('@');const hi=Number(raw);const idx=Number.isInteger(hi)&&B.hand[hi]===id?hi:B.hand.indexOf(id);return {id,hi:idx,pg:window.PAGES[id]};
}
function assignmentBaseWithout(id,hi){
 const next={...(B.assignments||{})};for(const key of Object.keys(next)){if(next[key].id===id&&next[key].hi===hi)delete next[key]}return next;
}
function tryAssignToDie(token,enemyId,dieIndex){
 if(B.busy||B.player.stunned)return;
 const {id,hi,pg}=parseHandToken(token);if(hi<0||!pg)return;
 const en=B.enemies.find(e=>e.id===enemyId&&e.alive);if(!en)return;
 if(en.stunned){tryAssignStaggeredPage(token,enemyId);return}
 const key=enemyId+'#'+dieIndex;
 let temp=assignmentBaseWithout(id,hi);
 const slotUsed=Object.prototype.hasOwnProperty.call(temp,key);
 if(!slotUsed&&Object.keys(temp).length>=diceSlots(B.player)){logMsg(`Your Emotion Level allows ${diceSlots(B.player)} assigned page(s) this Scene.`);return}
 const oldAtKey=temp[key];temp[key]={id,hi};
 const total=Object.values(temp).reduce((n,a)=>n+(window.PAGES[a.id]?.c||0),0);
 if(total>B.light){logMsg('Those assignments need more Light than you have.');return}
 B.assignments=temp;B.selectedPage=null;drag=null;B.target=enemyId;closeEnemyPage();renderBattle();saveSnapshot();
 logMsg(`${pg.n} → ${en.name} speed die ${dieIndex+1}.`);
}
function tryAssignStaggeredPage(token,enemyId){
 if(B.busy||B.player.stunned)return;
 const {id,hi,pg}=parseHandToken(token);if(hi<0||!pg)return;
 const en=B.enemies.find(e=>e.id===enemyId&&e.alive&&e.stunned);if(!en)return;
 let temp=assignmentBaseWithout(id,hi);
 // Allow multiple speed-slot actions to punish one staggered target, each as a separate unopposed page.
 let n=0;while(Object.prototype.hasOwnProperty.call(temp,enemyId+'#S'+n))n++;const key=enemyId+'#S'+n;
 if(!Object.prototype.hasOwnProperty.call(temp,key)&&Object.keys(temp).length>=diceSlots(B.player)){logMsg(`Your Emotion Level allows ${diceSlots(B.player)} assigned page(s) this Scene.`);return}
 temp[key]={id,hi};
 const total=Object.values(temp).reduce((n,a)=>n+(window.PAGES[a.id]?.c||0),0);if(total>B.light){logMsg('Those assignments need more Light than you have.');return}
 B.assignments=temp;B.selectedPage=null;drag=null;B.target=enemyId;closeEnemyPage();renderBattle();saveSnapshot();logMsg(`${pg.n} → ${en.name} (unopposed: STAGGERED).`);
}

function showEnemyPage(enemyId,anchor=null,pin=false,dieIndex=0){
 const enemy=B&&B.enemies.find(e=>e.id===enemyId&&e.alive);
 const host=$('#enemyPagePreview');if(!host||!enemy)return;
 const queued=enemy.intents?.length?enemy.intents:[enemy.intent].filter(Boolean);
 const pg=queued[dieIndex]||queued[0];if(!pg)return;
 if(previewDismissTimer){clearTimeout(previewDismissTimer);previewDismissTimer=null}
 previewEnemyId=enemyId;previewPinned=!!pin;
 host.innerHTML=`<button type="button" class="previewClose" aria-label="Close attack preview">×</button>
  <div class="previewKicker">${escapeHTML(enemy.name)} · SPEED DIE ${dieIndex+1}</div>
  <div class="card previewCard"><div class="cn">${escapeHTML(pg.n)}</div><div class="cc">Enemy attack · Cost ${pg.c??'—'}</div><div class="cd">${escapeHTML(diceStr(pg.dice))}</div>${effectIconsMarkup(pg)}<div class="previewDice">${pg.dice.map((d,i)=>`<div class="previewDie"><span>${i+1}</span><b>${escapeHTML(d.t.toUpperCase())}</b><strong>${d.lo}–${d.hi}</strong></div>`).join('')}</div></div>
  <div class="previewHint">This exact page is queued for speed die ${dieIndex+1} this Scene.</div>`;
 const mid=$('#bStage');
 if(anchor&&mid){
  const mr=mid.getBoundingClientRect(),ar=anchor.getBoundingClientRect();
  const w=Math.min(260,mr.width*.44),h=Math.min(mr.height*.48,285);
  const enemyIndex=B.enemies.findIndex(e=>e.id===enemyId);
  let left=enemyIndex>=2?mr.width-w-8:8;
  let top=ar.top-mr.top+Math.min(ar.height,22);
  const safeBottom=mr.height-window.innerHeight*.30-8;
  top=Math.max(8,Math.min(top,safeBottom-h));
  host.style.left=left+'px';host.style.top=top+'px';host.style.width=w+'px';
 }else{host.style.left='50%';host.style.top='8%';host.style.width='min(260px, 42vw)'}
 host.classList.add('on');host.setAttribute('aria-hidden','false');
 host.onpointerenter=()=>{if(previewDismissTimer){clearTimeout(previewDismissTimer);previewDismissTimer=null}};
 host.onpointerleave=()=>{if(!previewPinned)scheduleEnemyPageClose()};
 host.querySelector('.previewClose').onclick=()=>closeEnemyPage();
}
function scheduleEnemyPageClose(){
 if(previewDismissTimer)clearTimeout(previewDismissTimer);
 previewDismissTimer=setTimeout(()=>{if(!previewPinned)closeEnemyPage()},220);
}
function closeEnemyPage(){
 if(previewDismissTimer){clearTimeout(previewDismissTimer);previewDismissTimer=null}
 previewPinned=false;previewEnemyId=null;
 const host=$('#enemyPagePreview');if(host){host.classList.remove('on');host.setAttribute('aria-hidden','true')}
}
function cssSpr(k){return window.__spr[k]||(k?`assets/sprites/${k}.webp`:'')}

function tryClash(token,enemyId){
 // Legacy body-click assign → die 0
 tryAssignToDie(token, enemyId, 0);
}
function updatePlanButton(){
 const b=$('#bStartClash');if(!b)return;
 const maxA=B?diceSlots(B.player):1,count=B&&B.assignments?Object.keys(B.assignments).length:0;
 const staggered=!!(B&&B.player&&B.player.stunned);
 const can=!B?.busy&&(staggered||count>0);
 b.classList.toggle('ready',can);b.disabled=!can;
 const label=$('#bStartClashLabel');if(label)label.textContent=staggered?'END STAGGERED SCENE':(count?`START CLASH · ${count}/${maxA}`:'ASSIGN A PAGE');
 b.title='Review the queued enemy pages, assign your combat pages, then resolve the Scene.';
}

async function startPlannedClashes(){
 if(!B||B.busy)return;
 if(B.player.stunned){
  B.busy=true;updatePlanButton();closeEnemyPage();let ended=false;
  for(const en of B.enemies){if(!en.alive||en.stunned||B.player.hp<=0)continue;const intents=en.intents?.length?en.intents:[en.intent].filter(Boolean);for(let di=0;di<intents.length;di++){await resolveEnemyAttack(en,intents[di],di);renderBattle();flushHitFx();ended=checkEnd();if(ended)break;}if(ended)break;}
  B.assignments={};B.selectedPage=null;drag=null;B.busy=false;renderBattle();updatePlanButton();if(!ended&&!checkEnd())endScene();saveSnapshot();return;
 }
 const assignments=B.assignments||{},keys=Object.keys(assignments);if(!keys.length){logMsg('Assign at least one Combat Page first.');return}
 const resolvedKeys=new Set();
 B.busy=true;updatePlanButton();closeEnemyPage();let ended=false;
 try{
  for(const key of keys){
   const [enemyId,rawDie]=key.split('#'),dieIndex=Number(rawDie),en=B.enemies.find(e=>e.id===enemyId&&e.alive),a=assignments[key];
   if(!en||!a||B.player.hp<=0)continue;
   const idx=B.hand[a.hi]===a.id?a.hi:B.hand.indexOf(a.id);if(idx<0)continue;
   const pg=window.PAGES[a.id];if(!pg||pg.c>B.light)continue;
   B.light-=pg.c;B.hand.splice(idx,1);B.discard.push(a.id);
   for(const k2 of keys){if(assignments[k2]&&assignments[k2].hi>idx)assignments[k2].hi--}
   applyPageEffects(pg,B.player,'use',B.player);
   if(en.stunned||/#S\d*$/.test(key)){
    logMsg(`${S.name}: ${pg.n} → ${en.name} (Staggered)`);await resolveStaggeredAttack(pg,en);
   }else{
    const ep=(en.intents||[])[dieIndex]||en.intent||pickEnemyPage(en);
    logMsg(`${S.name}: ${pg.n} vs ${en.name}: ${ep.n} (speed die ${dieIndex+1})`);await resolveClash(pg,ep,en);
   }
   resolvedKeys.add(key);
   renderBattle();flushHitFx();ended=checkEnd();if(ended||B.player.stunned)break;
  }
  // Every enemy speed die not answered by a player page resolves as an unopposed attack.
  if(!ended){
   for(const en of B.enemies){
    if(!en.alive||en.stunned||B.player.hp<=0)continue;
    const intents=en.intents?.length?en.intents:[en.intent].filter(Boolean);
    for(let di=0;di<intents.length;di++){
     if(resolvedKeys.has(en.id+'#'+di))continue;
     await resolveEnemyAttack(en,intents[di],di);renderBattle();flushHitFx();ended=checkEnd();if(ended)break;
    }
    if(ended)break;
   }
  }
 }catch(err){console.error('Planned clash failed:',err);logMsg('The clash sequence stopped unexpectedly. See console for details.');}
 B.assignments={};B.selectedPage=null;drag=null;B.busy=false;renderBattle();flushHitFx();updatePlanButton();
 if(!ended&&!checkEnd())endScene();saveSnapshot();
}
async function resolveStaggeredAttack(pg,en){
 for(const d of pg.dice){
  if(!en.alive||B.player.hp<=0)break;
  if(isDef(d.t)){addWaitingDefense(B.player,d,pg);logMsg(`${d.t==='evade'?'Evade':'Block'} stance is waiting for an incoming attack this Scene.`);continue}
  triggerAttackStatuses(B.player,d);if(B.player.hp<=0||!en.alive)break;
  for(let i=0;i<4;i++){showClash(0,rollDie(d,B.player),'—',d.t);await wait(42)}
  const r=rollDie(d,B.player);consumeDiceStatus(B.player,d);showClash(0,r,'—',d.t);await wait(170);hurtEnemy(en,r,d.t,pg,B.player,{attackDie:d});logMsg(`${en.name} is staggered: unopposed hit for ${r}.`);renderBattle();flushHitFx();await wait(220);hideClash();
 }
}

async function resolveEnemyAttack(en,ep=null,dieIndex=0){
 ep=ep||((en.intents||[])[dieIndex])||en.intent||pickEnemyPage(en);if(!ep)return;
 logMsg(`${en.name} attacks without a clash: ${ep.n}.`);
 for(const d of ep.dice){if(!en.alive||en.stunned||B.player.hp<=0)break;if(isDef(d.t)){addWaitingDefense(en,d,ep);continue}
  triggerAttackStatuses(en,d);if(!en.alive||en.hp<=0||B.player.hp<=0)break;
  for(let i=0;i<4;i++){showClash(rollDie(d,en),0,d.t,'—');await wait(45)}
  const rawRoll=rollDie(d,en);consumeDiceStatus(en,d);showClash(rawRoll,0,d.t,'—');await wait(190);
  const stance=(B.player.defenseStances||[])[0];
  if(stance){
   const dp=(stance.pageId&&window.PAGES[stance.pageId])||null;
   // A standing defense die rolls anew against each incoming attack. The defensive
   // die receives its Offense/Defense-Level power adjustment; the one-sided attack does not get clash power.
   const defenseRoll=rollClashDie(stance.die,B.player,en,dp,ep,d);
   const incomingRoll=rawRoll;
   showClash(incomingRoll,defenseRoll,d.t,stance.type);await wait(160);
   if(stance.type==='evade'){
    if(defenseRoll>incomingRoll){
     logMsg(`Evaded ${incomingRoll} with ${defenseRoll}; Evade remains active.`);recoverStagger(B.player,defenseRoll);stance.roll=null;stance.recycled=true;
    }else if(defenseRoll===incomingRoll){
     B.player.defenseStances.shift();logMsg(`Evade matches ${incomingRoll}; the attack is avoided, but Evade is spent.`);
    }else{
     B.player.defenseStances.shift();hurtPlayer(incomingRoll,d.t,ep,en,{defensePage:dp,defenseDie:stance.die,attackDie:d});
     logMsg(`Evade failed (${defenseRoll} vs ${incomingRoll}); ${en.name} hits.`);
    }
   }else{
    B.player.defenseStances.shift();const remainder=Math.max(0,incomingRoll-defenseRoll);
    if(remainder>0){
     hurtPlayer(remainder,d.t,ep,en,{hpRaw:remainder,staggerRaw:Math.ceil(remainder/2),defensePage:dp,defenseDie:stance.die,attackDie:d});
     logMsg(`${en.name} gets through Block for ${remainder}.`);
    }else{
     if(defenseRoll>incomingRoll)dealStaggerDamage(en,defenseRoll-incomingRoll);
     logMsg(defenseRoll>incomingRoll?`Block wins and deals ${defenseRoll-incomingRoll} Stagger damage.`:`Block stops ${en.name}'s hit.`);
    }
   }
  }else{hurtPlayer(rawRoll,d.t,ep,en,{attackDie:d});logMsg(`${en.name} hits for ${rawRoll}.`)}
  renderBattle();flushHitFx();await wait(260);hideClash();
 }
}
async function resolvePlayerOneSidedDie(d,en,pp){
 if(!en?.alive||!d)return;
 if(isDef(d.t)){addWaitingDefense(B.player,d,pp);logMsg(`${d.t==='evade'?'Evade':'Block'} waits for an incoming attack this Scene.`);return;}
 triggerAttackStatuses(B.player,d);if(B.player.hp<=0||!en.alive)return;
 for(let i=0;i<4;i++){showClash(0,rollDie(d,B.player),'—',d.t);await wait(42)}
 const attackRoll=rollDie(d,B.player);consumeDiceStatus(B.player,d);showClash(0,attackRoll,'—',d.t);await wait(180);
 const stance=(en.defenseStances||[])[0];
 if(!stance){hurtEnemy(en,attackRoll,d.t,pp,B.player,{attackDie:d});logMsg(`Unopposed hit: ${attackRoll}.`)}
 else{
  const dp=(stance.pageId&&window.PAGES[stance.pageId])||null;
  const defenseRoll=rollClashDie(stance.die,en,B.player,dp,pp,d);
  showClash(defenseRoll,attackRoll,stance.type,d.t);await wait(150);
  if(stance.type==='evade'){
   if(defenseRoll>attackRoll){recoverStagger(en,defenseRoll);stance.recycled=true;logMsg(`${en.name} evades ${attackRoll} with ${defenseRoll}; its Evade remains active.`)}
   else if(defenseRoll===attackRoll){en.defenseStances.shift();logMsg(`${en.name}'s Evade matches the attack and is spent.`)}
   else{en.defenseStances.shift();hurtEnemy(en,attackRoll,d.t,pp,B.player,{attackDie:d});logMsg(`Hit ${en.name} through Evade for ${attackRoll}.`)}
  }else{
   en.defenseStances.shift();
   if(defenseRoll>attackRoll){dealStaggerDamage(B.player,defenseRoll-attackRoll);logMsg(`${en.name}'s Block wins and deals ${defenseRoll-attackRoll} Stagger damage.`)}
   else if(defenseRoll===attackRoll)logMsg(`${en.name}'s Block cancels the attack.`)
   else{const remaining=attackRoll-defenseRoll;hurtEnemy(en,attackRoll,d.t,pp,B.player,{hpRaw:remaining,staggerRaw:Math.ceil(remaining/2),defensePage:dp,defenseDie:stance.die,attackDie:d});logMsg(`Hit through ${en.name}'s Block for ${remaining}.`)}
  }
 }
 renderBattle();flushHitFx();await wait(240);hideClash();
}

async function resolveClash(pp,ep,en){
 const playerQueue=[...(pp.dice||[])].map((die,index)=>({die,index}));
 const enemyQueue=[...(ep?.dice||[])].map((die,index)=>({die,index}));
 while(playerQueue.length&&enemyQueue.length&&en.alive&&B.player.hp>0){
  // A successful defensive die becomes a Scene-local stance and gets first chance
  // to answer the next incoming attack before a fresh page die is paired.
  if(B.player.defenseStances?.length&&!isDef(enemyQueue[0].die.t)){
   const incoming=enemyQueue.shift();
   await resolveEnemyAttack(en,{...ep,dice:[incoming.die]},0);
   if(B.player.stunned)playerQueue.length=0;
   if(en.stunned)enemyQueue.length=0;
   renderBattle();flushHitFx();saveSnapshot();
   continue;
  }
  if(en.defenseStances?.length&&!isDef(playerQueue[0].die.t)){
   const incoming=playerQueue.shift();
   await resolvePlayerOneSidedDie(incoming.die,en,pp);
   if(B.player.stunned)playerQueue.length=0;
   if(en.stunned)enemyQueue.length=0;
   renderBattle();flushHitFx();saveSnapshot();
   continue;
  }
  const playerItem=playerQueue.shift(),enemyItem=enemyQueue.shift();
  const a=playerItem.die,b=enemyItem.die;
  triggerAttackStatuses(B.player,a);triggerAttackStatuses(en,b);
  if(B.player.hp<=0||!en.alive)break;
  const rolled=await rollClashPair(a,b,B.player,en,pp,ep),ar=rolled.player,br=rolled.enemy;
  showClash(br,ar,b.t,a.t);await wait(320);
  if(isDef(a.t)&&!isDef(b.t)){
   if(a.t==='evade'){
    if(ar>br){recoverStagger(B.player,ar);playerQueue.push(playerItem);logMsg(`Evaded ${br}; Evade wins, restores ${ar} Stagger, and recycles behind the remaining dice.`)}
    else if(ar===br)logMsg(`Evade matches ${br}; the attack is avoided, but the Evade is spent.`)
    else{hurtPlayer(br,b.t,ep,en,{attackDie:b});logMsg(`${en.name} breaks through Evade for ${br}.`)}
   }else{
    if(ar>br){dealStaggerDamage(en,blockStaggerAmount(B.player,ar-br));logMsg(`Block wins and deals ${blockStaggerAmount(B.player,ar-br)} direct Stagger damage.`)}
    else if(br>ar){const remaining=br-ar;hurtPlayer(remaining,b.t,ep,en,{hpRaw:remaining,staggerRaw:Math.ceil(remaining/2),defensePage:pp,defenseDie:a,attackDie:b});logMsg(`Attack gets through Block for ${remaining}.`)}
    else logMsg('Block and attack tie; no damage is dealt.');
   }
  }else if(isDef(b.t)&&!isDef(a.t)){
   if(b.t==='evade'){
    if(br>ar){recoverStagger(en,br);enemyQueue.push(enemyItem);logMsg(`${en.name} evades ${ar}, restores ${br} Stagger, and recycles its Evade behind the remaining dice.`)}
    else if(br===ar)logMsg(`${en.name}'s Evade matches ${ar}; the attack is avoided, but its Evade is spent.`)
    else{hurtEnemy(en,ar,a.t,pp,B.player,{attackDie:a});logMsg(`Hit ${en.name} through Evade for ${ar}.`)}
   }else{
    if(ar>br){const remaining=ar-br;hurtEnemy(en,ar,a.t,pp,B.player,{hpRaw:remaining,staggerRaw:Math.ceil(remaining/2),defensePage:ep,defenseDie:b,attackDie:a});logMsg(`Hit through ${en.name}'s Block for ${remaining}.`)}
    else if(br>ar){dealStaggerDamage(B.player,br-ar);logMsg(`${en.name}'s Block wins and deals ${br-ar} direct Stagger damage.`)}
    else logMsg(`${en.name}'s Block ties the attack; no damage is dealt.`);
   }
  }else if(isDef(a.t)&&isDef(b.t)){
   if(a.t==='evade'&&b.t==='evade')logMsg('Evade dice cancel each other; neither is retained.');
   else if(a.t==='block'&&b.t==='block'){
    if(ar>br){dealStaggerDamage(en,blockStaggerAmount(B.player,ar));logMsg(`Your Block wins against Block and deals ${blockStaggerAmount(B.player,ar)} Stagger damage.`)}
    else if(br>ar){dealStaggerDamage(B.player,br);logMsg(`${en.name}'s Block wins against Block and deals ${br} Stagger damage.`)}
    else logMsg('Block dice tie; neither deals Stagger damage.');
   }else if(a.t==='evade'){
    if(ar>br){recoverStagger(B.player,ar);logMsg(`Evade beats Block and restores ${ar} Stagger; it is spent against a defensive die.`)}
    else if(br>ar){dealStaggerDamage(B.player,br);logMsg(`${en.name}'s Block beats Evade and deals ${br} Stagger damage.`)}
    else logMsg('Evade and Block tie; both are spent.');
   }else{
    if(br>ar){recoverStagger(en,br);logMsg(`${en.name}'s Evade beats Block and restores ${br} Stagger; it is spent against a defensive die.`)}
    else if(ar>br){dealStaggerDamage(en,blockStaggerAmount(B.player,ar));logMsg(`Your Block beats Evade and deals ${blockStaggerAmount(B.player,ar)} Stagger damage.`)}
    else logMsg('Block and Evade tie; both are spent.');
   }
  }else if(!isDef(a.t)&&!isDef(b.t)){
   if(ar>br){hurtEnemy(en,ar,a.t,pp,B.player,{attackDie:a});applyPageEffects(pp,en,'clashWin',B.player);logMsg('Clash win.')}
   else if(br>ar){hurtPlayer(br,b.t,ep,en,{attackDie:b});applyPageEffects(ep,B.player,'clashWin',en);logMsg('Clash lost.')}
   else logMsg('Clash tie.');
  }
  renderBattle();flushHitFx();saveSnapshot();await wait(240);hideClash();
  if(!en.alive||B.player.hp<=0)return;
  if(B.player.stunned)playerQueue.length=0;
  if(en.stunned)enemyQueue.length=0;
 }
 // Any remaining defensive dice are retained for later incoming attacks this Scene.
 while(playerQueue.length&&en.alive&&B.player.hp>0&&!B.player.stunned){const item=playerQueue.shift();if(isDef(item.die)){addWaitingDefense(B.player,item.die,pp);logMsg(`${item.die.t==='evade'?'Evade':'Block'} is held for the next incoming attack this Scene.`)}else await resolvePlayerOneSidedDie(item.die,en,pp);if(!en.alive||B.player.hp<=0)return;if(B.player.stunned){playerQueue.length=0;break;}}
 while(enemyQueue.length&&en.alive&&B.player.hp>0&&!en.stunned){const item=enemyQueue.shift();if(isDef(item.die)){addWaitingDefense(en,item.die,ep);logMsg(`${en.name}'s ${item.die.t==='evade'?'Evade':'Block'} is held for the next incoming attack this Scene.`)}else await resolveEnemyAttack(en,{...ep,dice:[item.die]},0);if(!en.alive||B.player.hp<=0)return;if(en.stunned){enemyQueue.length=0;break;}}
}

/* ---- Manual hit FX (no animation files; WAAPI + rAF tweens) ---- */
function tweenShake(el, duration=320, amp=8){
 if(!el)return;
 // Cancel previous shakes on this node
 if(el._shakeAnims)el._shakeAnims.forEach(a=>{try{a.cancel()}catch(_){}});
 el._shakeAnims=[];
 const frames=[];
 const steps=8;
 for(let i=0;i<=steps;i++){
  const t=i/steps;
  const decay=1-t;
  const x=(i%2===0?-1:1)*amp*decay;
  frames.push({transform:`translateX(${x}px)`, offset:t});
 }
 frames.push({transform:'translateX(0)', offset:1});
 try{
  const a=el.animate(frames,{duration,easing:'ease-out',fill:'none'});
  el._shakeAnims.push(a);
 }catch(_){
  // Fallback without WAAPI
  el.style.transition='transform .05s';
  el.style.transform=`translateX(${-amp}px)`;
  setTimeout(()=>{el.style.transform=`translateX(${amp}px)`},50);
  setTimeout(()=>{el.style.transform='translateX(0)';el.style.transition=''},duration);
 }
}
function tweenFlashRed(el, duration=300){
 if(!el)return;
 if(el._flashAnims)el._flashAnims.forEach(a=>{try{a.cancel()}catch(_){}});
 el._flashAnims=[];
 try{
  const a=el.animate([
   {filter:'brightness(1) sepia(0) saturate(1)', offset:0},
   {filter:'brightness(1.65) sepia(1) saturate(6) hue-rotate(320deg)', offset:0.2},
   {filter:'brightness(1.35) sepia(.7) saturate(4) hue-rotate(320deg)', offset:0.45},
   {filter:'brightness(1) sepia(0) saturate(1)', offset:1}
  ],{duration,easing:'ease-out',fill:'none'});
  el._flashAnims.push(a);
 }catch(_){
  el.style.filter='brightness(1.5) sepia(1) saturate(5) hue-rotate(320deg)';
  setTimeout(()=>{el.style.filter=''},duration);
 }
}
function tweenVignette(duration=420){
 const v=$('#damageVignette');if(!v)return;
 v.style.opacity='0';v.style.display='block';
 try{
  v.animate([
   {opacity:0},{opacity:0.95, offset:0.15},{opacity:0.7, offset:0.4},{opacity:0}
  ],{duration,easing:'ease-out',fill:'forwards'});
 }catch(_){
  v.style.transition='opacity .1s';v.style.opacity='0.9';
  setTimeout(()=>{v.style.transition=`opacity ${duration}ms`;v.style.opacity='0'},80);
 }
}
function hitEnemyFx(en){
 if(!en)return;
 const actor=document.querySelector(`#bActors .actor[data-id="${en.id}"]`);
 const img=actor&&actor.querySelector('img');
 const panel=document.querySelector(`#enemyList .unitCard[data-enemy="${en.id}"]`);
 tweenShake(actor,340,9);
 tweenShake(img,340,7);
 tweenFlashRed(img,320);
 tweenShake(panel,300,5);
}
function hitPlayerFx(){
 tweenVignette(450);
 const panel=$('#playerPanel .unitCard')||$('#playerPanel');
 tweenShake(panel,340,7);
}
function flushHitFx(){
 // Re-apply after DOM rebuilds so a late render cannot swallow the hit.
 for(const id of pendingEnemyHitFx){const en=B&&B.enemies.find(e=>e.id===id);if(en)hitEnemyFx(en)}
 pendingEnemyHitFx.clear();
 if(pendingPlayerHitFx){hitPlayerFx();pendingPlayerHitFx=false}
}
function hurtEnemy(en,n,dmgType,page=null,attacker=B?.player,opts={}){
 if(!en||!en.alive)return 0;
 let power=(Number.isFinite(opts.hpRaw)?opts.hpRaw:n);
 if(attacker===B?.player&&currentPassive().id==='hammerGrip'&&dmgType==='blunt')power+=1;
 if(attacker===B?.player&&currentPassive().id==='seniorPressure'&&!attacker.passiveUsedThisScene){power+=1;attacker.passiveUsedThisScene=true}
 power=Math.max(0,power+unitStatus(en,'fragile')-unitStatus(en,'protection'));
 const factor=levelDamageMultiplier(attacker,page,en,opts.defensePage||null,opts.defenseDie||null,opts.attackDie||null);
 const dmg=en.stunned?Math.round(power*factor*2):applyRes(Math.round(power*factor),dmgType,en.res,'hp');
 const rawSt=Number.isFinite(opts.staggerRaw)?opts.staggerRaw:Math.ceil(Math.max(0,n)/2);
 const stBonus=attacker===B?.player?nameBuffMultiplier('staggerDamageMultiplier'):1;
 const stDmg=Math.round((en.stunned?Math.round(rawSt*factor*2):applyRes(Math.round(rawSt*factor),dmgType,en.res,'st'))*stBonus);
 en.hp=Math.max(0,en.hp-dmg);en.stagger=Math.max(0,en.stagger-stDmg);pendingEnemyHitFx.add(en.id);hitEnemyFx(en);
 consumeHitStatuses(en);
 if(gainEmotion(en,1))onEmotionUp(en);if(gainEmotion(B.player,1))onEmotionUp('player');
 if(en.hp>0)triggerHitStatuses(en);
 if(en.hp>0)applyPageEffects(page,en,'hit',attacker,dmgType);
 if(en.stagger<=0&&!en.stunned&&en.alive&&en.hp>0){en.stagger=1;dealStaggerDamage(en,1)}
 if(en.hp<=0){markEnemyDown(en,'damage');if(attacker===B?.player&&currentPassive().id==='hookMomentum')addStatus(B.player,'strength',1,2)}
 return dmg;
}
function hurtPlayer(n,dmgType,page=null,attacker=null,opts={}){
 if(!B||!B.player)return 0;
 const raw=(Number.isFinite(opts.hpRaw)?opts.hpRaw:n);
 const adjusted=Math.max(0,raw+unitStatus(B.player,'fragile')-unitStatus(B.player,'protection')),factor=levelDamageMultiplier(attacker,page,B.player,opts.defensePage||null,opts.defenseDie||null,opts.attackDie||null);
 const dmg=applyRes(Math.round(adjusted*factor),dmgType,B.player.res,'hp');
 const rawSt=Number.isFinite(opts.staggerRaw)?opts.staggerRaw:Math.ceil(adjusted/2);
 const stDmg=applyRes(Math.round(rawSt*factor),dmgType,B.player.res,'st');
 B.player.hp=Math.max(0,B.player.hp-dmg);B.player.stagger=Math.max(0,B.player.stagger-stDmg);pendingPlayerHitFx=true;hitPlayerFx();
 consumeHitStatuses(B.player);
 if(gainEmotion(B.player,1))onEmotionUp('player');
 if(B.player.hp>0)triggerHitStatuses(B.player);
 if(B.player.hp>0&&page&&attacker)applyPageEffects(page,B.player,'hit',attacker);
 if(B.player.stagger<=0&&!B.player.stunned){B.player.stagger=1;dealStaggerDamage(B.player,1)}
 if(B.player.hp<=0)logMsg('You are defeated.');return dmg;
}

async function rollClashPair(playerDie,enemyDie,playerUnit=B?.player,enemyUnit=null,playerPage=null,enemyPage=null){
 // A clash die rolls once. A tie is a draw and consumes both dice; only a strictly winning Evade recycles.
 for(let i=0;i<7;i++){
  showClash(rollClashDie(enemyDie,enemyUnit,playerUnit,enemyPage,playerPage,playerDie),rollClashDie(playerDie,playerUnit,enemyUnit,playerPage,enemyPage,enemyDie),enemyDie.t,playerDie.t);
  await wait(52);
 }
 const player=rollClashDie(playerDie,playerUnit,enemyUnit,playerPage,enemyPage,enemyDie);
 const enemy=rollClashDie(enemyDie,enemyUnit,playerUnit,enemyPage,playerPage,playerDie);
 consumeDiceStatus(playerUnit,playerDie);consumeDiceStatus(enemyUnit,enemyDie);
 showClash(enemy,player,enemyDie.t,playerDie.t);await wait(180);
 return {player,enemy};
}
function showClash(eVal,pVal,eT,pT){
 $('#cE').textContent=`${eT} ${eVal}`;$('#cP').textContent=`${pT} ${pVal}`;
 $('#cE').className='die'+(eVal>pVal?' win':eVal<pVal?' lose':'');
 $('#cP').className='die'+(pVal>eVal?' win':pVal<eVal?' lose':'');
 const panel=$('#bClash');
 if(!panel)return;
 if(!panel.classList.contains('on')){
  panel.classList.remove('on');void panel.offsetWidth;panel.classList.add('on');
 }else{
  // Keep panel up while numbers tick during fast rolls
  panel.classList.add('on');
 }
}
function hideClash(){$('#bClash').classList.remove('on')}
function wait(ms){return new Promise(r=>setTimeout(r,ms))}

function applyBattleBackground(bgKey){
 const key=BG_KEYS.includes(bgKey)?bgKey:(BG_KEYS.includes(currentBg)?currentBg:'back');
 currentBg=key;
 setBg(key,true);
 const stage=$('#bStage .alley');
 if(stage){
  stage.className='alley bg-'+key;
  stage.style.backgroundImage='';
  stage.style.backgroundColor='#08090a';
 }
}
function hideFadeOverlay(){
 const f=$('#fade');
 if(!f)return;
 f.style.opacity='0';
 f.style.pointerEvents='none';
 f.style.display='none';
}
function resumePendingWave(){
 if(!B)return;
 // Recover Arnold wave if an older/interrupted save lost the pending index.
 if(!Number.isInteger(B.pendingWaveIndex)&&B.encounterId==='brotherhood'&&Array.isArray(B.waves)&&B.waves.length>1&&B.waveIndex===0){
  B.pendingWaveIndex=1;
 }
 if(!Number.isInteger(B.pendingWaveIndex)){
  // Last-resort recovery for Brotherhood: if wave 0 roster is dead and a second wave exists, force it.
  if(B.encounterId==='brotherhood'&&Array.isArray(B.waves)&&B.waves.length>1&&B.waveIndex===0){
   B.pendingWaveIndex=1;
  }else{
   console.warn('No pending encounter wave to resume.');
   return;
  }
 }
 if(typing&&typing.t){try{clearTimeout(typing.t)}catch(_){}}
 typing=null;ready=false;i=Array.isArray(script)?script.length:0;
 clearVN();
 const dlg=$('#dlg'),pick=$('#pick'),nextBtn=$('#next');
 if(dlg)dlg.style.display='none';
 if(pick)pick.style.display='none';
 if(nextBtn)nextBtn.style.visibility='hidden';
 hideFadeOverlay();
 fadeBusy=false;fadeQueue.length=0;

 const targetIndex=B.pendingWaveIndex;
 delete B.pendingWaveIndex;
 B.waveIndex=targetIndex;
 B.interludeActive=false;
 B.busy=false;
 const wave=B.waves[B.waveIndex]||[];
 B.enemies=wave.map(def=>mkEnemy(def));
 B.enemies.forEach(queueEnemyIntents);
 B.assignments={};B.selectedPage=null;B.target=null;
 B.light=Math.min(B.maxLight,B.light+2);
 if(!B.player.stunned)drawPage();
 // Arnold's wave is fought inside Brotherhood territory.
 const waveBg=(B.encounterId==='brotherhood'&&B.waveIndex===1)?'brotherhood':(currentBg||'back');

 const enterBattle=()=>{
  hideFadeOverlay();
  applyBattleBackground(waveBg);
  show('battle');
  renderBattle();
  updatePlanButton();
  logMsg(B.encounterId==='brotherhood'&&B.waveIndex===1
   ?'Arnold stands in the Brotherhood workshop. The second wave begins.'
   :`Act ${B.waveIndex+1}. The next group steps into the stage.`);
  saveSnapshot();
 };
 // Prefer a short fade, but never depend on it — force battle in if the fade system is busy.
 if(fadeBusy){
  enterBattle();
 }else{
  fadeTo(enterBattle);
  // Safety net: if fade stalls, still enter battle.
  setTimeout(()=>{
   if(B&&Number.isInteger(B.waveIndex)&&B.waveIndex===targetIndex&&!$('#battle')?.classList.contains('on')){
    enterBattle();
   }
  },1200);
 }
}
function checkEnd(){
 if(!B)return true;
 if(B.interludeActive)return true;
 if(B.player.hp<=0){B.won=false;endBattle(false);return true}
 if(!B.enemies.length||B.enemies.every(e=>!e.alive)){
  // Store each defeated guest's book once before replacing an Act's enemy roster.
  for(const e of B.enemies.filter(e=>!e.alive&&e.book)){
   if(!B.bookDrops.some(x=>x.enemyId===e.id&&x.waveIndex===B.waveIndex))B.bookDrops.push({enemyId:e.id,waveIndex:B.waveIndex,id:e.book});
  }
  B.kills=Math.min(B.totalEnemies,(B.kills||0)+B.enemies.filter(e=>!e.alive).length);
  // Multi-wave: stop at the existing Victory panel. Continue starts the next-stage dialogue.
  if(B.waveIndex+1<B.waves.length){
   B.pendingWaveIndex=B.waveIndex+1;
   B.busy=false;
   B.won=true;
   endBattle(true);
   return true;
  }
  B.won=true;endBattle(true);return true;
 }
 return false;
}
function endScene(){
 closeEnemyPage();B.scene++;B.assignments={};B.light=Math.min(B.maxLight,B.light+2);B.player.defenseStances=[];B.enemies.forEach(e=>{e.defenseStances=[]});
 tickStatuses(B.player);B.enemies.forEach(e=>{if(e.alive)tickStatuses(e)});
 if(B.player.stunned){if(B.player.staggeredThisScene)B.player.staggeredThisScene=false;else{B.player.stunTurns--;if(B.player.stunTurns<=0){B.player.stunned=false;B.player.stagger=B.player.maxSt;logMsg('You recover from Stagger. Stagger resistance restored.')}}}
 B.enemies.forEach(e=>{
  if(!e.alive)return;
  if(e.stunned){if(e.staggeredThisScene)e.staggeredThisScene=false;else{e.stunTurns--;if(e.stunTurns<=0){e.stunned=false;e.stagger=e.maxSt;}}}
  if(e.passiveType==='fairyFestivalQueen'&&!e.ravenousnessTriggered&&e.hp>0&&e.hp<=Math.ceil(e.maxHp*.25)){e.ravenousnessTriggered=true;addStatus(e,'strength',3,99);logMsg('Ravenousness awakens. Fairy Festival gains Strength as it grows desperate.');}
  e.speed=1+Math.floor(Math.random()*4);queueEnemyIntents(e);e.passiveUsedThisScene=false;
 });
 B.player.speed=1+Math.floor(Math.random()*4);B.player.diceSpeeds=rollSpeeds(B.player);B.player.passiveUsedThisScene=false;
 const passive=currentPassive();
 if(passive.id==='associationBasics'&&B.scene%3===0)B.light=Math.min(B.maxLight,B.light+1);
 if(passive.id==='operatorOverhead'&&B.scene%2===0)B.light=Math.min(B.maxLight,B.light+1);
 if(!B.player.stunned)drawPage();
 if(B.player.emo&&B.player.emo.level>0)drawPage();
 if(passive.id==='steadyRoutine'&&B.scene%3===0)drawPage();
 renderBattle();if(checkEnd())return;
 logMsg(`Scene ${B.scene}. Light restored; enemy intentions have been queued.`);
}

const MISSION_PAY={rats:1000,yunOffice:4000,brotherhood:5000,hookOffice:6500};
function endBattle(win){
 closeEnemyPage();if(!B)return;
 B.won=!!win;
 ensureInventory();
 S.vitals={hp:win?Math.max(1,B.player.hp):Math.max(1,Math.ceil(B.player.maxHp*.42)),stagger:win?Math.max(1,B.player.stagger):B.player.maxSt,keyPage:B.player.keyPage};
 const hasNextWave=win&&Number.isInteger(B.pendingWaveIndex)&&B.pendingWaveIndex<(B.waves?.length||0);
 if(win&&B.missionId==='urbanMythExam'){
  S.pendingMission=null;$('#bEndTitle').textContent='Examination Cleared';
  $('#bEndTxt').innerHTML="Fairy Festival has been suppressed. The examination record is not a Canard contract and grants no contract payment or Books. Continue to hear the examiners' assessment.";
 }else if(hasNextWave){
  // Stage clear only — Continue uses the existing victory panel to open the next-wave scene.
  $('#bEndTitle').textContent='Stage Cleared';
  if(B.encounterId==='brotherhood'&&B.waveIndex===0){
   $('#bEndTxt').innerHTML='Mo and Consta are down. They are still moving — dragging themselves back toward Workshop Row.<br><br>Continue to pursue them. The next stage will open after the chase scene.';
  }else{
   $('#bEndTxt').innerHTML='This stage is cleared. Continue to proceed to the next group.';
  }
 }else if(win){
  // Full encounter victory is provisional until the mission post-scene reaches missionEnd.
  const bookNames=(B.bookDrops||[]).map(entry=>window.BOOK_DATA?.[entry.id]?.n).filter(Boolean);
  S.pendingMission={id:B.missionId||S.flags?.activeMission||'rats',payment:MISSION_PAY[B.missionId||'rats']||1000,expEarned:Math.max(0,Math.floor(B.expEarned||0)),bookDrops:(B.bookDrops||[]).map(entry=>({...entry})),savedAt:new Date().toISOString()};
  $('#bEndTitle').textContent='Victory';
  $('#bEndTxt').innerHTML=`The fight is won, but the contract is <b>not officially closed</b> until its follow-up report is complete. Keep going through the post-fight scene to receive payment and recovered Books.<br><br><b>Potential contract payment:</b> ${(MISSION_PAY[B.missionId||'rats']||1000).toLocaleString('en-US')} Ahn<br><b>Potential EXP:</b> ${Math.max(0,Math.floor(B.expEarned||0))}<br><b>Potential recovered Books:</b> ${bookNames.length?bookNames.map(escapeHTML).join('<br>'):'None'}<br><br>If you leave the game before the contract is finished, this encounter will be abandoned and must be done again.`;
 }else{
  S.pendingMission=null;
  $('#bEndTitle').textContent='Defeated';
  $('#bEndTxt').innerHTML=`The fight went badly. You retreat before the encounter can become fatal. Return home with reduced vitality, then rest or change your equipment before trying again.<br><br><b>Recovery:</b> HP restored to ${S.vitals.hp}/${B.player.maxHp}. No Books or contract payment are issued for an unfinished encounter.`;
 }
 $('#bEnd').classList.add('on');saveSnapshot();
}
function startBrotherhoodWave2Scene(){
 // Chase stays on Backstreets with only Mo + Consta.
 // Arnold is not on stage until the workshop arrival line.
 B.interludeActive=true;
 B.busy=false;
 script=[
  // Backstreets — Consta left, Mo mid. Arnold not present.
  {loc:'Backstreets — Workshop Row approach',bg:'back',t:'Mo and Consta do not stay down. Consta is limping hard, sparking at the joint; Mo hauls him by the arm toward the loading alley.'},
  {who:'Consta',title:'Brotherhood of Iron',bg:'back',side:'left',t:'Mo—I can’t—my leg’s grinding. We go back. We go back to the floor.'},
  {who:'Mo',title:'Brotherhood of Iron',bg:'back',side:'mid',t:'Move. Do not stop. We reach the workshop or we shut down in this alley.'},
  {loc:'Backstreets — Chase',bg:'back',t:'You stay on them through the alley. Oil and blood mark the path. They are not trying to lose you—they are trying to make it home before their bodies give out.'},
  {who:'Consta',title:'Brotherhood of Iron',bg:'back',side:'left',t:'Almost there—almost—'},
  {who:'Mo',title:'Brotherhood of Iron',bg:'back',side:'mid',t:'Keep moving.'},
  // Arrive — still only the two of them
  {loc:'Brotherhood of Iron — Workshop',bg:'brotherhood',t:'The workshop doors hang open. Crates. Cut seals. Hot metal. Consta collapses against a workbench. Mo tries to stay between you and the deeper floor—and fails.'},
  {who:'Mo',title:'Brotherhood of Iron',bg:'brotherhood',side:'mid',t:'The crate… the report… someone has to…'},
  // They go down — clear stage before Arnold exists
  {t:'Mo and Consta stop moving. Whatever kept those bodies fighting in the street is gone. For a moment the workshop is only quiet.',clearStage:true},
  // Arnold enters from the right as a new arrival
  {loc:'Brotherhood of Iron — Workshop',bg:'brotherhood',t:'Footsteps answer from the far end of the floor. Someone who was already inside steps into view.'},
  {who:'Arnold',title:'Brotherhood of Iron — Leader',bg:'brotherhood',side:'right',t:'So. You chased them onto our floor.'},
  {who:'Arnold',title:'Brotherhood of Iron — Leader',bg:'brotherhood',side:'right',t:'Mo. Consta. Rest. You did enough.'},
  {who:'Arnold',title:'Brotherhood of Iron — Leader',bg:'brotherhood',side:'right',t:'We take parts the Workshops price out of reach. You came for a crate and a clean report. Fine.'},
  {who:'Arnold',title:'Brotherhood of Iron — Leader',bg:'brotherhood',side:'right',t:'I will not let their deaths end as a line in somebody else’s paperwork. If this ends here, it ends with me.',autoResumeWave:true}
 ];
 i=-1;ready=false;
 if(typing&&typing.t){try{clearTimeout(typing.t)}catch(_){}}
 typing=null;
 hideFadeOverlay();
 $('#dlg').style.display='';$('#pick').style.display='none';
 if($('#next'))$('#next').style.visibility='hidden';
 fadeTo(()=>{
  hideFadeOverlay();
  clearVN();
  setBg('back',true);
  show('story');
  next();
 });
}
function afterBattle(){
 $('#bEnd').classList.remove('on');
 const won=!!(B&&B.won);
 // Existing Continue button: if a next wave is pending, run its scene instead of ending the mission.
 if(won&&B&&Number.isInteger(B.pendingWaveIndex)&&B.pendingWaveIndex<(B.waves?.length||0)){
  if(B.encounterId==='brotherhood'&&B.pendingWaveIndex===1){
   startBrotherhoodWave2Scene();
   return;
  }
  // Generic multi-wave fallback (no special dialogue): resume the next roster immediately.
  resumePendingWave();
  return;
 }
 if(won){
  const missionId=B.missionId||'rats';
  if(missionId==='urbanMythExam'){
   script=[
    {loc:'Hana Association — Examination Hall',bg:'hana',who:'Zevelyn',title:'Eden Office Fixer',side:'left',t:'Huh. You actually put it down. I was half-betting you’d panic the second it started knitting itself. Guess the papers weren’t pure horseshit.'},
    {loc:'Hana Association — Examination Hall',bg:'hana',who:'Han-ul',title:'Hana Association — Grade 1 Fixer',t:'The result has been recorded. This examination establishes a baseline; your file and previous reception outcomes remain in the review.'},
    {loc:'Hana Association — Examination Hall',bg:'hana',t:'The examination is over. Further evaluation will come later; you have not been automatically promoted by this test alone.'},
    {k:'urbanMythComplete'}
   ];
  }else if(missionId==='rats'){
   const post=window.POST_RATS||window.POST_RATS_REPLAY;
   script=[...(post||[{k:'homeHub'}])];
  } else script=[{k:'missionPost',id:missionId}];
 }else{
  S.flags=S.flags||{};S.flags.activeMission=null;S.pendingMission=null;
  if(B?.missionId==='urbanMythExam')script=[{loc:'Hana Association — Examination Hall',bg:'hana',who:'Han-ul',title:'Hana Association — Grade 1 Fixer',t:'The examination cannot be completed today. Recover, review your equipment, and request another attempt when you are ready.'},{k:'urbanMythComplete',failed:true}];
  else script=[{loc:'Your place',bg:homeBackgroundKey(),t:`The job went badly. You make it home before the situation worsens. Rest, adjust your pages, and prepare before trying the contract again.`},{k:'homeHub'}];
 }
 i=-1;ready=false;typing=null;B=null;$('#dlg').style.display='';$('#pick').style.display='none';
 fadeTo(()=>{clearVN();show('story');next()});
}

/* ---------- home hub ---------- */
function isOutskirtsBorn(){return (S.tags||[]).includes('Outskirts-born')}
function isNestBorn(){return (S.tags||[]).includes('Nest-born')}
function isBackstreetsBorn(){return (S.tags||[]).includes('Backstreet-born')}
function homeBackgroundKey(){return isOutskirtsBorn()?'outplace':'apt'}
function homeLocationName(){return isOutskirtsBorn()?'Outskirts: Your shelter':'Your apartment'}
let inventoryTab='pages';
function nextUid(kind='item'){S.nextItemId=(S.nextItemId||0)+1;return `${kind}-${S.nextItemId}`}
function ensureInventory(){
 if(!S.inventory)S.inventory={};const inv=S.inventory;
 for(const k of ['pages','keys','books','consumables','weapons','gear'])if(!Array.isArray(inv[k]))inv[k]=[];
 inv.pages=inv.pages.filter(p=>p&&p.id&&window.PAGES[p.id]).map(p=>{const def=window.PAGES[p.id];return {...p,uid:p.uid||nextUid('page'),n:p.n||def.n,desc:p.desc||diceStr(def.dice),equipped:!!p.equipped}});
 inv.keys=inv.keys.filter(k=>k&&k.id&&window.KEY_PAGES[k.id]&&k.id!=='grade9').map(k=>{const def=window.KEY_PAGES[k.id];return {...k,n:def.n,desc:k.desc||`${def.hp} HP · ${def.stagger} Stagger · ${def.passive?.desc||'No passive'}`}});
 inv.books=inv.books.filter(b=>b&&b.id&&window.BOOK_DATA?.[b.id]).map(b=>({...b,uid:b.uid||nextUid('book'),n:b.n||window.BOOK_DATA[b.id].n}));
 inv.consumables=inv.consumables.filter(c=>c&&c.id&&Number(c.count)>0).map(c=>({...c,count:Math.max(1,Math.floor(Number(c.count)||1))}));
 const stackMap=new Map();for(const c of inv.consumables){const prior=stackMap.get(c.id);if(prior)prior.count+=c.count;else stackMap.set(c.id,{...c})}inv.consumables=[...stackMap.values()];
 inv.weapons=inv.weapons.filter(w=>w&&window.WEAPON_DATA?.[w.id]);
 inv.gear=inv.gear.filter(g=>g&&window.GEAR_DATA?.[g.id]).map(g=>({...g,...window.GEAR_DATA[g.id]}));
 S.bodyShape=['male','female','bald'].includes(S.bodyShape)?S.bodyShape:(String(S.pronouns||S.gender||'they/them').startsWith('he')?'male':(String(S.pronouns||S.gender||'they/them').startsWith('she')?'female':'bald'));
 if(!Number.isFinite(Number(S.reputation)))S.reputation=50;else S.reputation=Math.max(0,Math.min(100,Number(S.reputation)));
 {const cap=playerLevelCap();S.level=Math.max(1,Math.min(cap,Math.floor(Number(S.level)||1)));S.exp=Math.max(0,Math.floor(Number(S.exp)||0));if(S.level>=cap)S.exp=0;}
 S.equipment=S.equipment||{keyPage:'grade9',weapons:[null,null],body:{}};
 if(!Array.isArray(S.equipment.weapons))S.equipment.weapons=[null,null];
 S.equipment.body=S.equipment.body&&typeof S.equipment.body==='object'?S.equipment.body:{};
 for(const slot of (window.BODY_SLOTS||[])){const id=S.equipment.body[slot.id];if(id&&(!window.GEAR_DATA?.[id]||window.GEAR_DATA[id].slot!==slot.id||!inv.gear.some(g=>g.id===id)))delete S.equipment.body[slot.id];}
 S.equipment.weapons=S.equipment.weapons.slice(0,2).map(id=>id&&inv.weapons.some(w=>w.id===id)?id:null);while(S.equipment.weapons.length<2)S.equipment.weapons.push(null);
 const keyId=S.equipment.keyPage||'grade9';if(keyId!=='grade9'&&!inv.keys.some(k=>k.id===keyId))S.equipment.keyPage='grade9';
 S.ahn=Number.isFinite(Number(S.ahn))?Math.max(0,Math.floor(Number(S.ahn))):10000;
 S.flags=S.flags||{};if(!Array.isArray(S.flags.completedMissions))S.flags.completedMissions=[];
 window.CityCanon?.migrate?.(S.flags);
 if(S.flags.gradePromoted8)S.grade=8;else if(!Number.isFinite(Number(S.grade)))S.grade=9;
 if(S.flags.starterPagesGranted&&!inv.pages.some(p=>p.id==='quickness')){
  const def=window.PAGES.quickness; if(def)inv.pages.push({uid:nextUid('page'),id:'quickness',n:def.n,desc:`Cost ${def.c} · ${diceStr(def.dice)}`,equipped:inv.pages.filter(p=>p.equipped).length<9});
 }
 return inv;
}
function addPageItem(id,equipped=false){
 ensureInventory();const def=window.PAGES[id];if(!def)return null;
 if(equipped&&S.inventory.pages.filter(p=>p.equipped).length>=9)equipped=false;
 const item={uid:nextUid('page'),id,n:def.n,desc:`Cost ${def.c} · ${diceStr(def.dice)}`,equipped};S.inventory.pages.push(item);return item;
}
function grantStarterInventory(){
 ensureInventory();if(S.flags.starterPagesGranted)return;
 ISSUE_PAGES.forEach(id=>addPageItem(id,true));
 if(!S.flags.starterConsumablesGranted){S.inventory.consumables.push({id:'field_dressing',n:'Field Dressing',desc:'Restore 14 HP and 6 Stagger in combat.',count:2},{id:'steadying_patch',n:'Steadying Patch',desc:'Restore 12 Stagger in combat.',count:1});S.flags.starterConsumablesGranted=true}
 if(!S.inventory.weapons.some(w=>w.id==='association_baton'))S.inventory.weapons.push({id:'association_baton',n:window.WEAPON_DATA.association_baton.n});
 if(!S.equipment.weapons.includes('association_baton'))S.equipment.weapons[0]='association_baton';
 S.flags.starterPagesGranted=true;saveSnapshot();
}
function togglePageEquipped(uid){
 ensureInventory();const p=S.inventory.pages.find(x=>x.uid===uid);if(!p)return;
 if(!p.equipped&&S.inventory.pages.filter(x=>x.equipped).length>=9){inventoryMessage='Only 9 Combat Pages can be equipped at once.';renderInventory();return}
 p.equipped=!p.equipped;inventoryMessage=p.equipped?`${p.n} equipped.`:`${p.n} moved to storage.`;renderInventory();saveSnapshot();
}
let inventoryMessage='';
function equipKeyPage(id){
 ensureInventory();if(id!=='grade9'&&!S.inventory.keys.some(k=>k.id===id))return;
 S.equipment.keyPage=id;const kp=currentKeyPage();if(S.vitals){const scaled=keyPageVitals(kp,playerLevel());S.vitals.hp=Math.min(S.vitals.hp,scaled.hp+(S.st.Might||0)*2);S.vitals.stagger=Math.min(S.vitals.stagger,scaled.stagger+(S.st.Agility||0)*2)}
 inventoryMessage=`Equipped ${kp.n}.`;renderInventory();saveSnapshot();
}
function toggleGear(id){
 ensureInventory();const item=window.GEAR_DATA?.[id];if(!item||!S.inventory.gear.some(g=>g.id===id))return;
 const slot=item.slot;S.equipment.body=S.equipment.body||{};
 if(S.equipment.body[slot]===id){delete S.equipment.body[slot];inventoryMessage=`Unequipped ${item.name}.`;}
 else {S.equipment.body[slot]=id;inventoryMessage=`Equipped ${item.name} in ${window.BODY_SLOTS.find(x=>x.id===slot)?.label||slot}.`;}
 renderInventory();saveSnapshot();
}
function bodyModelMarkup(){
 const shape=S.bodyShape||'bald';const label=shape==='male'?'Male silhouette':(shape==='female'?'Female silhouette':'Non-binary / bald silhouette');
 return `<div class="bodyModel shape-${shape}" role="img" aria-label="${label}"><i class="modelHair"></i><i class="modelHead"></i><i class="modelNeck"></i><i class="modelTorso"></i><i class="modelArm left"></i><i class="modelArm right"></i><i class="modelLeg left"></i><i class="modelLeg right"></i><span>${label}</span></div>`;
}
function toggleWeapon(id){
 ensureInventory();const slots=S.equipment.weapons||[null,null];
 if(slots.includes(id)){S.equipment.weapons=slots.map(w=>w===id?null:w);inventoryMessage=`${window.WEAPON_DATA[id]?.n||id} unequipped.`}
 else{const empty=slots.findIndex(w=>!w);if(empty<0){inventoryMessage='Both weapon slots are occupied. Unequip one before changing gear.';renderInventory();return}slots[empty]=id;S.equipment.weapons=slots;inventoryMessage=`Equipped ${window.WEAPON_DATA[id]?.n||id} in slot ${empty+1}.`}
 renderInventory();saveSnapshot();
}
function extractBook(uid){
 ensureInventory();const i=S.inventory.books.findIndex(b=>b.uid===uid);if(i<0)return;
 const book=S.inventory.books.splice(i,1)[0],data=window.BOOK_DATA[book.id];if(!data)return;
 const pool=(data.pages||[]).filter(id=>window.PAGES[id]);let awarded=[];
 if(pool.length){const id=pool[Math.floor(Math.random()*pool.length)];const item=addPageItem(id,false);if(item)awarded.push(`Combat Page: ${item.n} (stored)`)}
 if(data.key&&window.KEY_PAGES[data.key]&&Math.random()<.32){
  const kp=window.KEY_PAGES[data.key];S.inventory.keys.push({id:kp.id,n:kp.n,desc:`${kp.hp} HP · ${kp.stagger} Stagger · ${kp.passive?.desc||'No passive'}`});awarded.push(`Key Page: ${kp.n}${S.inventory.keys.filter(k=>k.id===kp.id).length>1?' (duplicate copy stacked)':''}`);
 }
 inventoryMessage=`Extracted ${book.n}: ${awarded.join(' · ')||'the book contained no available pages'}.`;inventoryTab='books';renderInventory();saveSnapshot();
}
function consumeCombatItem(id){
 if(!B||B.busy||B.player.hp<=0)return;
 ensureInventory();const item=S.inventory.consumables.find(c=>c.id===id&&c.count>0);if(!item)return;
 const p=B.player;
 if(id==='kcorp_ampule'&&p.hp>=p.maxHp){logMsg('K Corp Ampule would restore no HP right now.');return}
 if(id==='field_dressing'&&p.hp>=p.maxHp&&p.stagger>=p.maxSt){logMsg('Field Dressing would restore nothing right now.');return}
 if(id==='steadying_patch'&&p.stagger>=p.maxSt){logMsg('Steadying Patch would restore no Stagger resistance right now.');return}
 const consumableScale=nameBuffMultiplier('consumableMultiplier');
 if(id==='kcorp_ampule'){p.hp=p.maxHp}
 else if(id==='field_dressing'){p.hp=Math.min(p.maxHp,p.hp+Math.round(14*consumableScale));p.stagger=Math.min(p.maxSt,p.stagger+Math.round(6*consumableScale))}
 else if(id==='steadying_patch'){p.stagger=Math.min(p.maxSt,p.stagger+Math.round(12*consumableScale))}
 else{logMsg('This consumable has no combat-use effect configured.');return}
 item.count--;if(item.count<=0)S.inventory.consumables=S.inventory.consumables.filter(c=>c!==item);
 logMsg(`Used ${item.n} during combat. HP ${p.hp}/${p.maxHp} · Stagger ${p.stagger}/${p.maxSt}.`);
 renderBattle();saveSnapshot();
}

function consumeItem(id){
 ensureInventory();const item=S.inventory.consumables.find(c=>c.id===id&&c.count>0);if(!item)return;
 if(id==='kcorp_ampule'){
  const key=currentKeyPage(),stats=keyPageVitals(key,playerLevel()),maxHp=stats.hp+(S.st.Might||0)*2;S.vitals=S.vitals||{hp:maxHp,stagger:stats.stagger+(S.st.Agility||0)*2};
  if(S.vitals.hp>=maxHp){inventoryMessage='K Corp Ampule would restore no HP right now.';renderInventory();return}
  S.vitals.hp=maxHp;item.count--;if(item.count<=0)S.inventory.consumables=S.inventory.consumables.filter(c=>c!==item);inventoryMessage=`Used ${item.n}: HP fully restored to ${maxHp}.`;renderInventory();saveSnapshot();return;
 }
 if(String(id).startsWith('exp_ticket_')){
  const xp=({exp_ticket_1:100,exp_ticket_2:300,exp_ticket_3:700})[id]||0;if(!xp)return;
  {const cap=playerLevelCap();if(playerLevel()>=cap){inventoryMessage=`Your Fixer is already Level ${cap}. EXP Tickets cannot be used at the current level cap${S?.flags?.gradePromoted8?'': ' (Grade 8 promotion raises the cap to 50)'}.`;renderInventory();return}}
  item.count--;if(item.count<=0)S.inventory.consumables=S.inventory.consumables.filter(c=>c!==item);
  const before=playerLevel(),result=applyExperience(xp);inventoryMessage=`Used ${item.n}: +${xp} EXP${result.levels?` · Level ${before} → ${playerLevel()}`:` · Level ${playerLevel()}`}.`;renderInventory();saveSnapshot();return;
 }
 const key=currentKeyPage(),stats=keyPageVitals(key,playerLevel()),hpMax=stats.hp+(S.st.Might||0)*2,stMax=stats.stagger+(S.st.Agility||0)*2;
 S.vitals=S.vitals||{hp:hpMax,stagger:stMax};
 const consumableScale=nameBuffMultiplier('consumableMultiplier');
 if(id==='field_dressing'){S.vitals.hp=Math.min(hpMax,(S.vitals.hp||0)+Math.round(14*consumableScale));S.vitals.stagger=Math.min(stMax,(S.vitals.stagger||0)+Math.round(6*consumableScale))}
 else if(id==='steadying_patch')S.vitals.stagger=Math.min(stMax,(S.vitals.stagger||0)+Math.round(12*consumableScale));
 item.count--;if(item.count<=0)S.inventory.consumables=S.inventory.consumables.filter(c=>c!==item);
 inventoryMessage=`Used ${item.n}. HP ${S.vitals.hp}/${hpMax} · Stagger ${S.vitals.stagger}/${stMax}.`;renderInventory();saveSnapshot();
}
function renderInventory(){
 const inv=ensureInventory(),host=$('#hubInv');if(!host)return;
 const tabs=[['pages','Combat Pages'],['keys','Key Pages'],['books','Books'],['consumables','Consumables'],['body','Body Gear'],['status','Status'],['weapons','Weapons']];
 const lvl=playerLevel(),need=xpToNextLevel(lvl),xp=Math.max(0,Number(S.exp)||0),xpPct=need?Math.min(100,xp/need*100):100;
 host.innerHTML=`<div class="invHeader"><div><div class="loadEyebrow">FIXER RECORD</div><h2>Inventory</h2></div><button type="button" class="invClose" id="hubInvClose" aria-label="Close inventory">×</button></div>
  <div class="levelPanel"><div class="levelPanelTop"><b>FIXER LEVEL ${lvl}/${playerLevelCap()}</b><span>${lvl>=playerLevelCap()?'MAX LEVEL':`${xp} / ${need} EXP`}</span></div><div class="levelTrack"><i style="width:${xpPct}%"></i></div><small>OFF ${lvl} · DEF ${lvl} · Level growth: +0.8% max HP and +0.6% max Stagger per level above 1.${S?.flags?.gradePromoted8?' Cap 50 after Grade 8.':' Cap 30 until Grade 8 promotion.'}</small></div>
  <div class="inventoryTabs">${tabs.map(([id,label])=>`<button type="button" class="inventoryTab ${inventoryTab===id?'on':''}" data-tab="${id}">${label}</button>`).join('')}</div>
  <div class="inventoryHint">${escapeHTML(inventoryMessage||'Stored and equipped records are tracked separately.')}</div><div id="inventoryBody"></div>`;
 host.querySelector('#hubInvClose').onclick=()=>host.classList.remove('on');
 host.querySelectorAll('[data-tab]').forEach(b=>b.onclick=()=>{inventoryTab=b.dataset.tab;inventoryMessage='';renderInventory()});
 const body=host.querySelector('#inventoryBody');
 if(inventoryTab==='pages'){
  const equipped=inv.pages.filter(p=>p.equipped).length,pageGroups=new Map();
  for(const p of inv.pages){if(!pageGroups.has(p.id))pageGroups.set(p.id,{...p,count:0,equippedCount:0,storedCount:0,equippedUid:null,storedUid:null});const g=pageGroups.get(p.id);g.count++;if(p.equipped){g.equippedCount++;g.equippedUid=g.equippedUid||p.uid}else{g.storedCount++;g.storedUid=g.storedUid||p.uid}}
  body.innerHTML=`<div class="inventorySummary"><b>Combat Bookshelf</b><span>${equipped}/9 equipped · ${inv.pages.length} total</span></div><p class="invHelp">Identical Combat Pages stack into one row. Buttons move one copy at a time between the equipped shelf and storage.</p>`+
   ([...pageGroups.values()].map(p=>{const def=window.PAGES[p.id];return `<div class="invItem ${p.equippedCount?'equipped':''}"><div class="invItemTop"><b>${escapeHTML(p.n)}${p.count>1?` <span class="stackCount">×${p.count}</span>`:''}</b><span class="invBadge">${p.equippedCount?`EQUIPPED ×${p.equippedCount}`:'STORED'}</span></div><span>${p.storedCount?`Stored ×${p.storedCount} · `:''}Cost ${def.c} · ${escapeHTML(diceStr(def.dice))}</span><div class="invActionsRow">${p.storedUid?`<button type="button" class="invAction" data-page="${escapeHTML(p.storedUid)}">Equip one</button>`:''}${p.equippedUid?`<button type="button" class="invAction" data-page="${escapeHTML(p.equippedUid)}">Store one</button>`:''}</div></div>`}).join('')||'<div class="invEmpty">No Combat Pages. Accept a Fixer job to receive the basic bookshelf.</div>');
  body.querySelectorAll('[data-page]').forEach(b=>b.onclick=()=>togglePageEquipped(b.dataset.page));
 }else if(inventoryTab==='keys'){
  const all=[window.KEY_PAGES.grade9,...[...new Set(inv.keys.map(k=>k.id))].map(id=>window.KEY_PAGES[id])].filter(Boolean),equippedId=S.equipment.keyPage||'grade9';
  body.innerHTML=`<div class="inventorySummary"><b>Character / Key Page</b><span>1 equipped</span></div><p class="invHelp">Your level increases Offense and Defense Level. Key Page stats stay distinct; the green numbers show the extra HP and Stagger added by your current Fixer Level.</p>`+all.map(k=>{const count=k.id==='grade9'?1:inv.keys.filter(x=>x.id===k.id).length,scaled=keyPageVitals(k,lvl);return `<div class="invItem ${k.id===equippedId?'equipped':''}"><div class="invItemTop"><b>${escapeHTML(k.n)}${count>1?` <span class="stackCount">×${count}</span>`:''}</b><span class="invBadge">${k.id===equippedId?'EQUIPPED':'KEY PAGE'}</span></div><span>HP ${k.hp} <b class="levelBonus">+${scaled.hpBonus}</b> · Stagger ${k.stagger} <b class="levelBonus">+${scaled.staggerBonus}</b></span><span>Offense Level ${lvl+(k.offLevel||0)} · Defense Level ${lvl+(k.defLevel||0)}</span><span><b>${escapeHTML(k.passive?.n||'No passive')}</b> — ${escapeHTML(k.passive?.desc||'No passive effect.')}</span><button type="button" class="invAction" data-key="${escapeHTML(k.id)}" ${k.id===equippedId?'disabled':''}>${k.id===equippedId?'Currently equipped':'Equip Key Page'}</button></div>`}).join('');
  body.querySelectorAll('[data-key]').forEach(b=>b.onclick=()=>equipKeyPage(b.dataset.key));
 }else if(inventoryTab==='books'){
  body.innerHTML=`<p class="invHelp">Extract a book to receive one Combat Page from that guest's used-page pool. Some character books have a 32% chance to produce that guest's Key Page.</p>`+(inv.books.map(b=>`<div class="invItem"><div class="invItemTop"><b>${escapeHTML(b.n)}</b><span class="invBadge">UNEXTRACTED</span></div><span>${escapeHTML((window.BOOK_DATA[b.id]?.pages||[]).map(id=>window.PAGES[id]?.n||id).join(' · '))}</span><button type="button" class="invAction" data-book="${escapeHTML(b.uid)}">Extract Book</button></div>`).join('')||'<div class="invEmpty">No Books yet. Defeat an encounter and take its recovered Books here.</div>');
  body.querySelectorAll('[data-book]').forEach(b=>b.onclick=()=>extractBook(b.dataset.book));
 }else if(inventoryTab==='consumables'){
  body.innerHTML=`<p class="invHelp">Consumables can be used during combat to recover HP or Stagger. Resting at home fully restores vitality between missions.</p>`+(inv.consumables.map(c=>`<div class="invItem"><div class="invItemTop"><b>${escapeHTML(c.n)}</b><span class="invBadge">×${c.count}</span></div><span>${escapeHTML(c.desc||'')}</span><button type="button" class="invAction" data-consume="${escapeHTML(c.id)}">Use</button></div>`).join('')||'<div class="invEmpty">No consumables in storage.</div>');
  body.querySelectorAll('[data-consume]').forEach(b=>b.onclick=()=>consumeItem(b.dataset.consume));
 }else if(inventoryTab==='body'){
  const bodySlots=window.BODY_SLOTS||[];const eq=S.equipment.body||{};const totals={hp:gearBonus('hpBonus'),st:gearBonus('staggerBonus'),off:gearBonus('offLevel'),def:gearBonus('defLevel')};
  const slotHtml=bodySlots.map(slot=>{const id=eq[slot.id],item=id?window.GEAR_DATA[id]:null;return `<div class="bodySlot ${item?'equipped':''}"><div><b>${escapeHTML(slot.label)}</b><span>${escapeHTML(item?.name||'Empty')}</span></div>${item?`<button type="button" class="invAction" data-gear="${escapeHTML(id)}">Unequip</button>`:''}</div>`}).join('');
  const gearHtml=inv.gear.map(g=>{const d=window.GEAR_DATA[g.id],on=eq[d.slot]===g.id;return `<div class="invItem ${on?'equipped':''}"><div class="invItemTop"><b>${escapeHTML(d.name)}</b><span class="invBadge">${on?'EQUIPPED':'STORED'}</span></div><span>${escapeHTML(d.desc)} · Slot: ${escapeHTML(bodySlots.find(x=>x.id===d.slot)?.label||d.slot)}</span><button type="button" class="invAction" data-gear="${escapeHTML(d.id)}">${on?'Unequip':'Equip'}</button></div>`}).join('');
  body.innerHTML=`<div class="inventorySummary"><b>Body Equipment</b><span>${Object.values(eq).filter(Boolean).length}/${bodySlots.length} slots</span></div><div class="bodyProfile">${bodyModelMarkup()}<div><b>Equipment bonuses</b><span>+${totals.hp} max HP</span><span>+${totals.st} max Stagger</span><span>+${totals.off} Offense Level</span><span>+${totals.def} Defense Level</span><small>Choose gear for individual body parts. Your silhouette follows the pronouns selected when creating this Fixer.</small></div></div><div class="bodySlotList">${slotHtml}</div><div class="invSectionTitle">Owned Body Gear / Prosthetics / Augmentations</div>${gearHtml||'<div class="invEmpty">No body equipment owned. Buy fitting parts at Market Street or authorized Nest counters.</div>'}`;
  body.querySelectorAll('[data-gear]').forEach(b=>b.onclick=()=>toggleGear(b.dataset.gear));
 }else if(inventoryTab==='status'){
  const rep=Math.max(0,Math.min(100,Number(S.reputation)||0));
  body.innerHTML=`<div class="inventorySummary"><b>Fixer Status</b><span>${gradeTitle()} · Level ${lvl}</span></div><div class="repPanel"><div class="repTop"><b>REPUTATION</b><strong>${rep}/100</strong></div><div class="repTrack" role="progressbar" aria-label="Reputation" aria-valuemin="0" aria-valuemax="100" aria-valuenow="${rep}"><i style="width:${rep}%"></i></div><p>${rep>=65?'Your record is generally regarded positively.':rep<=35?'Your record raises concern among people who have read it.':'Your reputation remains mixed.'} Special dialogue can check high or low reputation.</p></div><div class="invSectionTitle">Core Attributes</div><div class="attributeGrid">${['Might','Agility','Wit','Nerve'].map(k=>`<div><b>${Number(S.st?.[k])||0}</b><span>${k}</span></div>`).join('')}<div><b>${unitOffenseLevel(B?.player||{level:lvl})}</b><span>Offense</span></div><div><b>${unitDefenseLevel(B?.player||{level:lvl})}</b><span>Defense</span></div></div><p class="invHelp">Reputation changes at most once per office on first completion. Replays do not change it.</p>`;
 }else{
  const ids=[...new Set(inv.weapons.map(w=>w.id))],slots=S.equipment.weapons||[null,null];
  body.innerHTML=`<div class="inventorySummary"><b>Weapon Slots</b><span>${slots.filter(Boolean).length}/2 equipped</span></div><div class="weaponSlots"><div>Slot 1 <b>${escapeHTML(window.WEAPON_DATA[slots[0]]?.n||'Empty')}</b></div><div>Slot 2 <b>${escapeHTML(window.WEAPON_DATA[slots[1]]?.n||'Empty')}</b></div></div><p class="invHelp">Two equipment slots maximum. Effects are implemented as small in-game dice bonuses.</p>`+(ids.map(id=>{const w=window.WEAPON_DATA[id],on=slots.includes(id);return `<div class="invItem ${on?'equipped':''}"><div class="invItemTop"><b>${escapeHTML(w.n)}</b><span class="invBadge">${on?'EQUIPPED':'STORED'}</span></div><span>${escapeHTML(w.desc)}</span><button type="button" class="invAction" data-weapon="${escapeHTML(id)}">${on?'Unequip':'Equip'}</button></div>`}).join('')||'<div class="invEmpty">No equipment recorded yet.</div>');
  body.querySelectorAll('[data-weapon]').forEach(b=>b.onclick=()=>toggleWeapon(b.dataset.weapon));
 }
}
function missionUnlocked(id){
 const m=window.CANARD_MISSIONS?.[id];if(!m)return false;
 if(id==='yunOffice'&&!S.flags.ratsCleared)return false;
 if(m.unlockAfter==='rats'&&!S.flags.ratsCleared)return false;
 if(m.unlockAfter&&!['rats'].includes(m.unlockAfter)&&!(S.flags.completedMissions||[]).includes(m.unlockAfter))return false;
 const required=MISSION_LEVEL_REQUIREMENTS[id]||1;return playerLevel()>=required;
}
function startMission(id){
 const m=window.CANARD_MISSIONS?.[id];if(!m)return;if(!missionUnlocked(id)){const req=MISSION_LEVEL_REQUIREMENTS[id]||1;$('#hubText').textContent=`This contract is not available yet. Required Fixer Level: ${req}. Current Level: ${playerLevel()}. Train by replaying completed contracts or purchase EXP Tickets at the Market.`;return}
 $('#story').classList.remove('urban-myth-prologue');
 const completed=window.CityCanon?.isMissionCompleted?.(S?.flags,id)||false;
 S.flags.pendingCanonicalOutcomes=S.flags.pendingCanonicalOutcomes||{};
 if(!completed)delete S.flags.pendingCanonicalOutcomes[id];
 S.pendingMission=null;S.flags.activeMission=id;
 // Completed receptions replay their original in-world dialogue and choices. The
 // office board is a replay entry point, not a fourth-wall narration device.
 script=[...m.start];
 i=-1;ready=false;typing=null;currentBg=script.find(n=>n.bg)?.bg||'back';
 fadeTo(()=>{clearVN();$('#dlg').style.display='';$('#pick').style.display='none';setBg(currentBg,true);show('story');next()});
}
function finishMission(id){
 const missionId=id||'rats';
 ensureInventory();
 S.flags=S.flags||{};S.flags.completedMissions=S.flags.completedMissions||[];
 const firstCanonicalClear=window.CityCanon?.isMissionCompleted?.(S.flags,missionId)!==true;
 const selectedOutcome=S.flags.pendingCanonicalOutcomes?.[missionId]||'fight';
 if(firstCanonicalClear)window.CityCanon?.commitMission?.(S.flags,missionId,selectedOutcome);
 S.flags.reputationApplied=S.flags.reputationApplied||{};
 if(firstCanonicalClear&&['yunOffice','brotherhood','hookOffice'].includes(missionId)&&!S.flags.reputationApplied[missionId]){
  const delta=selectedOutcome==='helped'?12:-8;S.reputation=Math.max(0,Math.min(100,(Number.isFinite(Number(S.reputation))?Number(S.reputation):50)+delta));S.flags.reputationApplied[missionId]=true;
  S.flags.reputationHistory=S.flags.reputationHistory||{};S.flags.reputationHistory[missionId]=delta;
  inventoryMessage=`Reputation ${delta>0?'+':''}${delta} (${S.reputation}/100).`;
 }
 if(S.flags.pendingCanonicalOutcomes)delete S.flags.pendingCanonicalOutcomes[missionId];
 if(missionId==='rats')S.flags.ratsCleared=true;
 else if(!S.flags.completedMissions.includes(missionId))S.flags.completedMissions.push(missionId);
 // Commit payout and Books only at the official mission end. Non-combat delivery routes
 // still receive their contract fee, but cannot award Books from a fight that never happened.
 const pending=S.pendingMission&&S.pendingMission.id===missionId?S.pendingMission:null;
 // Help route (Brotherhood): thanks payment only — no Books, no EXP, no crate gear.
 const helpedPeaceful=selectedOutcome==='helped'&&missionId==='brotherhood';
 const BROTHERHOOD_THANKS=2500;
 let basePayment;
 if(helpedPeaceful){
  basePayment=BROTHERHOOD_THANKS;
 }else{
  basePayment=pending?Math.max(0,Number(pending.payment)||MISSION_PAY[missionId]||1000):(MISSION_PAY[missionId]||1000);
 }
 const payment=Math.round(basePayment*nameBuffMultiplier('ahnMultiplier'));
 S.ahn=Math.max(0,Number(S.ahn)||0)+payment;
 const recovered=[];
 if(pending&&!helpedPeaceful){
  for(const entry of (pending.bookDrops||[])){
   const data=window.BOOK_DATA?.[entry.id];if(!data)continue;
   S.inventory.books.push({uid:nextUid('book'),id:entry.id,n:data.n});recovered.push(data.n);
  }
 }
 // Crate / office gear only on combat-clear paths.
 const rewardId=(!helpedPeaceful&&missionId==='brotherhood')?'workshop_blade':(missionId==='hookOffice'?'hook_tool':null);
 if(rewardId&&window.WEAPON_DATA?.[rewardId]&&!S.inventory.weapons.some(w=>w.id===rewardId))S.inventory.weapons.push({id:rewardId,n:window.WEAPON_DATA[rewardId].n});
 const expReward=helpedPeaceful?0:(pending?Math.max(0,Math.floor(Number(pending.expEarned)||0)):0);
 const beforeLevel=playerLevel();const expResult=applyExperience(expReward);
 S.flags.activeMission=null;S.pendingMission=null;B=null;
 let gradeNote='';
 const officesDone=['yunOffice','brotherhood','hookOffice'].every(oid=>(S.flags.completedMissions||[]).includes(oid));
 if(officesDone&&!S.flags.gradePromoted8){
  S.flags.gradePromoted8=true;S.grade=8;
  gradeNote=' Hana Association records have been updated: you are promoted to Grade 8 Fixer. Level cap is now 50. Urban Myth opens on the Fixer Office board.';
 }
 const missionName=missionId==='rats'?'Rats — First Contract':(window.CANARD_MISSIONS?.[missionId]?.name||'The contract');
 const payLabel=helpedPeaceful?`Brotherhood thanks · +${payment.toLocaleString('en-US')} Ahn (no Books, no EXP)`:`+${payment.toLocaleString('en-US')} Ahn · +${expReward} EXP${expResult.levels?` · Level ${beforeLevel} → ${playerLevel()}`:''}${recovered.length?`; recovered Books: ${recovered.join(', ')}`:''}${rewardId?'; crate gear recovered':''}`;
 inventoryMessage=`${missionName} officially completed. ${payLabel}.${firstCanonicalClear&&['yunOffice','brotherhood','hookOffice'].includes(missionId)?` Reputation ${S.flags.reputationHistory?.[missionId]>0?'+':''}${S.flags.reputationHistory?.[missionId]||0} (${S.reputation}/100).`:''}${gradeNote}`;
 fadeTo(()=>{clearVN();showHub();$('#hubText').textContent=inventoryMessage;inventoryTab='books';renderInventory();saveSnapshot()});
}
function urbanMythUnlocked(){
 const flags=S?.flags||{};
 const completed=Array.isArray(flags.completedMissions)?flags.completedMissions:[];
 const officesDone=['yunOffice','brotherhood','hookOffice'].every(id=>completed.includes(id));
 const refreshPending=Object.keys(flags.canonicalRefreshPending||{}).length>0;
 return !!(officesDone&&!refreshPending)||!!flags.gradePromoted8;
}
function startUrbanMythPrologue(){
 const flags=S?.flags||{};
 if(!urbanMythUnlocked()){
  const t=$('#hubText');if(t)t.textContent='Finish the three Canard office receptions (and any re-register markers) before the Hana Association examination opens.';
  return;
 }
 const need=MISSION_LEVEL_REQUIREMENTS.urbanMythExam||22;
 if(playerLevel()<need){
  const t=$('#hubText');if(t)t.textContent=`The Hana Association examination requires Level ${need}. Train further, then return.`;
  return;
 }
 const build=window.URBAN_MYTH_DIALOGUE?.buildHanaExamination;
 if(typeof build!=='function'){
  const t=$('#hubText');if(t)t.textContent='Urban Myth dialogue data could not be loaded. Check that data/dialogues/Urban-Myth/hana-examination.js is present.';
  return;
 }
 const scriptLines=build({playerName:S.name,flags,reputation:S.reputation});
 if(!Array.isArray(scriptLines)||!scriptLines.length){
  const t=$('#hubText');if(t)t.textContent='Urban Myth dialogue returned empty. Check hana-examination.js.';
  return;
 }
 S.flags=S.flags||{};S.flags.urbanMythStarted=true;
 script=scriptLines;i=-1;ready=false;typing=null;currentBg='void';
 fadeTo(()=>{
  clearVN();$('#dlg').style.display='';$('#pick').style.display='none';
  $('#story').classList.remove('urban-myth-test');$('#story').classList.add('urban-myth-prologue');setBg('void',true);$('#loc').textContent='';show('story');next();
 });
}

function showHub(place=null){
 ensureInventory();closeHubPanels();
 const homeKey=homeBackgroundKey(),homeName=homeLocationName();
 const current=place||{key:homeKey,name:homeName,text:'You are home. Rest here, review your records, or travel.'};
 const isHome=current.name===homeName;
 const bg=$('#hubBg');if(bg)bg.className='hubBackground bg-'+current.key;
 $('#hubLoc').textContent=current.name;
 $('#hubOrigin').textContent=(isOutskirtsBorn()?'OUTSKIRTS ORIGIN':(isNestBorn()?'NEST ORIGIN':'BACKSTREETS ORIGIN'))+' · '+(S.ahn||0).toLocaleString('en-US')+' AHN';
 $('#hubTitle').textContent=isHome?'Home':current.name;$('#hubText').textContent=current.text;
 renderInventory();
 const nav=$('#hubNav');if(!nav)return;
 nav.innerHTML='<section class="travelPanel"><div class="travelPanelTitle">TRAVEL ROUTES</div><div class="travelGrid" id="hubTravelGrid"></div></section><div class="hubActions" id="hubActions"></div>';
 const actionHost=nav.querySelector('#hubActions'),travelGrid=nav.querySelector('#hubTravelGrid');
 const add=(label,action,locked=false)=>{const b=document.createElement('button');b.type='button';b.className='btn'+(locked?' hubLocked':'');b.textContent=label+(locked?' 🔒':'');b.disabled=!!locked;b.onclick=action;actionHost.appendChild(b);return b};
 const isAllowedNest=isNestBorn()||!!S.flags.nestPermit||!!S.flags.nestTicket;
 // Six fixed route slots keep button positions stable on every location screen.
 const routeDefs=[
  {key:'back',label:'🌆 Backstreets',name:'Backstreets',text:'Rows of patched buildings, late-night stalls, and narrow roads. The local patrol contract starts here.'},
  {key:'office',label:'🏢 Fixer Office Frontage',name:'Fixer Office Frontage',text:'A battered counter and a contract board. This is where Canard jobs are accepted and completed reports are filed.'},
  {key:'workshop',label:'🔧 Workshop Row',name:'Workshop Row',text:'Independent Workshops line the street. Review equipment records here; the Market sells recovery supplies and travel tickets.'},
  {key:'market',label:'🛒 Market Street',name:'Market Street',text:'Stalls, repair counters, and vendors. The item catalogue and full item descriptions are available only while you are here.'},
  {key:'checkpoint',label:'🚧 Nest Checkpoint',name:'Nest Checkpoint',text:'A guarded checkpoint. Entry requires going through this gate and presenting a Nest transit ticket or a valid Nest origin/permit record.'},
  {key:'nest',label:'🏙️ The Nest',name:'The Nest',text:'A Wing-governed district with strict entry rules.'}
 ];
 const currentKey=current.key||(isHome?'home':'back');
 const routeMap={
  home:['back'],back:['office','workshop','market','checkpoint'],office:['back'],workshop:['back','market'],market:['back','workshop'],checkpoint:['back',...(isAllowedNest?['nest']:[])],nest:['checkpoint']
 };
 const reachable=routeMap[currentKey]||['back'];
 for(const dest of routeDefs){
  const slot=document.createElement('div');slot.className='travelSlot';
  if(dest.key!==currentKey&&reachable.includes(dest.key)){
   const b=document.createElement('button');b.type='button';b.className='btn travelBtn';b.textContent=dest.label;b.onclick=()=>fadeTo(()=>showHub({key:dest.key,name:dest.name,text:dest.text}));slot.appendChild(b);
  }else{slot.classList.add('travelSlotEmpty');slot.setAttribute('aria-hidden','true')}
  travelGrid.appendChild(slot);
 }

 // Home controls remain separate from travel. Market item descriptions appear only in Market Street.
 if(isHome){
  add('🛏️ Rest · fully recover',()=>{const k=currentKeyPage(),scaled=keyPageVitals(k,playerLevel()),hp=scaled.hp+(S.st.Might||0)*2,st=scaled.stagger+(S.st.Agility||0)*2;S.vitals={hp,stagger:st,keyPage:k.id};$('#hubText').textContent='You shut the door, eat something cheap, and let the strain pass. HP and Stagger are fully restored.';inventoryMessage='Rested to full vitality.';renderInventory();saveSnapshot()});
  add('📂 Review your records',()=>{inventoryTab='status';renderInventory();openHubPanel('#hubInv')});
  // Apartment Urban Myth entry: only before the exam is cleared. No replay here.
  if(!S.flags.urbanMythExamCleared&&['yunOffice','brotherhood','hookOffice'].every(id=>(S.flags.completedMissions||[]).includes(id))){
   const refreshIds=['yunOffice','brotherhood','hookOffice'].filter(id=>S.flags.canonicalRefreshPending?.[id]);
   if(refreshIds.length){
    const labels={yunOffice:"Yun's Office",brotherhood:'Brotherhood of Iron',hookOffice:'Hook Office'};
    add('📌 Register updated story choices first',()=>{$('#hubText').textContent='This save has older reception data. Revisit each office marked “Re-register story choices” on the Fixer Office board once: '+refreshIds.map(id=>labels[id]).join(', ')+'. Your existing Reputation will not be awarded again. Grade 8 and Urban Myth open after these records are refreshed.'});
   }else if(urbanMythUnlocked()){
    const need=MISSION_LEVEL_REQUIREMENTS.urbanMythExam||22;
    const readyLv=playerLevel()>=need;
    add(
     readyLv?'🜂 Enter Urban Myth · Hana Association examination':`🜂 Hana Examination · Lv ${need} required`,
     ()=>startUrbanMythPrologue(),
     !readyLv
    );
   }
  }
 }else add('🏠 Return Home',()=>fadeTo(()=>showHub()));

 if(current.key==='back'){
  // First Rats contract only. Replays live on the Fixer Office board.
  if(!S.flags.ratsCleared)add('🐀 Begin the first patrol contract',()=>startJob());
  add('🔎 Ask around about the delivery dispute',()=>{S.flags=S.flags||{};S.flags.backstreetsRumorHeard=true;$('#hubText').textContent='A stallkeeper says the missing parcel passed through Workshop Row before anyone logged it. You mark the route in your notes.';saveSnapshot()});
  if(S.flags.ratsCleared&&!S.flags.completedMissions?.includes('yunOffice'))add(missionUnlocked('yunOffice')?'📑 Follow the ledger trail — Yun’s Office':'📑 Ledger trail reported · train to the required Level',()=>{if(missionUnlocked('yunOffice'))startMission('yunOffice');else $('#hubText').textContent=`The ledger trail is there, but this contract requires Level ${MISSION_LEVEL_REQUIREMENTS.yunOffice}. Replay completed jobs or use EXP Tickets before approaching the situation.`});
  else if(S.flags.completedMissions?.includes('yunOffice')&&!S.flags.completedMissions?.includes('brotherhood'))add(missionUnlocked('brotherhood')?'⚙️ Investigate the missing shipment — Brotherhood of Iron':'⚙️ Shipment trail reported · train to the required Level',()=>{if(missionUnlocked('brotherhood'))startMission('brotherhood');else $('#hubText').textContent=`The Workshop Row clue requires Level ${MISSION_LEVEL_REQUIREMENTS.brotherhood}. Prepare before getting involved.`});
  else if(S.flags.completedMissions?.includes('brotherhood')&&!S.flags.completedMissions?.includes('hookOffice'))add(missionUnlocked('hookOffice')?'🪝 Follow the altered receipt — Hook Office':'🪝 Receipt trail reported · train to the required Level',()=>{if(missionUnlocked('hookOffice'))startMission('hookOffice');else $('#hubText').textContent=`The Hook Office trail requires Level ${MISSION_LEVEL_REQUIREMENTS.hookOffice}. Prepare before approaching them.`});
 }else if(current.key==='office'){
  // ── Canard panel (always available) ──
  const canardBox=document.createElement('div');canardBox.className='missionList';
  canardBox.innerHTML='<div class="missionLabel">📜 CANARD · RECEPTION BOARD</div>';
  const balance=document.createElement('div');balance.className='missionLabel';balance.textContent=(S.ahn||0).toLocaleString('en-US')+' AHN · '+gradeTitle();canardBox.appendChild(balance);
  const rat=document.createElement('button');rat.type='button';rat.className='btn';rat.textContent=S.flags.ratsCleared?'🐀 Rats · Replay / Ahn farming':'🐀 Rats · First Contract';rat.onclick=()=>startJob();canardBox.appendChild(rat);
  for(const id of (window.CANARD_MISSION_ORDER||[])){
   const m=window.CANARD_MISSIONS[id];if(!m)continue;
   const b=document.createElement('button');b.type='button';b.className='btn';
   const icons={yunOffice:'🗂️',brotherhood:'⚙️',hookOffice:'🪝'};
   const done=(S.flags.completedMissions||[]).includes(id),refresh=!!S.flags.canonicalRefreshPending?.[id],required=MISSION_LEVEL_REQUIREMENTS[id]||1,unlocked=missionUnlocked(id);
   b.textContent=(icons[id]||'📜')+' '+m.name+(refresh?' · Re-register (one time)':done?' · Replay':unlocked?' · Available':` · Lv ${required}`);
   b.disabled=!done&&!unlocked;
   b.title=refresh?'Older save: re-run once so the chosen outcome is registered. Reputation is not re-awarded.':done?'Replay with original dialogue and choices. Canon is protected.':unlocked?'Start the reception story from the field route.':`Requires Level ${required}.`;
   b.onclick=()=>{if(done||unlocked)startMission(id)};
   canardBox.appendChild(b);
  }
  actionHost.appendChild(canardBox);

  // ── Urban Myth panel (unlocked after Canard offices / Grade 8; exam needs Lv 22) ──
  const mythBox=document.createElement('div');mythBox.className='missionList';
  const mythOpen=urbanMythUnlocked();
  const examNeed=MISSION_LEVEL_REQUIREMENTS.urbanMythExam||22;
  const examReady=playerLevel()>=examNeed;
  mythBox.innerHTML='<div class="missionLabel">🜂 URBAN MYTH · RECEPTION BOARD</div>';
  if(!mythOpen){
   const locked=document.createElement('div');locked.className='missionLabel';locked.textContent='Locked · Complete Yun’s Office, Brotherhood of Iron, and Hook Office to open this panel.';mythBox.appendChild(locked);
  }else{
   const mythBtn=document.createElement('button');mythBtn.type='button';mythBtn.className='btn'+(examReady?'':' hubLocked');
   mythBtn.disabled=!examReady;
   mythBtn.textContent=S.flags.urbanMythExamCleared
    ?(examReady?'🜂 Hana Examination · Replay Fairy Festival':`🜂 Hana Examination · Lv ${examNeed} required`)
    :(examReady?'🜂 Hana Association Examination · Fairy Festival':`🜂 Hana Examination · Lv ${examNeed} required`);
   mythBtn.title=examReady?'Begin the Hana Association examination.':`Requires Fixer Level ${examNeed}. Current level: ${playerLevel()}.`;
   mythBtn.onclick=()=>{if(examReady)startUrbanMythPrologue();else{const t=$('#hubText');if(t)t.textContent=`The Hana Association examination requires Level ${examNeed}. You are Level ${playerLevel()}.`;}};
   mythBox.appendChild(mythBtn);
  }
  actionHost.appendChild(mythBox);

  add('🧾 Read the contract clerk’s notice',()=>{$('#hubText').textContent='Canard receptions stay on this board permanently. Urban Myth opens after your Grade 8 promotion. An encounter is not a completed job until the follow-up report finishes; leaving mid-fight abandons the attempt.'});
 }else if(current.key==='market'){
  const shopBox=document.createElement('div');shopBox.className='missionList marketGoods';shopBox.innerHTML='<div class="missionLabel">🛒 MARKET CATALOGUE · PRICES IN AHN</div><p class="shopIntro">Item details are shown here, at the market—not in your apartment or on the travel board.</p>';
  const goods=[
   {id:'field_dressing',name:'Field Dressing',price:1200,desc:'Restores 14 HP and 6 Stagger in combat.',kind:'consumable'},
   {id:'steadying_patch',name:'Steadying Patch',price:900,desc:'Restores 12 Stagger in combat.',kind:'consumable'},
   {id:'exp_ticket_1',name:'EXP Ticket Tier I',price:600,desc:'Grants 100 EXP. Use from Inventory to train your Fixer.',kind:'expTicket',exp:100},
   {id:'exp_ticket_2',name:'EXP Ticket Tier II',price:1800,desc:'Grants 300 EXP. Use from Inventory to train your Fixer.',kind:'expTicket',exp:300},
   {id:'exp_ticket_3',name:'EXP Ticket Tier III',price:3500,desc:'Grants 700 EXP. Use from Inventory to train your Fixer.',kind:'expTicket',exp:700},
   {id:'workshop_blade',name:'Workshop Practice Blade',price:12000,desc:'A basic Workshop-made item. Its gameplay bonus is listed in your equipment inventory.',kind:'weapon'},
   {id:'hook_tool',name:'Hook Office Tool',price:15000,desc:'A specialised Workshop item. Its gameplay bonus is listed in your equipment inventory.',kind:'weapon'},
   {id:'nest_transit_ticket',name:'Nest Transit Ticket',price:2000,desc:'A valid travel pass for the Nest checkpoint. Purchase it here, then return through the Backstreets to reach the checkpoint.',kind:'ticket'},
   ...Object.values(window.GEAR_DATA||{}).filter(g=>!g.nestOnly).map(g=>({id:g.id,name:g.name,price:g.price,desc:g.desc,kind:'gear'}))
  ];
  for(const item of goods){
   const card=document.createElement('div');card.className='marketItem';
   const owned=(item.kind==='weapon'&&S.inventory.weapons.some(w=>w.id===item.id))||(item.kind==='ticket'&&!!S.flags.nestTicket)||(item.kind==='gear'&&S.inventory.gear.some(g=>g.id===item.id));
   card.innerHTML=`<div class="marketItemTop"><b>${escapeHTML(item.name)}</b><span class="marketPrice">${item.price.toLocaleString('en-US')} Ahn</span></div><p class="marketDesc">${escapeHTML(item.desc)}</p><button type="button" class="invAction" ${owned?'disabled':''}>${owned?(item.kind==='ticket'?'Purchased':'Owned'):`Buy · ${item.price.toLocaleString('en-US')} Ahn`}</button>`;
   const button=card.querySelector('button');button.onclick=()=>{
    if((S.ahn||0)<item.price){inventoryMessage=`Not enough Ahn. ${item.price.toLocaleString('en-US')} required; you have ${(S.ahn||0).toLocaleString('en-US')}.`;$('#hubText').textContent=inventoryMessage;return}
    S.ahn-=item.price;
    if(item.kind==='consumable'||item.kind==='expTicket'){
     const existing=S.inventory.consumables.find(c=>c.id===item.id);if(existing)existing.count++;else S.inventory.consumables.push({id:item.id,n:item.name,desc:item.desc,count:1,exp:item.exp||0});
    }else if(item.kind==='ticket')S.flags.nestTicket=true;
    else if(item.kind==='gear')S.inventory.gear.push({id:item.id,name:item.name});
    else S.inventory.weapons.push({id:item.id,n:window.WEAPON_DATA[item.id].n});
    inventoryMessage=`Purchased ${item.name} for ${item.price.toLocaleString('en-US')} Ahn.`;saveSnapshot();showHub(current);
   };
   shopBox.appendChild(card);
  }
  actionHost.appendChild(shopBox);
 }else if(current.key==='workshop'){
  add('🧰 Review Workshop and equipment records',()=>{inventoryTab='weapons';renderInventory();openHubPanel('#hubInv')});
  add('📋 Read the fitting notice',()=>{$('#hubText').textContent='The fitters will check what you already own before quoting a new part. Open Inventory → Weapons to view equipment and its current gameplay effects.'});
 }else if(current.key==='checkpoint'){
  add('🪪 Present your travel documents',()=>{S.flags=S.flags||{};S.flags.checkpointChecked=true;$('#hubText').textContent=isAllowedNest?'The checkpoint verifies your Nest transit ticket or origin/permit record. The gate to the Nest is open.':'The checkpoint clerk asks for a Nest transit ticket. Buy one at Market Street, then return through the Backstreets to reach this gate.';saveSnapshot()});
  if(isAllowedNest)add('🏙️ Pass through into the Nest',()=>fadeTo(()=>showHub({key:'nest',name:'The Nest',text:'The checkpoint verifies your documents and lets you through. The Nest is quieter than the Backstreets, but every door has its own rules.'})));
 }else if(current.key==='nest'){
  add('📌 Read the Wing bulletin',()=>{S.flags=S.flags||{};S.flags.nestNoticeRead=true;$('#hubText').textContent='The Wing bulletin lists curfew times, visitor rules, and fees for unregistered work. The place is clean; the notices make sure everyone remembers who owns it.';saveSnapshot()});
  const shopBox=document.createElement('div');shopBox.className='missionList marketGoods';shopBox.innerHTML='<div class="missionLabel">🏙️ WING-AUTHORIZED EQUIPMENT COUNTER</div><p class="shopIntro">Regulated medical supplies, prosthetics, optics, and high-grade body augmentation. Prices are in Ahn.</p>';
  const nestGoods=[
   {id:'kcorp_ampule',name:'K Corp Ampule',price:5000,desc:'A sealed recovery item that restores HP to 100% of maximum. Usable from Inventory or during combat.',kind:'consumable'},
   ...Object.values(window.GEAR_DATA||{}).filter(g=>g.nestOnly).map(g=>({id:g.id,name:g.name,price:g.price,desc:g.desc,kind:'gear'})),
   ...Object.values(window.WEAPON_DATA||{}).filter(w=>w.nestOnly).map(w=>({id:w.id,name:w.n,price:w.price,desc:w.desc,kind:'weapon'}))
  ];
  for(const item of nestGoods){
   const owned=item.kind==='gear'?S.inventory.gear.some(g=>g.id===item.id):item.kind==='weapon'?S.inventory.weapons.some(w=>w.id===item.id):false;
   const card=document.createElement('div');card.className='marketItem';
   card.innerHTML=`<div class="marketItemTop"><b>${escapeHTML(item.name)}</b><span class="marketPrice">${item.price.toLocaleString('en-US')} Ahn</span></div><p class="marketDesc">${escapeHTML(item.desc)}</p><button type="button" class="invAction" ${owned?'disabled':''}>${owned?'Owned':`Buy · ${item.price.toLocaleString('en-US')} Ahn`}</button>`;
   card.querySelector('button').onclick=()=>{
    if((S.ahn||0)<item.price){inventoryMessage=`Not enough Ahn. ${item.price.toLocaleString('en-US')} required; you have ${(S.ahn||0).toLocaleString('en-US')}.`;$('#hubText').textContent=inventoryMessage;return}
    S.ahn-=item.price;
    if(item.kind==='consumable'){const existing=S.inventory.consumables.find(c=>c.id===item.id);if(existing)existing.count++;else S.inventory.consumables.push({id:item.id,n:item.name,desc:item.desc,count:1})}
    else if(item.kind==='weapon')S.inventory.weapons.push({id:item.id,n:window.WEAPON_DATA[item.id].n});
    else S.inventory.gear.push({id:item.id,name:item.name});
    inventoryMessage=`Purchased ${item.name}.`;saveSnapshot();showHub(current)
   };
   shopBox.appendChild(card)
  }
  actionHost.appendChild(shopBox);
 }
 show('hub');saveSnapshot();
}
function openHubPanel(id){
 const el=$(id);if(!el)return;
 document.querySelectorAll('.hubSide').forEach(s=>s.classList.remove('on'));
 el.classList.add('on');
}
function toggleHubPanel(id){
 const el=$(id);if(!el)return;
 const wasOpen=el.classList.contains('on');
 closeHubPanels();
 if(!wasOpen)el.classList.add('on');
}
function closeHubPanels(){document.querySelectorAll('.hubSide').forEach(s=>s.classList.remove('on'))}
function ratsTalk(){
  // First time the trio is allowed on screen.
  // NOTE: ensureVN() never existed — calling it threw and soft-locked the alley scene.
  try{
   enterVN('Pete','left');
   setSpeaker('Pete','left');
  }catch(err){console.warn('ratsTalk stage setup failed',err)}
  ready=true;
  if($('#next'))$('#next').style.visibility='visible';
  if($('#dlg'))$('#dlg').style.display='';
  if($('#pick'))$('#pick').style.display='none';
  saveSnapshot();
}



function start(){
 closeHubPanels();clearVN();B=null;
 if(typing&&typing.t)clearTimeout(typing.t);typing=null;if(rollTimer)clearInterval(rollTimer);rollTimer=null;
 const d=document.documentElement;
 (d.requestFullscreen?d.requestFullscreen():Promise.reject()).then(()=>screen.orientation.lock('landscape')).catch(()=>{});
 fadeTo(()=>{
  S={name:'',gender:'they/them',pronouns:'they/them',bodyShape:'bald',reputation:50,tags:[],st:{Might:0,Agility:0,Wit:0,Nerve:0},
   inventory:{pages:[],keys:[],books:[],consumables:[],weapons:[],gear:[]},
   equipment:{keyPage:'grade9',weapons:[null,null],body:{}},nextItemId:0,
   ahn:10000,level:1,exp:0,vitals:null,pendingMission:null,flags:{nestPermit:false,completedMissions:[],ratsCleared:false,starterPagesGranted:false,starterConsumablesGranted:false}};
  script=[...window.P];i=-1;ready=false;typing=null;currentBg='back';
  setBg('back',true);$('#dlg').style.display='';$('#pick').style.display='none';
  show('story');next();
 });
}

/* ---------- save files / autosave ---------- */
const SAVE_KEY='the-city-rpg-save-v1';
function saveSnapshot(){
 try{
  if(!S||!S.name)return null;
  const active=document.querySelector('.screen.on');
  if(active?.id==='menu'){try{return JSON.parse(localStorage.getItem(SAVE_KEY)||'null')}catch(_){return null}}
  const snap={format:'the-city-save',version:4,savedAt:new Date().toISOString(),screen:active?active.id:'story',S,script,i,currentBg,
   story:{text:$('#txt')?.textContent||'',who:$('#who span')?.textContent||'',loc:$('#loc')?.textContent||'',ready:!!ready},
   battle:B?JSON.parse(JSON.stringify(B)):null,
   hub:{key:($('#hubBg')?.className||'hubBackground bg-apt').replace('hubBackground bg-',''),name:$('#hubLoc')?.textContent||'',text:$('#hubText')?.textContent||''},
   summary:$('#summMeta')?.textContent||''};
  localStorage.setItem(SAVE_KEY,JSON.stringify(snap));return snap;
 }catch(e){console.warn('Autosave failed',e);return null}
}
function exportSave(){
 const snap=saveSnapshot()||(()=>{try{return JSON.parse(localStorage.getItem(SAVE_KEY)||'null')}catch(_){return null}})();
 if(!snap){alert('There is no progress to export yet. Start the story first.');return}
 const blob=new Blob([JSON.stringify(snap,null,2)],{type:'application/json'});
 const url=URL.createObjectURL(blob),a=document.createElement('a');
 a.href=url;a.download=`the-city-save-${(snap.S?.name||'player').replace(/[^a-z0-9_-]/gi,'_')}.json`;
 document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),1000);
}
function restoreSave(snap){
 if(!snap||snap.format!=='the-city-save'||![1,2,3,4].includes(snap.version)||!snap.S||!Array.isArray(snap.script))throw new Error('This is not a supported The City save file.');
 if(typing?.t)clearTimeout(typing.t);typing=null;if(rollTimer)clearInterval(rollTimer);rollTimer=null;
 S=snap.S;{const cap=S?.flags?.gradePromoted8?PLAYER_LEVEL_CAP_PROMOTED:PLAYER_LEVEL_CAP_BASE;S.level=Math.max(1,Math.min(cap,Math.floor(Number(S.level)||1)));S.exp=Math.max(0,Math.floor(Number(S.exp)||0));if(S.level>=cap)S.exp=0;}script=snap.script;i=Number.isInteger(snap.i)?snap.i:-1;currentBg=snap.currentBg||'back';ready=true;drag=null;
 $('#story').classList.remove('urban-myth-prologue','urban-myth-test');$('#battle').classList.toggle('urban-myth-exam',!!snap.battle&&snap.battle.encounterId==='fairyFestival');
 if(!S.pronouns){const old=String(S.gender||'').toLowerCase();S.pronouns=old==='boy'||old==='he/him'?'he/him':old==='girl'||old==='she/her'?'she/her':'they/them';}
 S.gender=S.pronouns;S.pendingMission=S.pendingMission||null;
 ensureInventory();
 const interruptedBattle=(snap.screen==='battle'||!!snap.battle||!!S.pendingMission);
 if(interruptedBattle){
  // Treat every battle save as an unfinished contract when loading after a restart.
  // Older builds paid at battle victory; roll back a provisional legacy payout where possible.
  const oldBattle=snap.battle||null;
  if(Number(snap.version)<3&&oldBattle?.won){
   const id=oldBattle.missionId||S.flags?.activeMission||'rats';
   const amount=MISSION_PAY[id]||1000;S.ahn=Math.max(0,(Number(S.ahn)||0)-amount);
   const drops=(oldBattle.bookDrops||[]).slice().reverse();
   for(const d of drops){const idx=S.inventory.books.map(b=>b?.id).lastIndexOf(d.id);if(idx>=0)S.inventory.books.splice(idx,1)}
  }
  B=null;S.pendingMission=null;S.flags=S.flags||{};S.flags.activeMission=null;
  closeHubPanels();$('#bEnd').classList.remove('on');$('#dlg').style.display='';$('#pick').style.display='none';
  currentBg=homeBackgroundKey();setBg(currentBg,true);clearVN();
  const note=oldBattle?.missionId==='urbanMythExam'?'The Fairy Festival examination was interrupted and has not been marked as cleared. You are back home; open Urban Myth again from the apartment when you are ready to retry.':'Your last encounter was interrupted before the contract was officially completed. It has been abandoned: no victory, payment, Books, or unlocks were kept. Return to the Backstreets for a first-time story encounter, or use the Fixer Office board to replay a completed reception.';
  showHub({key:homeBackgroundKey(),name:homeLocationName(),text:note});saveSnapshot();updateContinueButton();return;
 }
 B=snap.battle||null;
 if(B){
  if(!B.assignments)B.assignments={};
  if(!Array.isArray(B.hand))B.hand=[];if(!Array.isArray(B.discard))B.discard=[];
  if(!Array.isArray(B.bookDrops))B.bookDrops=[];
  B.encounterId=B.encounterId||'rats';B.missionId=B.missionId||S.flags?.activeMission||'rats';
  B.waves=B.waves||getEncounterWaves(B.encounterId);B.waveIndex=Number.isInteger(B.waveIndex)?B.waveIndex:0;
  B.totalEnemies=B.totalEnemies||B.waves.reduce((n,w)=>n+w.length,0);B.kills=B.kills||0;B.won=!!B.won;
  normalizeUnitStatuses(B.player);
  (B.enemies||[]).forEach(e=>{normalizeUnitStatuses(e);if(!Array.isArray(e.intents)||!e.intents.length)queueEnemyIntents(e);else{if(!Array.isArray(e.diceSpeeds))e.diceSpeeds=rollSpeeds(e);e.intent=e.intents[0]||e.intent}});
 }
 $('#dlg').style.display='';$('#pick').style.display='none';$('#txt').textContent=snap.story?.text||'';$('#who span').textContent=snap.story?.who||'';$('#loc').textContent=snap.story?.loc||'Location: Unknown';
 setBg(currentBg,true);clearVN();
 const target=snap.screen||'story';
 if(target==='hub'){showHub({key:snap.hub?.key||homeBackgroundKey(),name:snap.hub?.name||homeLocationName(),text:snap.hub?.text||'You are back home.'})}
 else if(target==='summ'){toSoon()}
 else if(target==='story'){show('story');$('#next').style.visibility='visible';if(snap.story?.who)setSpeaker(snap.story.who)}
 else {showHub({key:homeBackgroundKey(),name:homeLocationName(),text:'Your progress has been restored.'})}
 saveSnapshot();updateContinueButton();
}
function importSaveFile(file){
 if(!file)return;const reader=new FileReader();reader.onload=()=>{try{const snap=JSON.parse(String(reader.result));restoreSave(snap);alert('Save imported.');}catch(e){alert('Could not import save: '+e.message)}};reader.onerror=()=>alert('Could not read that file.');reader.readAsText(file);
}
$('#bExport').onclick=exportSave;$('#hubExport').onclick=exportSave;
$('#bImport').onclick=()=>$('#saveFileInput').click();
$('#saveFileInput').onchange=e=>{importSaveFile(e.target.files?.[0]);e.target.value=''};
function readValidAutosave(){
 try{const raw=localStorage.getItem(SAVE_KEY);if(!raw)return null;const snap=JSON.parse(raw);
  if(!snap||snap.format!=='the-city-save'||![1,2,3,4].includes(snap.version)||!snap.S||!snap.S.name||!Array.isArray(snap.script))return null;
  return snap;
 }catch(_){return null}
}
function updateContinueButton(){
 const b=$('#bContinue');if(!b)return;const snap=readValidAutosave();b.disabled=!snap;
 b.textContent=snap?`Continue · ${snap.S.name}`:'Continue';
 b.title=snap?'Continue from this browser’s autosave':'No valid save file found on this device';
}
$('#bContinue').onclick=()=>{const snap=readValidAutosave();if(!snap){updateContinueButton();alert('No valid save file found on this browser. Start a new game or import a save file.');return}
 try{restoreSave(snap)}catch(e){localStorage.removeItem(SAVE_KEY);updateContinueButton();alert('The local save is invalid. Import a valid save file to continue.')}};
window.addEventListener('beforeunload',saveSnapshot);window.addEventListener('pagehide',saveSnapshot);document.addEventListener('visibilitychange',()=>{if(document.visibilityState==='hidden')saveSnapshot()});

/* ---------- wiring ---------- */
{const st=$('#shelfToggle');if(st)st.onclick=()=>{const p=$('#sumPages');const open=p.hidden;p.hidden=!open;st.setAttribute('aria-expanded',String(open));st.textContent=open?'Combat Bookshelf ▾':'Combat Bookshelf ▸ (tap to view)'}}
document.addEventListener('keydown',e=>{if(e.key==='Escape'){closeHubPanels();$('#optm').classList.remove('on')}});
document.addEventListener('pointerdown',e=>{const open=document.querySelector('.hubSide.on');if(open&&!open.contains(e.target)&&!e.target.closest('#hubDockInv'))closeHubPanels()});
$('#bStart').onclick=start;$('#bStartClash').onclick=startPlannedClashes;updateContinueButton();window.addEventListener('storage',e=>{if(e.key===SAVE_KEY)updateContinueButton()});
 const hi=$('#hubDockInv');if(hi)hi.onclick=()=>{if(!$('#hub').classList.contains('on'))showHub();toggleHubPanel('#hubInv')};
 const hs=$('#hubDockSet');if(hs)hs.onclick=()=>$('#optm').classList.add('on');
 const hx=$('#hubDockSave');if(hx)hx.onclick=()=>{saveSnapshot();const t=$('#hubText');if(t)t.textContent='Progress saved on this device.';};
 const hc=$('#hubDockClose');if(hc)hc.onclick=closeHubPanels;
$('#bBack').onclick=()=>fadeTo(()=>{clearVN();show('menu')});
$('#hubReturnTitle').onclick=()=>fadeTo(()=>{clearVN();show('menu')});
$('#bGoJob').onclick=startJob;
$('#bEndOk').onclick=afterBattle;
$('#bOpt').onclick=()=>$('#optm').classList.add('on');
// Mobile uses tap-card then tap-target; native drag/drop remains for desktop.
$('#bClose').onclick=()=>$('#optm').classList.remove('on');
const toggleFullscreen=()=>{document.fullscreenElement?document.exitFullscreen():document.documentElement.requestFullscreen?.().catch(()=>{})};
$('#bFs').onclick=toggleFullscreen;
const fsBtn=$('#fsToggle');if(fsBtn)fsBtn.onclick=e=>{e.stopPropagation();toggleFullscreen()};
$('#spd').oninput=e=>speed=[60,40,28,16,8][e.target.value-1];
$('#story').onclick=advance;
$('#skip').onclick=e=>{e.stopPropagation();skip()};
$('#pick').onclick=e=>e.stopPropagation();
document.addEventListener('keydown',e=>{if($('#story').classList.contains('on')&&(e.key===' '||e.key==='Enter')){e.preventDefault();advance()}});


/* Mandatory preloader. It completes only after all tracked attempts finish; it never hides itself. */
(function boot(){
 const fill=$('#loadFill'),hint=$('#loadHint'),pct=$('#loadPercent'),missing=$('#loadMissing'),enter=$('#loadEnter'),skipButton=$('#loadSkip');
 const paths=[...new Set([
  'assets/bg/menu.webp','assets/bg/city.webp','assets/bg/apt.webp',
  'assets/bg/nest.webp','assets/bg/out.webp','assets/bg/outplace.webp',
  'assets/bg/office.webp','assets/bg/workshop.webp','assets/bg/hook-office.webp',
  'assets/bg/market.webp','assets/bg/nest-checkpoint.webp','assets/bg/junction.webp','assets/bg/hana-association.webp',
  ...Object.values(window.__spr||{}),
  'assets/icon/start-clash.webp','assets/icon/stagger.webp'
 ])];
 let done=0;const failed=[];let canEnter=false;
 const finish=()=>{
  canEnter=true;
  if(hint)hint.textContent=failed.length?'Assets checked · fallback art will be used where possible':'Visual assets ready';
  if(pct)pct.textContent='100%';
  if(fill)fill.style.width='100%';
  if(missing){missing.textContent='';missing.style.display='none';}
  if(enter){enter.disabled=false;enter.classList.add('ready');enter.textContent='ENTER THE CITY';enter.focus({preventScroll:true})}
  if(skipButton)skipButton.style.display='none';
 };
 const enterCity=(skipped=false)=>{
  if(!skipped&&!canEnter)return;
  if(enter)enter.disabled=true;
  if(skipButton)skipButton.disabled=true;
  const ld=$('#loading');if(!ld)return;
  if(skipped&&hint)hint.textContent='Loading skipped · some images may appear as they finish loading';
  ld.style.opacity='0';ld.style.pointerEvents='none';
  setTimeout(()=>{ld.style.display='none';ld.setAttribute('aria-hidden','true');updateContinueButton()},420);
 };
 const tick=(src,ok)=>{
  done++;if(!ok)failed.push(src);
  const progress=Math.round(done/paths.length*100);
  if(fill)fill.style.width=progress+'%';
  if(pct)pct.textContent=progress+'%';
  if(hint)hint.textContent=`Checking art assets · ${done}/${paths.length}`;
  if(done>=paths.length)finish();
 };
 if(enter)enter.onclick=()=>enterCity(false);
 if(skipButton)skipButton.onclick=()=>enterCity(true);
 paths.forEach(src=>{const im=new Image();im.onload=()=>tick(src,true);im.onerror=()=>tick(src,false);im.src=src});
})();
