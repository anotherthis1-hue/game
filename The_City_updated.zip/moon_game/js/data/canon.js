/*
 * The City — canonical story outcomes.
 * These flags describe the main story timeline, not replay availability.
 * Replaying a cleared reception never changes a character's canonical fate.
 */
(function (global) {
  'use strict';

  const OUTCOMES = Object.freeze({
    rats: Object.freeze({ pete: 'dead', lenny: 'dead', mangchi: 'dead' }),
    yunOffice: Object.freeze({ yun: 'dead', eri: 'dead', finn: 'alive' }),
    brotherhood: Object.freeze({ mo: 'dead', consta: 'dead', arnold: 'alive' }),
    hookOffice: Object.freeze({ taein: 'dead', mccullin: 'dead', naoki: 'dead' })
  });

  const ALIASES = Object.freeze({
    rata: 'lenny', rat_a: 'lenny',
    ratb: 'mangchi', rat_b: 'mangchi',
    'mang chi': 'mangchi'
  });
  const normalizeId = value => {
    const raw = String(value ?? '').trim().toLowerCase();
    const compact = raw.replace(/[^a-z0-9]/g, '');
    return ALIASES[raw] || ALIASES[compact] || compact;
  };

  function ensureFlags(flags) {
    flags = flags || {};
    if (!Array.isArray(flags.completedMissions)) flags.completedMissions = [];
    if (!flags.canonicalFates || typeof flags.canonicalFates !== 'object' || Array.isArray(flags.canonicalFates)) {
      flags.canonicalFates = {};
    }
    if (!flags.canonicalOutcomeApplied || typeof flags.canonicalOutcomeApplied !== 'object' || Array.isArray(flags.canonicalOutcomeApplied)) {
      flags.canonicalOutcomeApplied = {};
    }
    return flags;
  }

  function isMissionCompleted(flags, missionId) {
    flags = ensureFlags(flags);
    // Saves from before the reworked branching stories must replay each already-cleared
    // office once so the new outcome/reputation data can be registered.
    if (flags.canonicalRefreshPending && flags.canonicalRefreshPending[missionId]) return false;
    return missionId === 'rats'
      ? flags.ratsCleared === true
      : flags.completedMissions.includes(missionId);
  }

  function commitMission(flags, missionId, selectedOutcome) {
    flags = ensureFlags(flags);
    const defaultOutcome = OUTCOMES[missionId];
    const refreshPending = !!flags.canonicalRefreshPending?.[missionId];
    if (!defaultOutcome || (flags.canonicalOutcomeApplied[missionId] && !refreshPending)) return false;
    // A peaceful/helping route keeps that Office's members alive. This is committed
    // only on its first completed reception; replay outcomes are never canonical.
    const outcome = selectedOutcome === 'helped'
      ? Object.fromEntries(Object.keys(defaultOutcome).map(character => [character, 'alive']))
      : defaultOutcome;
    for (const [character, fate] of Object.entries(outcome)) {
      flags.canonicalFates[normalizeId(character)] = fate;
    }
    flags.canonicalReceptionOutcomes = flags.canonicalReceptionOutcomes || {};
    flags.canonicalReceptionOutcomes[missionId] = selectedOutcome === 'helped' ? 'helped' : 'fight';
    flags.canonicalOutcomeApplied[missionId] = true;
    if (flags.canonicalRefreshPending) delete flags.canonicalRefreshPending[missionId];
    return true;
  }

  // Backfill saves created before canonical outcomes existed. This runs on load
  // and does not change the ability to replay a completed mission.
  function migrate(flags) {
    flags = ensureFlags(flags);
    flags.canonicalRefreshPending = flags.canonicalRefreshPending || {};
    // One-time save migration: previously completed office receptions are replayed once
    // under the new branching story so the player's actual chosen outcome is registered.
    // Do not clear completion history or award reputation twice; only the story outcome
    // registration is refreshed when the player finishes that reception again.
    if (Number(flags.storyReworkVersion || 0) < 2) {
      for (const missionId of ['yunOffice', 'brotherhood', 'hookOffice']) {
        const wasCompleted = missionId === 'rats'
          ? flags.ratsCleared === true
          : (Array.isArray(flags.completedMissions) && flags.completedMissions.includes(missionId));
        if (wasCompleted) flags.canonicalRefreshPending[missionId] = true;
      }
      flags.storyReworkVersion = 2;
    }
    for (const missionId of Object.keys(OUTCOMES)) {
      if (!flags.canonicalRefreshPending[missionId] && isMissionCompleted(flags, missionId) && !flags.canonicalOutcomeApplied[missionId]) {
        commitMission(flags, missionId);
      }
    }
    // Existing saves that already finished the three office receptions receive Grade 8
    // without forcing them to re-clear the contracts.
    const officesDone = ['yunOffice', 'brotherhood', 'hookOffice'].every(id =>
      Array.isArray(flags.completedMissions) && flags.completedMissions.includes(id)
    );
    if (officesDone && !flags.gradePromoted8) flags.gradePromoted8 = true;
    return flags;
  }

  function fateFor(flags, characterId) {
    flags = ensureFlags(flags);
    return flags.canonicalFates[normalizeId(characterId)] || 'unknown';
  }

  function outcomeFor(missionId) {
    const outcome = OUTCOMES[missionId];
    return outcome ? { ...outcome } : {};
  }

  global.CityCanon = Object.freeze({
    outcomes: OUTCOMES,
    migrate,
    commitMission,
    isMissionCompleted,
    fateFor,
    outcomeFor
  });
})(window);
