// Story data: prologue branches + Grade 9 job
window.BR={
back:[
 {k:'roll'},
 C(`How did you get by in the Backstreets?`,[
  O('Dug through trash','Anything that could be eaten.','Agility','Scavenger',`You ate whatever you could find, and a lot of the time that meant digging through trash. You learned which places were safe and which ones weren’t.`),
  O('Syndicate errands','Small jobs, small pay.','Nerve','Runner',`A Syndicate paid you a few coins to run small errands. It was good money at first, but then the jobs got bigger and it became hard to say no.`),
  O('A neighbor helped','They fed you. You never asked why.','Wit','Sheltered',`An old neighbor started feeding you when you were small. They never said why, and you never asked. You just remember that it kept you alive.`)]),
 C(`One night you saw something you shouldn’t have.`,[
  O('A Fixer fight','Two Fixers, one doorway.','Agility','Fight-watcher',`Two Fixers fought in the middle of the street. You watched from a window and tried to remember every move they made.`),
  O('A Distortion','A person turned into a monster.','Nerve','Saw a Distortion',`A man standing near you suddenly turned into a Distortion. You ran, and you still hear the sound he made when you try to sleep.`),
  O('A Syndicate deal','Names, numbers, a handshake.','Wit','Eavesdropper',`You were close enough to hear a Syndicate making a deal. Names, numbers, and threats. You kept your mouth shut, because you knew what happens to people who talk.`)]),
 {loc:'Backstreets: School',bg:'school',t:`Each year, a school took in a few kids from the Backstreets. It wasn’t free, and everyone knew there was always a catch.`},
 C(`How did you get a seat?`,[
  O('A favor','Someone owed someone.','Wit','Sponsored',`Someone owed someone a favor, and you ended up as part of the deal. You never met the person who helped you, but you knew you owed them.`),
  O('A fight','The yard decided.','Might','Yard-fighter',`You beat three other kids in the school yard. After that, the teachers decided you were worth keeping around, and nobody asked more questions.`),
  O('You snuck in','No name on any list.','Agility','Snuck in',`You walked in and sat in the back of the class. Nobody checked, and nobody cared. It took them a full year to even notice.`)]),
 {loc:'Backstreets: Growing up',bg:'back',t:`School ended, but the Backstreets were still waiting for you outside.`},
 C(`What did you want back then?`,[
  O('To get out','Anywhere but here.','Agility','Wants out',`You wanted to leave the Backstreets and never come back. You didn’t care where you ended up, as long as it was somewhere else.`),
  O('To be feared','So nobody pushes you.','Might','Wants to be feared',`You wanted people to be afraid of you, so they would move out of your way instead of pushing you around.`),
  O('To be needed','Someone who would miss you.','Nerve','Wants to be needed',`You wanted just one person to notice if you were gone. Someone who would actually come looking for you.`)]),
 {loc:'Your apartment',bg:'apt',t:`Years passed, and now you are old enough to live on your own. The City doesn’t give anyone a home for free, so you had to find one yourself.`},
 C(`What kind of place did you take?`,[
  O('A cheap room','Thin walls, low rent.','Nerve','Cheap room',`The room was small and the walls were thin, but the rent was low enough that you could pay it. It was yours, and that was all that mattered.`),
  O('A shared apartment','Split the rent with others.','Wit','Shared place',`You split the rent with a few other people. It was crowded and noisy, but at least you weren’t alone.`),
  O('A quiet place, far from everyone','Hard to find, hard to reach.','Agility','Hideout',`You found a place at the end of a long hallway where nobody asked questions. If anyone came looking for you, you would hear them first.`)]),
 {loc:'Your apartment',bg:'apt',t:`That is how {name}’s story begins. A name nobody knows, in a City that doesn’t care.`},
 {t:`Now the City is going to show you what it is really like.`,bg:'apt'},

],
nest:[
 {k:'roll'},
 C(`How did your family stay in the Nest?`,[
  O('Worked for the Wing','Steady work, no questions.','Wit','Wing-worker’s child',`Your parents worked for the Wing and never complained. They knew that complaining was a good way to lose everything.`),
  O('Saved every coin','One missed rent and it’s over.','Nerve','Rent-scared',`Every coin your family earned went to rent. They knew that one missed month would be enough to throw them out into the Backstreets.`),
  O('Side jobs after dark','Jobs the Wing didn’t know about.','Agility','Side-job family',`Your parents took extra jobs from Syndicates at night. The Wing never found out, and they made sure you never told anyone either.`)]),
 C(`Something scared your family.`,[
  O('A neighbor disappeared','Sent to the Backstreets.','Nerve','Saw a neighbor fall',`One day, your neighbor was just gone. The Wing said they weren’t useful anymore, and nobody on the block said a word about it.`),
  O('A Fixer enforced a new rule','Everyone just smiled and obeyed.','Agility','Watched a Fixer',`A Fixer came to your block to enforce a new Wing rule. Everyone smiled and followed it, even though nobody understood why it existed.`),
  O('A Wing inspection','Every home was checked.','Wit','Inspected',`People from the Wing came to check every home. Everyone acted normal, but you could tell all the adults were scared.`)]),
 {loc:'Nest: School',bg:'school',t:`Kids in the Nest can go to school, but the Wing decides who gets a seat. For most families, it was the best chance their kids would ever get.`},
 C(`How did you get a seat?`,[
  O('You passed the Wing test','Top marks.','Wit','Test-passer',`You passed the Wing’s test. Your parents were proud, but they were also scared, because now you had to keep passing every test after it.`),
  O('Your parents’ job','The Wing owed them.','Nerve','Placed by parents',`Your parents’ work for the Wing got you in. You knew that if you wasted the chance, it would hurt them too.`),
  O('You won a fight','A teacher noticed.','Might','Yard champion',`You won a fight in front of a teacher. They seemed to like it, and that is how you got noticed. It probably wasn’t the right way to do it.`)]),
 {loc:'Nest: Growing up',bg:'nest',t:`School ended, but the Nest was still watching everything you did.`},
 C(`What did you want back then?`,[
  O('To join a Wing','Become a feather.','Wit','Wants to be a feather',`You wanted to join the Wing and become a feather, like everyone told you that you should. It sounded like the only way to be safe.`),
  O('To protect your family','So they never fall.','Might','Protector',`You wanted to make sure your family would never be sent to the Backstreets, no matter what it took.`),
  O('To see the City','Past your own Nest.','Agility','Wants to see the City',`You wanted to see other Districts. You were tired of seeing the same Nest and the same people every day.`)]),
 {loc:'Your apartment',bg:'apt',t:`Years passed, and now you are old enough to live on your own. The City doesn’t give anyone a home for free, so you had to find one yourself.`},
 C(`What kind of place did you take?`,[
  O('A cheap room','Thin walls, low rent.','Nerve','Cheap room',`The room was small and the walls were thin, but the rent was low enough that you could pay it. It was yours, and that was all that mattered.`),
  O('A shared apartment','Split the rent with others.','Wit','Shared place',`You split the rent with a few other people. It was crowded and noisy, but at least you weren’t alone.`),
  O('A quiet place, far from everyone','Hard to find, hard to reach.','Agility','Hideout',`You found a place at the end of a long hallway where nobody asked questions. If anyone came looking for you, you would hear them first.`)]),
 {loc:'Your apartment',bg:'apt',t:`That is how {name}’s story begins. A name nobody knows, in a City that doesn’t care.`},
 {t:`Now the City is going to show you what it is really like.`,bg:'apt'},

],
out:[
 C(`How did your family survive in the Outskirts?`,[
  O('Hunting','Long days, little food.','Might','Hunter',`Your family hunted whatever they could find. Some days there was plenty to eat, and a lot of days there wasn’t. You learned to track animals before you could even count.`),
  O('Trading scrap','With anyone passing by.','Wit','Scrap-trader',`Your family traded scrap with people passing through. You learned very quickly what things were worth and who was trying to cheat you.`),
  O('Moving camp','Never staying long.','Agility','Wanderer',`Your family never stayed in one place for long. You learned how to pack up and leave in minutes, and to never get too attached to any place.`)]),
 C(`One night you will never forget.`,[
  O('A storm','It destroyed the camp.','Nerve','Storm-survivor',`A huge storm wrecked your whole camp in one night. Everyone lived, but only barely, and you lost almost everything you owned.`),
  O('A stranger from the City','Hurt, and scared.','Wit','Met a City stranger',`A stranger from the City showed up hurt and scared. Before he left, he told you about the Wings and their tall towers, and you couldn’t stop thinking about them.`),
  O('Something in the dark','Not an animal.','Nerve','Saw something',`Something walked through the camp in the dark, and it wasn’t an animal. You never found out what it was, and nobody wanted to talk about it afterward.`)]),
 {loc:'Outskirts: Growing up',bg:'out',t:`There were no schools in the Outskirts. Everything you knew, you learned by staying alive.`},
 C(`What did you want back then?`,[
  O('A real home','A place that doesn’t move.','Nerve','Wants a home',`You wanted a real home, one that doesn’t have to be packed up and moved. A place where you could finally stop running.`),
  O('To reach the City','Even if it’s dangerous.','Might','Wants the City',`You wanted to reach the City, even though everyone said it was dangerous. Anything seemed better than staying where you were.`),
  O('To be left alone','By everyone.','Agility','Wants peace',`You wanted everyone to just leave you alone. You were tired of people who only showed up when they needed something.`)]),
 {loc:'Outskirts: Your place',bg:'outplace',t:`Years passed. There are no apartments out here — just whatever shelter you can keep standing.`},
 C(`What kind of place did you claim?`,[
  O('An abandoned machine shed','Still half-working.','Nerve','Shed-dweller',`You took over a rusted machine shed. The lights still flicker on some nights, and the walls keep the wind out better than a tent ever could.`),
  O('A scrap lean-to','Built from what you found.','Wit','Scrap-home',`You built a lean-to from scrap metal and old tarps. It isn’t much, but it is yours, and you know every weak spot in the walls.`),
  O('A hidden ruin further out','Hard for anyone to find.','Agility','Ruin-hideout',`You found a half-collapsed ruin away from the usual paths. Few people come this far, and that is exactly why you chose it.`)]),
 {loc:'Outskirts: Your place',bg:'outplace',t:`That is how {name}’s story begins. A name nobody knows, far from the City that doesn’t care.`},
 {t:`Sooner or later, the City will reach even here.`,bg:'outplace'},
],
};
window.P=[
{loc:'Somewhere in the City',bg:'back',t:`This is the City. Most people here spend every day just trying to survive, and nobody really cares if they make it.`},
{t:`You are one of those people. Before your story starts, there are a few things we need to know about you.`},
{k:'in',p:`What is your name?`},
{t:`{name}. That name doesn’t mean anything to anyone in the City yet. That could change, or it could stay that way forever.`},
{k:'ch',key:'gender',p:`Which pronouns should people use for you?`,o:[
 {t:'He / him',pronouns:'he/him',say:[`Got it. People will use he/him for you.`]},
 {t:'She / her',pronouns:'she/her',say:[`Got it. People will use she/her for you.`]},
 {t:'They / them',pronouns:'they/them',say:[`Got it. People will use they/them for you.`]}]},
{loc:'Chapter 1: Birth',bg:'back',t:`Nobody gets to pick where they are born. Where you start in the City decides a lot about how your life will go.`},
{k:'ch',p:`Where were you born?`,o:[
 {t:'The Backstreets',d:'Dirty, loud, dangerous.',s:'Agility',g:'Backstreet-born',go:'back',bg:'back',say:[`You were born in the Backstreets. Syndicates and Fixers fight over every corner here, and the Wings don’t care what happens to the people living in it. You learned early to keep your head down.`]},
 {t:'The Nest',d:'Run by a Wing. Safe, if you earn it.',s:'Nerve',g:'Nest-born',go:'nest',bg:'nest',say:[`You were born in the Nest. A Wing runs everything here, so life is safe and comfortable. But the Wing can take it all away if you stop being useful, and then you would end up in the Backstreets.`]},
 {t:'The Outskirts',d:'Far from the City.',s:'Might',g:'Outskirts-born',go:'out',bg:'out',say:[`You were born in the Outskirts, far away from the City and far from any Wing’s protection. Hardly anyone comes here unless they have no other choice.`]}]},
{k:'end'}];
window.JOB=[
 {loc:'Your place',bg:'apt',t:`The Hana stamp on the slip is still wet. Grade 9. Low risk. Low pay. Exactly the kind of job that keeps a new Fixer from starving.`},
 {t:`A corner in the Backstreets. Rats have been taxing a noodle stall that already paid someone else. Your contract says to clear the corner, not to decide who deserves it.`},
 {t:`You pin the license to your coat, check the route once, and step out. The street keeps moving around you as if the job has already been forgotten.`,bg:'back'},
 {k:'fade',bg:'back',loc:'Backstreets — Patrol'},
 {loc:'Backstreets — Patrol',bg:'back',t:`The deeper streets do not change for a Grade 9. Wet iron smell. Eyes that look away when they see a pin. A closed Workshop shutter with fresh scrape marks at the lock.`},
 {t:`Voices carry from the last bend. Not loud — the kind of quiet that means someone is already claiming the space.`},
 {loc:'Backstreets — Side Alley',bg:'back',t:`Three figures have the stall corner blocked. Pete stands in front; Lenny watches the owner's hands; Mang Chi pretends not to notice you.`},
 {k:'ratsTalk'},
 {who:'Mang Chi',title:'Backstreets Rat',t:`…`},
 {who:'Lenny',title:'Backstreets Rat',t:`Boss. Pin.`},
 {who:'Pete',title:'Backstreets Rat — Leader',t:`I see it.`},
 {t:`Pete looks you over as if he were pricing a broken machine.`},
 {who:'Pete',title:'Backstreets Rat — Leader',t:`Grade 9. Fresh ink. Did the Association pay you to collect a story, or did somebody actually pay for this corner?`},
 {k:'ch',key:'approach',p:'How do you make your first move?',o:[
  {t:'State the contract and order them away',d:'Lead with your authority as a Fixer.',say:'I have a signed job. Leave the corner and let the stall reopen.',route:'rat_direct',tags:['direct','prepared']},
  {t:'Offer them a way to leave quietly',d:'Try to end the dispute without making it public.',say:'No one has to get hurt over a few metres of street. Walk away and I will keep the report simple.',route:'rat_calm',tags:['calm','merciful']},
  {t:'Say nothing; watch who gives the orders',d:'Read the group before you commit.',say:'You stay quiet and watch Pete’s hands, Lenny’s eyes, and the space Mang Chi leaves by the stall.',route:'rat_silent',tags:['silent','observant']}
 ]}
];



// Short continuation after the first Canard Rat encounter. Keep this in story data so future chapters can extend it cleanly.
window.POST_RATS=[
 {loc:'Backstreets — Side alley',bg:'back',t:`The last exchange leaves Pete, Lenny, and Mang Chi too badly injured to survive. None of the three makes it through the aftermath.`},
 {loc:'Backstreets — Side alley',bg:'back',t:`The Association's incident report records all three Rats as dead. No one remains to reclaim the corner, and the original contract is closed.`},
 {loc:'Heading home',bg:'back',t:`You check that your Fixer license is still pinned to your coat, then make your way back to your place. The report goes with you; the outcome will remain part of the City's record.`},
 {k:'missionEnd',id:'rats'}
];
// Retained as a compatibility alias for older saves; replay dialogue stays in-world.
window.POST_RATS_REPLAY=[
 {loc:'Backstreets — Side alley',bg:'back',t:`The Association's incident report is finalized. The three Rats do not return to reclaim the corner, and the contract is closed.`},
 {loc:'Heading home',bg:'back',t:`You check your Fixer license and make your way home after the report is filed.`},
 {k:'missionEnd',id:'rats'}
];
