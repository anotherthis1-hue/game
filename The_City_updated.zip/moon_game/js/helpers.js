window.O=function(t,d,s,g,say){return{t:t,d:d,s:s,g:g,say:Array.isArray(say)?say:[say]}};
window.C=function(p,o){return{k:'ch',p:p,o:o}};
// alias for story data files
var O=window.O, C=window.C;
