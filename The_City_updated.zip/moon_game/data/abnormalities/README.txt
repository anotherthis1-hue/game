ABNORMALITY DEFINITIONS

Store abnormality code, name, threat level, HP/Stagger, passives, combat page assignments, and encounter configuration here. Keep data definitions separate from image assets. Fairy Festival is defined in fairy-festival.js.
