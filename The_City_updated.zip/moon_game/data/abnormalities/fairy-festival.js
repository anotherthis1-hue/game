/*
 * Fairy Festival (F-04-83) — Urban Myth examination data.
 * Core identification and the Fairy Queen's 200 HP / 50 Stagger are based on
 * Library of Ruina community reference material. Combat has been tuned for this
 * fan RPG's shorter dice and status system; it is not a one-to-one game port.
 */
(function (global) {
  'use strict';
  global.ABNORMALITIES = global.ABNORMALITIES || {};
  global.ABNORMALITIES.fairyFestival = {
    id: 'fairyFestival',
    code: 'F-04-83',
    name: 'Fairy Festival',
    threatLevel: 'ZAYIN',
    classification: 'Abnormality',
    sourceNote: 'Fairy Festival / Fairy Queen adaptation',
    passives: [
      { id: 'momentarySatiation', name: 'Momentary Satiation', description: 'The Fairy Queen consumes prepared prey in its original encounter; this solo exam does not include Fairy Mass allies.' },
      { id: 'ravenousness', name: 'Ravenousness', description: 'At 25% HP or less, gains a tuned Strength boost for the rest of this exam.' }
    ],
    notes: 'Its attacks build Bleed and can recover HP. The solo exam uses neutral Slash, Pierce, and Blunt resistances to match the Fairy Queen reference.'
  };

  global.PAGES = global.PAGES || {};
  Object.assign(global.PAGES, {
    fairyBite: {
      id: 'fairyBite', n: 'Fairy Bite', tier: 2, c: 1,
      dice: [{t:'pierce',lo:3,hi:6},{t:'slash',lo:2,hi:4}],
      effects: [{trigger:'hit',status:'bleed',potency:1,count:2,chance:0.65},{trigger:'hit',type:'heal',amount:2,target:'self'}]
    },
    fairyFlutter: {
      id: 'fairyFlutter', n: 'Fluttering Lunge', tier: 2, c: 1,
      dice: [{t:'slash',lo:2,hi:5},{t:'pierce',lo:3,hi:5}],
      effects: [{trigger:'hit',status:'bleed',potency:2,count:2,chance:0.45}]
    },
    fairyFeast: {
      id: 'fairyFeast', n: 'Feast on the Wounded', tier: 2, c: 2,
      dice: [{t:'pierce',lo:4,hi:7},{t:'blunt',lo:2,hi:5}],
      effects: [{trigger:'hit',status:'bleed',potency:2,count:3,chance:0.7},{trigger:'hit',type:'heal',amount:4,target:'self'}]
    }
  });

  global.ENCOUNTERS = global.ENCOUNTERS || {};
  global.ENCOUNTERS.fairyFestival = {
    name: 'Hana Association Examination — Fairy Festival',
    threatLevel: 'ZAYIN',
    waves: [[{
      id: 'fairyFestival', name: 'Fairy Festival', title: 'F-04-83 · Threat Level: ZAYIN',
      code: 'F-04-83', threat: 'ZAYIN', level: 9, hp: 200, stagger: 50,
      pages: ['fairyBite','fairyFlutter','fairyFeast'], spr: 'fairyFestival',
      ability: 'Ravenousness', passiveType: 'fairyFestivalQueen',
      res: {
        hp: {slash: 1.0, pierce: 1.0, blunt: 1.0},
        st: {slash: 1.0, pierce: 1.0, blunt: 1.0}
      }
    }]]
  };
})(window);
