STORY ARC: URBAN MYTH
Current playable scope: Hana Association report, meeting Grade 8 Fixer Zevelyn, Han-ul's briefing, and the Fairy Festival examination. Later Urban Myth scenes and Grade 8 promotion are not implemented yet. The current dialogue source is data/dialogues/Urban-Myth/hana-examination.js.
