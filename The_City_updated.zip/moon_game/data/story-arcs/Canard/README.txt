STORY ARC: CANARD
The playable Canard stories currently live in data/dialogues/Canard/. This is a reserved organization folder only; do not duplicate story scripts here unless the runtime is deliberately migrated.
