// Additional Canard reception data. Named story sprites use the exact path keys below;
// If artwork is not in the ZIP, that character remains invisible until the correct sprite is supplied.
window.PAGES = window.PAGES || {};
Object.assign(window.PAGES, {
  bBlowItUp: {id:'bBlowItUp',n:'B-blow It Up!',tier:2,c:2,dice:[{t:'pierce',lo:2,hi:5}],effects:[{trigger:'hit',status:'tremor',potency:2,count:2,chance:.8}]} ,
  cChop:     {id:'cChop',n:'C-chop It Off!',tier:2,c:2,dice:[{t:'slash',lo:2,hi:5},{t:'slash',lo:1,hi:4}],effects:[{trigger:'hit',type:'tremorBurst'},{trigger:'hit',type:'chargeBurst'}]},
  eEndure:   {id:'eEndure',n:'E-endure',tier:1,c:1,dice:[{t:'block',lo:2,hi:5},{t:'block',lo:1,hi:4}]},
  cChargeUp: {id:'cChargeUp',n:'C-charge Up!',tier:2,c:2,dice:[{t:'blunt',lo:2,hi:5},{t:'block',lo:2,hi:4}],effects:[{trigger:'clashWin',status:'charge',potency:2,count:2,target:'self',chance:1}]},
  arnoldAssault:{id:'arnoldAssault',n:'Arnold’s Assault',tier:2,c:2,dice:[{t:'slash',lo:4,hi:7},{t:'blunt',lo:3,hi:6}],effects:[{trigger:'hit',status:'tremor',potency:2,count:2,chance:.7}]},
  arnoldResolve:{id:'arnoldResolve',n:'Unyielding Resolve',tier:2,c:2,dice:[{t:'block',lo:3,hi:6},{t:'pierce',lo:4,hi:7}],effects:[{trigger:'clashWin',status:'charge',potency:2,count:2,target:'self',chance:1}]},
  yYouOnlyLiveOnce:{id:'yYouOnlyLiveOnce',n:'Y-you Only Live Once!',tier:2,c:2,dice:[{t:'pierce',lo:2,hi:5},{t:'evade',lo:1,hi:5}],effects:[{trigger:'hit',status:'tremor',potency:1,count:2,chance:.5}]},
  track:     {id:'track',n:'Track',tier:1,c:1,dice:[{t:'evade',lo:1,hi:6},{t:'pierce',lo:2,hi:4}],effects:[{trigger:'hit',type:'heal',amount:1,target:'self'}]},
  rampage:   {id:'rampage',n:'Rampage',tier:2,c:2,dice:[{t:'blunt',lo:2,hi:4},{t:'pierce',lo:3,hi:5},{t:'slash',lo:2,hi:4}],effects:[{trigger:'hit',status:'bleed',potency:1,count:2,chance:.4},{trigger:'hit',type:'heal',amount:1,target:'self'}]},
  overpower: {id:'overpower',n:'Overpower',tier:2,c:2,dice:[{t:'pierce',lo:4,hi:6}],effects:[{trigger:'hit',status:'bleed',potency:2,count:2,chance:.6},{trigger:'hit',type:'heal',amount:1,target:'self'}]},
  fendThisOff:{id:'fendThisOff',n:'Fend This Off If You Can',tier:2,c:2,dice:[{t:'blunt',lo:3,hi:5},{t:'pierce',lo:2,hi:4}],effects:[{trigger:'hit',status:'bleed',potency:1,count:2,chance:.45},{trigger:'hit',type:'heal',amount:1,target:'self'}]}
});

window.ENCOUNTERS = {
  rats: {name:'Rats', enemies:[
    {id:'pete',name:'Pete',title:'Backstreets Rat — Leader',level:2,hp:18,stagger:10,pages:['shiv','dirty'],spr:'pete',res:{hp:{slash:1.25,pierce:1,blunt:1.5},st:{slash:1.25,pierce:1,blunt:1.5}},book:'book_pete'},
    {id:'rata',name:'Lenny',title:'Backstreets Rat',level:1,hp:12,stagger:7,pages:['shiv','carefulCut','ratsGuide'],spr:'rata',res:{hp:{slash:1,pierce:1.5,blunt:1.25},st:{slash:1,pierce:1.5,blunt:1.25}},book:'book_lenny'},
    {id:'ratb',name:'Mang Chi',title:'Backstreets Rat',level:2,hp:13,stagger:8,pages:['shiv','dirty'],spr:'ratb',res:{hp:{slash:1.5,pierce:1.25,blunt:1},st:{slash:1.5,pierce:1.25,blunt:1}},book:'book_mang'}
  ]},
  yunOffice: {name:"Yun's Office — Contract Dispute", enemies:[]},
  brotherhood: {name:'Brotherhood of Iron', enemies:[]},
  hookOffice: {name:'Hook Office', enemies:[]}
};

// Canard reception roster refinement: Yun's Office and Hook Office have distinct Acts/waves.
// The main story uses the canonical order: Rats → Yun's Office Fixers → Yun's Office Rookie →
// Yun's Office → Brotherhood of Iron → Hook Office. Combat values remain tuned for this fan RPG.
window.PAGES = window.PAGES || {};
Object.assign(window.PAGES, {
  biteOff:{id:'biteOff',n:'Bite Off',tier:1,c:1,dice:[{t:'slash',lo:2,hi:4},{t:'blunt',lo:1,hi:3}],effects:[{trigger:'hit',status:'bleed',potency:1,count:2,chance:.25}]},
  ratsGuide:{id:'ratsGuide',n:"Rats' Guide to Survival",tier:1,c:1,dice:[{t:'block',lo:2,hi:4},{t:'pierce',lo:2,hi:4}],effects:[{trigger:'hit',status:'bleed',potency:1,count:2,chance:.35}]},
  pileOn:{id:'pileOn',n:'Pile On',tier:1,c:1,dice:[{t:'blunt',lo:2,hi:4},{t:'slash',lo:2,hi:3}],effects:[{trigger:'hit',status:'bleed',potency:1,count:1,chance:.25}]},
  gutHarvesting:{id:'gutHarvesting',n:'Gut Harvesting',tier:1,c:1,dice:[{t:'slash',lo:2,hi:5}],effects:[{trigger:'hit',status:'bleed',potency:1,count:2,chance:.35}]},
  finnResolve:{id:'finnResolve',n:'Rookie Resolve',tier:1,c:1,dice:[{t:'block',lo:2,hi:5},{t:'pierce',lo:2,hi:4}],effects:[{trigger:'clashWin',status:'haste',potency:1,count:2,target:'self',chance:1},{trigger:'hit',status:'rupture',potency:1,count:2,chance:.45}]},
  hookCut:{id:'hookCut',n:'Hook Cut',tier:1,c:1,dice:[{t:'slash',lo:2,hi:5},{t:'pierce',lo:2,hi:4}],effects:[{trigger:'hit',status:'bleed',potency:1,count:2,chance:.45},{trigger:'hit',type:'heal',amount:1,target:'self'}]},
  ledgerRead:{id:'ledgerRead',n:'Ledger Read',tier:2,c:2,dice:[{t:'pierce',lo:3,hi:5},{t:'block',lo:2,hi:5}],effects:[{trigger:'clashWin',status:'haste',potency:1,count:2,target:'self',chance:1},{trigger:'hit',status:'rupture',potency:1,count:2,chance:.55}]},
  feeCollection:{id:'feeCollection',n:'Fee Collection',tier:2,c:2,dice:[{t:'blunt',lo:3,hi:5},{t:'pierce',lo:2,hi:4}],effects:[{trigger:'hit',status:'rupture',potency:1,count:3,chance:.65}]}
});
const __canardYun={id:'yun',name:'Yun',title:'Office Operator',level:12,hp:22,stagger:12,pages:['ledgerRead','feeCollection','focused'],spr:'yun',res:{hp:{slash:1,pierce:1.25,blunt:1.25},st:{slash:1,pierce:1.25,blunt:1.25}},book:'book_yun'};
const __canardEri={id:'eri',name:'Eri',title:'Grade 8 Fixer',level:10,hp:20,stagger:11,pages:['wallop','quickStep','preemptive'],spr:'eri',res:{hp:{slash:1.25,pierce:1,blunt:1},st:{slash:1.25,pierce:1,blunt:1}},book:'book_eri'};
const __canardFinn={id:'finn',name:'Finn',title:"Yun's Office — Grade 9 Fixer",level:8,hp:18,stagger:9,pages:['finnResolve','quickStep'],spr:'finn',res:{hp:{slash:1.25,pierce:1,blunt:1},st:{slash:1.25,pierce:1,blunt:1}},book:'book_finn'};
const __canardMo={id:'mo',name:'Mo',title:'Brotherhood of Iron',level:15,hp:18,stagger:10,pages:['cChargeUp','bBlowItUp','cChop'],spr:'mo',res:{hp:{slash:1,pierce:1.5,blunt:1},st:{slash:1,pierce:1.5,blunt:1}},book:'book_mo'};
const __canardConsta={id:'consta',name:'Consta',title:'Brotherhood of Iron',level:14,hp:17,stagger:9,pages:['bBlowItUp','cChargeUp','cChop'],spr:'consta',res:{hp:{slash:1.25,pierce:1.25,blunt:1},st:{slash:1.25,pierce:1.25,blunt:1}},book:'book_consta'};
const __canardArnold={id:'arnold',name:'Arnold',title:'Brotherhood of Iron — Leader',level:16,hp:100,stagger:45,pages:['arnoldAssault','arnoldResolve','cChop'],spr:'arnold',res:{hp:{slash:0.8,pierce:1,blunt:0.7},st:{slash:0.9,pierce:1,blunt:0.8}}};
const __taein={id:'taein',name:'Taein',title:'Hook Office',level:22,hp:18,stagger:9,pages:['hookCut','rampage'],spr:'taein',res:{hp:{slash:1,pierce:1.25,blunt:1.5},st:{slash:1,pierce:1.25,blunt:1.5}},book:'book_taein'};
const __mccullin={id:'mccullin',name:'McCullin',title:'Hook Office',level:21,hp:17,stagger:9,pages:['overpower','track'],spr:'mccullin',res:{hp:{slash:1,pierce:1.5,blunt:1.25},st:{slash:1,pierce:1.5,blunt:1.25}},book:'book_mccullin'};
const __naoki={id:'naoki',name:'Naoki',title:'Hook Office',level:20,hp:17,stagger:9,pages:['fendThisOff','hookCut'],spr:'naoki',res:{hp:{slash:1.25,pierce:1,blunt:1.25},st:{slash:1.25,pierce:1,blunt:1.25}},book:'book_naoki'};
window.ENCOUNTERS.yunOffice.enemies=[__canardYun,__canardEri,__canardFinn];
// Brotherhood: Wave 1 = Mo AND Consta together. Wave 2 = Arnold alone (after stage-clear → chase dialogue).
window.ENCOUNTERS.brotherhood.enemies=[__canardMo,__canardConsta];
window.ENCOUNTERS.brotherhood.waves=[
  [__canardMo,__canardConsta], // wave 1 — both on the street at once
  [__canardArnold]             // wave 2 — workshop, after Continue on victory panel
];
window.ENCOUNTERS.hookOffice.enemies=[__taein,__mccullin,__naoki];
