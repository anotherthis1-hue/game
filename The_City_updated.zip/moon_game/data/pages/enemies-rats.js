// Canard: Rats. Enemy pages may enter the player's inventory only through book extraction.
window.PAGES = window.PAGES || {};
Object.assign(window.PAGES, {
  shiv:      {id:'shiv', n:'Shiv', tier:1, c:1, dice:[{t:'slash',lo:1,hi:3},{t:'slash',lo:1,hi:3}], effects:[{trigger:'hit',status:'bleed',potency:1,count:2,chance:.35}]},
  dirty:     {id:'dirty', n:'Dirty Blow', tier:1, c:1, dice:[{t:'blunt',lo:2,hi:4}], effects:[{trigger:'hit',status:'bleed',potency:1,count:2,chance:.25}]},
  ratsGuide: {id:'ratsGuide', n:"Rats' Guide", tier:2, c:2, dice:[{t:'block',lo:1,hi:5},{t:'slash',lo:2,hi:4}], effects:[{trigger:'hit',status:'bleed',potency:1,count:2,chance:.35}]},
  pileOn:    {id:'pileOn', n:'Pile On', tier:2, c:2, dice:[{t:'slash',lo:1,hi:4},{t:'slash',lo:1,hi:4},{t:'blunt',lo:1,hi:4}], effects:[{trigger:'hit',status:'bleed',potency:1,count:1,chance:.25}]},
  gutHarvesting:{id:'gutHarvesting', n:'Gut Harvesting', tier:2, c:2, dice:[{t:'pierce',lo:2,hi:5},{t:'slash',lo:2,hi:4}], effects:[{trigger:'hit',status:'bleed',potency:1,count:2,chance:.4}]}
});
