// Lightweight equipment items for the game's two weapon slots. Effects are in-game values only.
window.WEAPON_DATA = {
  association_baton:{id:'association_baton',n:'Association Standard Baton',desc:'Issued with the Grade 9 contract. +1 to Block dice.',blockBonus:1},
  workshop_blade:{id:'workshop_blade',n:'Workshop Practice Blade',desc:'A well-balanced Workshop training piece. +1 to Slash and Pierce dice.',attackBonus:1,types:['slash','pierce']},
  hook_tool:{id:'hook_tool',n:'Hook Office Tool',desc:'A specialised field tool recovered from an Office book. +1 to Pierce dice.',attackBonus:1,types:['pierce']},
  nest_issue_blade:{id:'nest_issue_blade',n:'Nest-Issue Composite Blade',desc:'An officially supplied composite weapon. +2 to Slash dice.',attackBonus:2,types:['slash'],nestOnly:true,price:24000},
  nest_precision_spear:{id:'nest_precision_spear',n:'Wing-Authorized Precision Spear',desc:'A costly precision-built weapon for authorized Fixers. +2 to Pierce dice.',attackBonus:2,types:['pierce'],nestOnly:true,price:28000},
  nest_guard_baton:{id:'nest_guard_baton',n:'Nest Security Baton',desc:'A reinforced official baton. +2 to Block dice and +1 to Blunt dice.',blockBonus:2,attackBonus:1,types:['blunt'],nestOnly:true,price:21000}
};
