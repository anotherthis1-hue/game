/* Body equipment for the RPG inventory. Item values are entirely in-game bonuses. */
window.BODY_SLOTS = [
  {id:'head',label:'Head'}, {id:'eyes',label:'Eyes / Optics'}, {id:'face',label:'Face'},
  {id:'torso',label:'Torso / Armor'}, {id:'leftArm',label:'Left Arm'}, {id:'rightArm',label:'Right Arm'},
  {id:'leftHand',label:'Left Hand'}, {id:'rightHand',label:'Right Hand'},
  {id:'leftLeg',label:'Left Leg'}, {id:'rightLeg',label:'Right Leg'}, {id:'feet',label:'Feet'}, {id:'neural',label:'Neural Augmentation'}
];
window.GEAR_DATA = {
  field_cap: {id:'field_cap',name:'Field Cap',slot:'head',price:700,desc:'A basic protective cap. +3 max HP.',hpBonus:3},
  clear_lens: {id:'clear_lens',name:'Clear Lens',slot:'eyes',price:1000,desc:'Basic replaceable optics. +1 Offense Level.',offLevel:1},
  reinforced_coat: {id:'reinforced_coat',name:'Reinforced Coat',slot:'torso',price:1900,desc:'Layered protection for a new Fixer. +8 max HP, +1 Defense Level.',hpBonus:8,defLevel:1},
  left_prosthetic_arm: {id:'left_prosthetic_arm',name:'Standard Left Prosthetic',slot:'leftArm',price:2400,desc:'A sturdy mechanical replacement. +1 Offense Level.',offLevel:1},
  right_prosthetic_arm: {id:'right_prosthetic_arm',name:'Standard Right Prosthetic',slot:'rightArm',price:2400,desc:'A sturdy mechanical replacement. +1 Offense Level.',offLevel:1},
  left_prosthetic_hand: {id:'left_prosthetic_hand',name:'Precision Left Hand',slot:'leftHand',price:1600,desc:'A fine-motor replacement hand. +1 Offense Level.',offLevel:1},
  right_prosthetic_hand: {id:'right_prosthetic_hand',name:'Precision Right Hand',slot:'rightHand',price:1600,desc:'A fine-motor replacement hand. +1 Offense Level.',offLevel:1},
  left_reinforced_leg: {id:'left_reinforced_leg',name:'Reinforced Left Leg',slot:'leftLeg',price:2100,desc:'A mechanical leg with a reinforced frame. +4 max Stagger.',staggerBonus:4},
  right_reinforced_leg: {id:'right_reinforced_leg',name:'Reinforced Right Leg',slot:'rightLeg',price:2100,desc:'A mechanical leg with a reinforced frame. +4 max Stagger.',staggerBonus:4},
  padded_faceguard: {id:'padded_faceguard',name:'Padded Face Guard',slot:'face',price:850,desc:'Protective padding and a clear comms channel. +2 max HP.',hpBonus:2},
  reinforced_boots: {id:'reinforced_boots',name:'Reinforced Boots',slot:'feet',price:950,desc:'Stability-focused footwear. +3 max Stagger.',staggerBonus:3},
  reflex_augment: {id:'reflex_augment',name:'Reflex Augmentation',slot:'neural',price:3200,desc:'A basic neural-response implant. +1 Offense Level, +1 Defense Level.',offLevel:1,defLevel:1},

  nest_optics: {id:'nest_optics',name:'Nest-Grade Optics',slot:'eyes',price:18000,nestOnly:true,desc:'Official high-grade optical augmentation. +2 Offense Level.',offLevel:2},
  nest_armor: {id:'nest_armor',name:'Nest Composite Armor',slot:'torso',price:30000,nestOnly:true,desc:'A costly official protective shell. +24 max HP, +2 Defense Level.',hpBonus:24,defLevel:2},
  nest_neural_link: {id:'nest_neural_link',name:'Wing Neural Link',slot:'neural',price:26000,nestOnly:true,desc:'Regulated neural augmentation. +2 Offense Level, +2 Defense Level.',offLevel:2,defLevel:2},
  nest_left_arm: {id:'nest_left_arm',name:'Official Left-Arm Prosthesis',slot:'leftArm',price:22000,nestOnly:true,desc:'An expensive, precision-fitted prosthetic. +2 Offense Level, +6 max HP.',offLevel:2,hpBonus:6},
  nest_right_arm: {id:'nest_right_arm',name:'Official Right-Arm Prosthesis',slot:'rightArm',price:22000,nestOnly:true,desc:'An expensive, precision-fitted prosthetic. +2 Offense Level, +6 max HP.',offLevel:2,hpBonus:6},
  nest_leg_pair: {id:'nest_leg_pair',name:'Official Lower-Body Prosthesis',slot:'rightLeg',price:25000,nestOnly:true,desc:'A high-grade support prosthesis. +10 max Stagger, +1 Defense Level.',staggerBonus:10,defLevel:1}
};
