// Skill 2 — early Grade 9 / Canard pages. Stronger options have meaningful Light costs.
window.PAGES = window.PAGES || {};
Object.assign(window.PAGES, {
  wallop:       {id:'wallop', n:'Wallop', tier:2, c:2, dice:[{t:'blunt',lo:2,hi:6},{t:'blunt',lo:2,hi:4}], effects:[{trigger:'hit',status:'fragile',potency:1,count:1,chance:.35}]},
  focused:      {id:'focused', n:'Focused Strikes', tier:2, c:2, dice:[{t:'slash',lo:3,hi:5},{t:'slash',lo:2,hi:5},{t:'pierce',lo:1,hi:3}], effects:[{trigger:'hit',status:'rupture',potency:1,count:2,chance:.45}]},
  charge:       {id:'charge', n:'Charge and Cover', tier:2, c:2, dice:[{t:'pierce',lo:3,hi:5},{t:'block',lo:2,hi:5}], effects:[{trigger:'clashWin',status:'charge',potency:1,count:2,target:'self',chance:1}]},
  preemptive:   {id:'preemptive', n:'Preemptive Strike', tier:2, c:2, dice:[{t:'slash',lo:3,hi:5},{t:'evade',lo:1,hi:7}], effects:[{trigger:'clashWin',status:'haste',potency:1,count:2,target:'self',chance:1}]},
  backstreetDash:{id:'backstreetDash', n:'Backstreets Dash', tier:2, c:1, dice:[{t:'evade',lo:2,hi:5},{t:'slash',lo:2,hi:4}]},
  skitterAway:  {id:'skitterAway', n:'Skitter Away', tier:2, c:1, dice:[{t:'evade',lo:2,hi:6},{t:'evade',lo:1,hi:4}]},
  carefulCut:  {id:'carefulCut', n:'Careful Cut', tier:2, c:1, dice:[{t:'pierce',lo:2,hi:4}], effects:[{trigger:'hit',status:'bleed',potency:1,count:2,chance:.5}]},
  quickStep:    {id:'quickStep', n:'Quick Step', tier:2, c:1, dice:[{t:'evade',lo:2,hi:5},{t:'pierce',lo:2,hi:4}], effects:[{trigger:'clashWin',status:'haste',potency:1,count:2,target:'self',chance:1},{trigger:'hit',status:'rupture',potency:1,count:2,chance:.6}]},
  brace:       {id:'brace', n:'Brace Yourself', tier:2, c:1, dice:[{t:'block',lo:2,hi:6},{t:'block',lo:1,hi:3}], effects:[{trigger:'clashWin',status:'protection',potency:1,count:1,target:'self',chance:1}]}
});
