// Skill 1 — Canard / Grade 9 baseline combat pages.
// These are data records, not an automatically granted deck. Copies enter inventory when the job is accepted.
window.PAGES = window.PAGES || {};
Object.assign(window.PAGES, {
  evade:       {id:'evade', n:'Evade', tier:1, c:0, dice:[{t:'evade',lo:1,hi:4}]},
  lightAtk:    {id:'lightAtk', n:'Light Attack', tier:1, c:1, dice:[{t:'pierce',lo:2,hi:3},{t:'blunt',lo:1,hi:4}], effects:[{trigger:'use',type:'restoreLight',amount:2}]},
  lightDef:    {id:'lightDef', n:'Light Defense', tier:1, c:1, dice:[{t:'evade',lo:1,hi:5},{t:'block',lo:2,hi:4}]},
  thrust:      {id:'thrust', n:'Thrust', tier:1, c:1, dice:[{t:'pierce',lo:1,hi:4},{t:'pierce',lo:1,hi:4}]},
  dodgeStrike: {id:'dodgeStrike', n:'Dodge and Strike', tier:1, c:1, dice:[{t:'evade',lo:1,hi:4},{t:'slash',lo:1,hi:3}], effects:[{trigger:'hit',status:'paralysis',potency:1,count:1,chance:.25}]},
  struggle:    {id:'struggle', n:'Struggle', tier:1, c:0, dice:[{t:'blunt',lo:1,hi:3}]},
  quickness:   {id:'quickness', n:'Quickness', tier:1, c:1, dice:[{t:'slash',lo:1,hi:3},{t:'evade',lo:1,hi:5}], effects:[{trigger:'use',type:'draw',amount:1}]},
  preparation:{id:'preparation', n:'Preparation', tier:1, c:1, dice:[{t:'block',lo:2,hi:5},{t:'block',lo:1,hi:4}], effects:[{trigger:'clashWin',status:'protection',value:1,duration:1,chance:1}]},
  parry:       {id:'parry', n:'Parry', tier:1, c:1, dice:[{t:'block',lo:1,hi:5},{t:'slash',lo:1,hi:3}], effects:[{trigger:'use',status:'strength',potency:1,count:1,target:'self',chance:1}]}
});
