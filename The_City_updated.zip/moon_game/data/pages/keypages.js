// Key Pages: equipment modifies combat statistics and runs a defined passive effect.
window.KEY_PAGES = {
  grade9: {id:'grade9',n:'Grade 9 Fixer',hp:48,stagger:26,res:{hp:{slash:1,pierce:1,blunt:1},st:{slash:1,pierce:1,blunt:1}},passive:{id:'associationBasics',n:'Association Basics',desc:'Every third Scene grants 1 extra Light.'}},
  pete_key: {id:'pete_key',n:"Pete's Page",hp:54,stagger:27,res:{hp:{slash:1.25,pierce:1,blunt:1.5},st:{slash:1.25,pierce:1,blunt:1.5}},passive:{id:'corneredLeader',n:'Cornered Leader',desc:'Gain +1 offensive power when only one enemy remains.'}},
  lenny_key: {id:'lenny_key',n:"Lenny's Page",hp:47,stagger:30,res:{hp:{slash:1,pierce:1.5,blunt:1.25},st:{slash:1,pierce:1.5,blunt:1.25}},passive:{id:'dirtyCut',n:'Dirty Cut',desc:'Once per Scene, a successful Pierce hit inflicts 1 Bleed.'}},
  mang_key: {id:'mang_key',n:"Mang-chi's Page",hp:52,stagger:29,res:{hp:{slash:1.5,pierce:1.25,blunt:1},st:{slash:1.5,pierce:1.25,blunt:1}},passive:{id:'hammerGrip',n:'Hammer Grip',desc:'Blunt attacks deal +1 damage.'}},
  finn_key: {id:'finn_key',n:"Finn's Page",hp:52,stagger:27,res:{hp:{slash:1.25,pierce:1,blunt:1},st:{slash:1.25,pierce:1,blunt:1}},passive:{id:'steadyRoutine',n:'Steady Routine',desc:'Every third Scene draws one extra Combat Page.'}},
  yun_key: {id:'yun_key',n:"Yun's Page",hp:56,stagger:28,res:{hp:{slash:1,pierce:1.25,blunt:1.25},st:{slash:1,pierce:1.25,blunt:1.25}},passive:{id:'operatorOverhead',n:'Operator Overhead',desc:'Every second Scene grants 1 extra Light.'}},
  eri_key: {id:'eri_key',n:"Eri's Page",hp:59,stagger:31,res:{hp:{slash:1.25,pierce:1,blunt:1},st:{slash:1.25,pierce:1,blunt:1}},passive:{id:'seniorPressure',n:'Senior Pressure',desc:'The first successful hit each Scene deals +1 damage.'}},
  mo_key: {id:'mo_key',n:"Mo's Page",hp:56,stagger:29,res:{hp:{slash:1,pierce:1.5,blunt:1},st:{slash:1,pierce:1.5,blunt:1}},passive:{id:'shockRoutine',n:'Shock Routine',desc:'Successful offensive hits have a 25% chance to inflict 1 Paralysis.'}},
  consta_key: {id:'consta_key',n:"Consta's Page",hp:54,stagger:29,res:{hp:{slash:1.25,pierce:1.25,blunt:1},st:{slash:1.25,pierce:1.25,blunt:1}},passive:{id:'shockRoutine',n:'Shock Routine',desc:'Successful offensive hits have a 25% chance to inflict 1 Paralysis.'}}
};

// A Book is an extraction source, not a Key Page itself. Each extraction yields one
// combat page from the source's real move pool and has a 32% chance to yield its Key Page.
window.BOOK_DATA = {
  book_pete:{n:"Book of Pete",key:'pete_key',pages:['shiv','dirty']},
  book_lenny:{n:"Book of Lenny",key:'lenny_key',pages:['shiv']},
  book_mang:{n:"Book of Mang-chi",key:'mang_key',pages:['shiv','dirty']},
  book_yun:{n:"Book of Yun",key:'yun_key',pages:['ledgerRead','feeCollection','focused']},
  book_finn:{n:"Book of Finn",key:'finn_key',pages:['finnResolve','quickStep']},
  book_eri:{n:"Book of Eri",key:'eri_key',pages:['quickStep','wallop','preemptive']},
  book_mo:{n:'Book of Mo',key:'mo_key',pages:['cChargeUp','bBlowItUp','cChop']},
  book_consta:{n:"Book of Consta",key:'consta_key',pages:['bBlowItUp','cChargeUp','cChop']},
  book_taein:{n:'Book of Taein',key:'taein_key',pages:['hookCut','rampage']},
  book_mccullin:{n:'Book of McCullin',key:'mccullin_key',pages:['overpower','track']},
  book_naoki:{n:'Book of Naoki',key:'naoki_key',pages:['fendThisOff','hookCut']}
};


Object.assign(window.KEY_PAGES, {
  taein_key:{id:'taein_key',n:"Taein's Page",hp:54,stagger:28,res:{hp:{slash:1,pierce:1.25,blunt:1.5},st:{slash:1,pierce:1.25,blunt:1.5}},passive:{id:'hookMomentum',n:'Hook Momentum',desc:'Defeating a foe grants 1 Strength for the next Scene.'}},
  mccullin_key:{id:'mccullin_key',n:"McCullin's Page",hp:52,stagger:27,res:{hp:{slash:1,pierce:1.5,blunt:1.25},st:{slash:1,pierce:1.5,blunt:1.25}},passive:{id:'dirtyCut',n:'Dirty Cut',desc:'Once per Scene, a successful Pierce hit inflicts 1 Bleed.'}},
  naoki_key:{id:'naoki_key',n:"Naoki's Page",hp:52,stagger:29,res:{hp:{slash:1.25,pierce:1,blunt:1.25},st:{slash:1.25,pierce:1,blunt:1.25}},passive:{id:'steadyRoutine',n:'Steady Routine',desc:'Every third Scene draws one extra Combat Page.'}}
});
Object.assign(window.BOOK_DATA, {
  book_taein:{n:'Book of Taein',key:'taein_key',pages:['hookCut','rampage']},
  book_mccullin:{n:'Book of McCullin',key:'mccullin_key',pages:['overpower','track']},
  book_naoki:{n:'Book of Naoki',key:'naoki_key',pages:['fendThisOff','hookCut']}
});
