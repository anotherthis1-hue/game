// Skill 3 — future pages. Data is intentionally present for story-book drops, but none are issued at Canard.
window.PAGES = window.PAGES || {};
Object.assign(window.PAGES, {
  relentless: {id:'relentless',n:'Relentless Advance',tier:3,c:3,dice:[{t:'slash',lo:3,hi:6},{t:'blunt',lo:3,hi:5}],effects:[{trigger:'clashWin',status:'strength',value:1,duration:1,chance:1}]},
  breakLine: {id:'breakLine',n:'Break the Line',tier:3,c:3,dice:[{t:'pierce',lo:4,hi:7},{t:'pierce',lo:2,hi:5}],effects:[{trigger:'hit',status:'fragile',value:1,duration:1,chance:.4}]},
  unyielding: {id:'unyielding',n:'Unyielding Guard',tier:3,c:2,dice:[{t:'block',lo:4,hi:7},{t:'block',lo:3,hi:6}],effects:[{trigger:'clashWin',status:'protection',value:2,duration:1,chance:1}]}
});
// Skill 3 — locked for later (Urban Myth+ / stronger Fixer)
window.PAGES = window.PAGES || {};
Object.assign(window.PAGES, {
  // placeholders for future updates — not in starter bookshelf
  strongStrike:{id:'strongStrike',n:'Strong Strike',tier:3,c:3,dice:[{t:'slash',lo:5,hi:7},{t:'blunt',lo:3,hi:4}]},
  multiBlock:  {id:'multiBlock',  n:'Multi-block',  tier:3,c:1,dice:[{t:'block',lo:1,hi:5},{t:'block',lo:3,hi:5},{t:'block',lo:1,hi:4}]}
});
