/* Urban Myth: Hana Association report and Fairy Festival examination dialogue.
   Narrative data only; later Urban Myth chapters stay placeholders. */
(function (global) {
  'use strict';
  global.URBAN_MYTH_DIALOGUE = global.URBAN_MYTH_DIALOGUE || {};
  global.URBAN_MYTH_DIALOGUE.buildHanaExamination = function ({ playerName, flags, reputation }) {
    flags = flags || {};
    const fate = id => global.CityCanon?.fateFor?.(flags, id) || 'unknown';
    reputation = Math.max(0, Math.min(100, Number(reputation) || 0));
    const name = String(playerName || 'the candidate');
    const officeLines = [];
    const addOffice = (title, people) => {
      const dead = people.filter(([key]) => fate(key) === 'dead').map(([, n]) => n);
      const alive = people.filter(([key]) => fate(key) === 'alive').map(([, n]) => n);
      if (dead.length) {
        officeLines.push({ who: 'Hana Association — Staff Member A', title: 'Internal Discussion', t: `${title}. Dead listed: ${dead.join(', ')}.` });
        if (alive.length) officeLines.push({ who: 'Hana Association — Staff Member B', title: 'Internal Discussion', t: `${alive.join(', ')} walked away. Incomplete wipe.` });
      }
    };
    addOffice("Yun's Office", [['yun', 'Yun'], ['eri', 'Eri'], ['finn', 'Finn']]);
    addOffice('Brotherhood of Iron', [['mo', 'Mo'], ['consta', 'Consta'], ['arnold', 'Arnold']]);
    addOffice('Hook Office', [['naoki', 'Naoki'], ['mccullin', 'McCullin'], ['taein', 'Taein']]);

    const lines = [
      { who: 'Hana Association — Staff Member A', title: 'Internal Discussion', t: 'Grade 8 name keeps showing up in Canard noise. Same Fixer, three offices.' },
      { who: 'Hana Association — Staff Member B', title: 'Internal Discussion', t: 'We only flag the ones with bodies attached. The rest is paperwork.' },
      ...(officeLines.length
        ? officeLines
        : [{ who: 'Hana Association — Staff Member A', title: 'Internal Discussion', t: 'No casualty lines on the three office jobs. Quiet file. Almost boring.' }]),
      ...(reputation >= 65
        ? [
            { who: 'Hana Association — Staff Member B', title: 'Internal Discussion', t: 'Street talk likes them. Helped people who could have been problems.' },
            { who: 'Hana Association — Staff Member A', title: 'Internal Discussion', t: 'Doesn’t mean the next call goes clean. Pattern’s still a pattern.' }
          ]
        : reputation <= 35
          ? [
              { who: 'Hana Association — Staff Member B', title: 'Internal Discussion', t: 'Reputation’s in the dirt. Too many rooms end with a body count.' },
              { who: 'Hana Association — Staff Member A', title: 'Internal Discussion', t: 'Then we watch judgment, not just the swing. Still no excuse to decide before the test.' }
            ]
          : [
              { who: 'Hana Association — Staff Member B', title: 'Internal Discussion', t: 'Mixed file. Not a saint. Not a walking hazard on paper.' },
              { who: 'Hana Association — Staff Member A', title: 'Internal Discussion', t: 'Exam will say more than the gossip does.' }
            ]),
      { who: 'Hana Association — Staff Member B', title: 'Internal Discussion', t: 'Bring them in?' },
      { who: 'Hana Association — Staff Member A', title: 'Internal Discussion', t: 'Standard abnormality exam. Fold the result into the rest of the file.' },
      { t: 'The reports are stacked, closed, and walked down to the examination hall.' },
      { k: 'hanaReveal' },

      // Zevelyn — dry, cold, sarcastic, no filter; not invested in your drama
      { loc: 'Hana Association — Examination Hall', bg: 'hana', who: 'Zevelyn', title: 'Eden Office Fixer', side: 'left',
        t: `Oh. ${name}. The paper celebrity. Newbie Grade 9 who somehow didn’t die on schedule… or some shit like that.` },
      { loc: 'Hana Association — Examination Hall', bg: 'hana', who: 'Zevelyn', title: 'Eden Office Fixer', side: 'left',
        t: "Don’t look at me like I’m your mentor. I’m here because Eden needs the stamp. You’re here because Hana wants a show. That’s the whole friendship." },
      { loc: 'Hana Association — Examination Hall', bg: 'hana', who: 'Zevelyn', title: 'Eden Office Fixer', side: 'left',
        t: "I don’t care how messy your Canard jobs got. Not my office. Not my problem. Try not to bleed on the floor; the staff hate that." },

      { loc: 'Hana Association — Examination Hall', bg: 'hana', who: 'Han-ul', title: 'Hana Association — Grade 1 Fixer', side: 'right',
        t: 'This examination uses a controlled abnormality. Fairy Festival. Observe recovery behavior under pressure. Begin when ready.' },

      { loc: 'Hana Association — Examination Hall', bg: 'hana', who: 'Zevelyn', title: 'Eden Office Fixer', side: 'left',
        t: "Yeah, yeah. Fairy bullshit that knits itself back together. If your first idea stops working, use a second one. I’m not catching you if you freeze." },
      { loc: 'Hana Association — Examination Hall', bg: 'hana', who: 'Zevelyn', title: 'Eden Office Fixer', side: 'left',
        t: "…What? You wanted a speech? Go swing. Good luck. Or don’t. Either way I still get my afternoon back." },

      { k: 'battle', encounter: 'fairyFestival', bg: 'hana' }
    ];
    return lines;
  };
})(window);
