window.CANARD_MISSIONS = Object.assign(window.CANARD_MISSIONS || {}, {
brotherhood: {
    name:'Brotherhood of Iron — The Missing Crate', unlockAfter:'yunOffice', encounter:'brotherhood',
    start:[
      {loc:'Backstreets — Workshop Row approach',bg:'back',t:'The shipment trail ends at Workshop Row. You are still on the street when two iron silhouettes cut across the loading alley and stop in front of you. They found you first.'},
      {who:'Mo',title:'Brotherhood of Iron',side:'left',t:'That’s far enough. You’ve been asking about a crate. That crate is ours now. We took it off a dead route before some Workshop clerk sold the parts twice.'},
      {who:'Consta',title:'Brotherhood of Iron',side:'mid',t:'I—I sorted everything. Bolts, plates, joint sleeves. No noodles this time. Just metal. Please don’t kick the crate. It took me forever.'},
      {who:'Mo',title:'Brotherhood of Iron',side:'left',t:'Consta. Quiet. Look—our legs don’t last. Workshops price a single clean joint like a month of food. We’re not thieves for fun. We’re keeping ourselves upright.'},
      {who:'Consta',title:'Brotherhood of Iron',side:'mid',t:'If the list is wrong, that’s not the same as us stealing! The seal was already cut when it got here. I wrote the time. I always write the time…'},
      {who:'Mo',title:'Brotherhood of Iron',side:'left',t:'You can walk away and write that the trail went cold. Or you can try to take the crate. We’re not handing it over so some report looks neat.'},
      C('How do you answer the Brotherhood?',[
        {t:'Demand the crate for the contract',d:'Close the job the hard way.',say:'The contract names that shipment. Hand it over or I take it.',route:'iron_force',tags:['direct']},
        {t:'Ask what the parts are for',d:'Hear them out before you decide.',say:'What are you fixing with those parts? Talk. Then I’ll decide what goes in the report.',route:'iron_ask',tags:['observant']},
        {t:'Warn them the report will name them',d:'Put the Association paper on the table.',say:'If I walk back empty, the report still gets written—and it will have your names on it.',route:'iron_warn',tags:['threat']},
        {t:'Help them keep what they need',d:'Let the haul stay. File a quiet report.',say:'Keep the parts you need to walk. I’ll mark the shipment unrecoverable. Don’t make me regret it.',route:'iron_help',tags:['merciful','calm']}
      ])
    ],
    post:[
      {loc:'Brotherhood of Iron — Workshop',bg:'brotherhood',t:'The workshop is quiet except for cooling metal. Mo and Consta do not get up. The crate sits open—plates, joint sleeves, serial marks still readable.'},
      {who:'Arnold',title:'Brotherhood of Iron — Leader',side:'right',t:'…So that’s how it ends. We took what the City priced out of reach. You took it back. Fair, in a filthy way.'},
      {t:'You seal what remains of the crate for the report. Workshop parts, Association fee, and whatever else the job listed as recovered—all of it goes with you.'},
      {k:'missionOutcome',id:'brotherhood',outcome:'fight'},
      {k:'missionEnd',id:'brotherhood'}
    ],
    postReplay:[
      {loc:'Brotherhood of Iron — Workshop',bg:'brotherhood',t:'The workshop settles. The crate is collected for the report. The street outside does not care how the iron bodies fell.'},
      {k:'missionEnd',id:'brotherhood'}
    ]
  }
});
