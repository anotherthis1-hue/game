window.ROUTE_TABLE = Object.assign(window.ROUTE_TABLE || {}, {
  iron_force:[
    {who:'Mo',title:'Brotherhood of Iron',side:'left',t:'Then stop talking. Consta—behind me.'},
    {who:'Consta',title:'Brotherhood of Iron',side:'mid',t:'I—I just finished stacking the sleeves—!'},
    {who:'Mo',title:'Brotherhood of Iron',side:'left',t:'Stack later. We hold the alley.'},
    {k:'missionOutcome',id:'brotherhood',outcome:'fight'},
    {k:'battle',encounter:'brotherhood',bg:'back'}
  ],
  iron_ask:[
    {who:'Consta',title:'Brotherhood of Iron',side:'mid',t:'M-my knee’s grinding again. Without a new sleeve it locks. Then I fall. Then Mo has to drag me. That’s… that’s all.'},
    {who:'Mo',title:'Brotherhood of Iron',side:'left',t:'Arnold said if we wait for a “legal” sale we’ll be scrap before the papers clear. So we took a crate that was already cut open. You want a speech? That’s it.'},
    {who:'Mo',title:'Brotherhood of Iron',side:'left',t:'Sympathy doesn’t move iron. If you’re still here for the shipment, come take it.'},
    {k:'missionOutcome',id:'brotherhood',outcome:'fight'},
    {k:'battle',encounter:'brotherhood',bg:'back'}
  ],
  iron_warn:[
    {who:'Consta',title:'Brotherhood of Iron',side:'mid',t:'N-names? On a report? We didn’t—look, the list is right here—'},
    {who:'Mo',title:'Brotherhood of Iron',side:'left',t:'A warning is still a threat. You want us quiet while someone files us as thieves? No.'},
    {who:'Mo',title:'Brotherhood of Iron',side:'left',t:'Show us empty hands leaving this alley—or try to go through us.'},
    {k:'missionOutcome',id:'brotherhood',outcome:'fight'},
    {k:'battle',encounter:'brotherhood',bg:'back'}
  ],
  iron_help:[
    {k:'missionOutcome',id:'brotherhood',outcome:'helped'},
    {who:'Mo',title:'Brotherhood of Iron',side:'left',t:'…You’re serious. You’re going to write that the trail died on the Row.'},
    {who:'Consta',title:'Brotherhood of Iron',side:'mid',t:'Th-thank you. Really. I can keep the knee sleeve. I won’t forget. I write things down so I don’t forget.'},
    {who:'Mo',title:'Brotherhood of Iron',side:'left',t:'Arnold will want to pay you something. Not Association rates. Our rates. Take it and don’t come back asking for the crate.'},
    {t:'Mo counts out a thin stack of Ahn—thanks from the Brotherhood, not a contract payout. No Books. No “recovered” parts for the report. The crate stays with them.'},
    {who:'Consta',title:'Brotherhood of Iron',side:'mid',t:'If you ever need… uh… a bolt tightened? I’m good at sorting. Not fighting. Sorting.'},
    {who:'Mo',title:'Brotherhood of Iron',side:'left',t:'Go. Before we change our minds about trusting a Fixer.'},
    {k:'missionEnd',id:'brotherhood'}
  ]
});
