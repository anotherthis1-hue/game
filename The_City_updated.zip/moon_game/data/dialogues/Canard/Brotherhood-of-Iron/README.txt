Brotherhood of Iron dialogue lives in routes.js and missions.js. Keep dialogue in individual turns for Mo and Consta.
