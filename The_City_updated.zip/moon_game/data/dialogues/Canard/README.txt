CANARD DIALOGUES

Story dialogue is split by reception/route. Edit the JavaScript files inside the named subfolders; the game loads them directly.

Backstreets-Rats/dialogue.js — Rats branch dialogue.
Yun-Office/routes.js and missions.js — Yun's Office and Finn route choices and scenes.
Brotherhood-of-Iron/routes.js and missions.js — Brotherhood routes and scenes.
Hook-Office/routes.js and missions.js — Hook Office routes and scenes.

Each line with a `who` field is one speaker turn. Use a separate entry for each character turn. Use entries without `who` only for narration/scene-setting.

DIALOGUE DISPLAY RULE
- A non-empty `who` field means that named character is speaking in first person. The game adds quotation marks automatically; do not write stage directions or describe the speaker in third person in that field.
- A missing/empty `who` field (or `who: 'Narrator'`) is narration; it has no speaker name and no dialogue portrait.
- Keep one character per entry. Example: {who:'Finn', title:'Grade 9 Fixer', t:'“I checked the route twice.”'}

ECONOMY
- Currency is Ahn, displayed as whole-number amounts with Korean-style thousands separators (for example, 10,000 Ahn); there are no decimal subunits.
- Winning repeatable contracts grants Ahn as well as the usual Book drops. Rates are configured in `js/engine.js` in `missionPay`.
- The hub's Market & Workshop Shop lists item descriptions and prices before the purchase button. Prices and reward rates can be adjusted in `js/engine.js`.
