Canard / Fingers

Reserved folder for future fingers-related story content at the Canard stage. This is intentionally a placeholder: no additional mission, faction, or chapter becomes playable just because this folder exists.
