Backstreets Rats dialogue lives in dialogue.js. Each `who` entry is a single speaker turn; keep Pete, Lenny, and Mang Chi as separate turns.
