window.RAT_ROUTES = {
  rat_direct: [
    {who:'Pete',title:'Backstreets Rat — Leader',t:'A contract? So somebody paid you to come tell us to leave. Must be nice, getting paid before you even do the hard part.'},
    {who:'Lenny',title:'Backstreets Rat',t:'Pete, the stamp’s real. I checked it. So either the stall owner hired help, or somebody wants us gone badly enough to pay for it.'},
    {who:'Pete',title:'Backstreets Rat — Leader',t:'Yeah, well, I’m not giving up a good corner because some paper says so.'},
    C('Pete folds his arms and waits. What do you put first?',[
      {t:'Show the stamped order',d:'Make the contract the issue.',say:'The order has the Association seal. You can leave now, or I can put your names in the report.',route:'rat_direct_order',tags:['direct','prepared']},
      {t:'Ask who owns the corner',d:'Get their version before things escalate.',say:'Who told you this corner was yours? I want to hear the story before this gets worse.',route:'rat_direct_owner',tags:['direct','observant']},
      {t:'Move between them and the stall',d:'Give the stall owner room to get away.',say:'The stall owner is leaving. You want to argue, argue with me.',route:'rat_direct_stall',tags:['direct','protective']}
    ])
  ],
  rat_calm: [
    {who:'Pete',title:'Backstreets Rat — Leader',t:'“We can all walk away.” Sure. And then what, you write down that we were nice about it?'},
    {who:'Mang Chi',title:'Backstreets Rat',t:'We could leave. I’m not saying we should, but… there’s another street over by the old stairwell. Less foot traffic.'},
    {who:'Lenny',title:'Backstreets Rat',t:'And less money. We’ve got until tomorrow to pay what we owe. Nobody’s going to care that we left politely.'},
    C('Pete looks from you to the stall. How do you make the offer work?',[
      {t:'Offer a clean exit',d:'Let them retreat without making a show of it.',say:'Walk away. I’ll report the corner clear. No need to write down who backed off.',route:'rat_calm_exit',tags:['calm','merciful']},
      {t:'Ask what happens if they leave empty-handed',d:'Find out what is really keeping them here.',say:'You keep looking over your shoulder. Who’s waiting for you if you go back with nothing?',route:'rat_calm_question',tags:['calm','observant']},
      {t:'Offer to mark the job complete if they leave',d:'Make a practical deal.',say:'Leave the stall alone and I’ll mark the job complete. I’m not offering you money.',route:'rat_calm_bargain',tags:['calm','bargain']}
    ])
  ],
  rat_silent: [
    {who:'Lenny',title:'Backstreets Rat',t:'Boss, they’re not answering. Their eyes keep going to your hands.'},
    {who:'Pete',title:'Backstreets Rat — Leader',t:'I noticed. I’m trying to figure out if they’re brave or just bad at talking.'},
    {who:'Mang Chi',title:'Backstreets Rat',t:'M-maybe they’re waiting for us to calm down. We don’t have to start anything yet.'},
    {who:'Pete',title:'Backstreets Rat — Leader',t:'One chance. Say something with that silence, or stop wasting my time.'},
    C('They wait. What do you do?',[
      {t:'Watch Pete’s hands',d:'Keep an eye on the one giving orders.',say:'You watch Pete’s hands and wait to see who moves first.',route:'rat_silent_watch',tags:['silent','observant']},
      {t:'Look to the stall owner',d:'Make sure the person behind the job can leave.',say:'You check that the stall owner has a clear way out.',route:'rat_silent_stall',tags:['silent','protective']},
      {t:'Reach for the job paper',d:'Show them you are not bluffing.',say:'You take the contract out and hold it where they can see the seal.',route:'rat_silent_paper',tags:['silent','prepared']}
    ])
  ],
  rat_direct_order:[
    {t:'Pete glances at the seal and snorts. It is real, but that does not mean he plans to obey it.'},
    {who:'Pete',title:'Backstreets Rat — Leader',t:'All right, I’ve seen your fancy stamp. Now let’s see if you can do more than wave paper around.'},
    {k:'fightHook'}
  ],
  rat_direct_owner:[
    {who:'Lenny',title:'Backstreets Rat',t:'The stall owner paid another crew last week. They stopped showing up, so we took the corner. That’s how it goes.'},
    {who:'Pete',title:'Backstreets Rat — Leader',t:'Nobody owns a corner just because they stood on it yesterday. You gonna explain that to every crew in the Backstreets?'},
    {k:'fightHook'}
  ],
  rat_direct_stall:[
    {t:'The stall owner backs toward the door. Mang Chi notices first, then looks at Pete to see whether he will stop them.'},
    {who:'Pete',title:'Backstreets Rat — Leader',t:'Look at you, playing bodyguard. Fine. You’re the one standing in front of us now.'},
    {k:'fightHook'}
  ],
  rat_calm_exit:[
    {who:'Pete',title:'Backstreets Rat — Leader',t:'You’re offering us an exit and a clean report. What, you think I’m going to thank you for it?'},
    {who:'Lenny',title:'Backstreets Rat',t:'Pete, it’s still better than getting hauled in. We can’t pay a fine with pride.'},
    {who:'Pete',title:'Backstreets Rat — Leader',t:'Then prove you mean it. I’m not leaving because you asked nicely.'},
    {k:'fightHook'}
  ],
  rat_calm_question:[
    {who:'Pete',title:'Backstreets Rat — Leader',t:'A place in a better crew. Some cash. A chance to stop being the guy everyone steps over. Pick your favorite.'},
    {who:'Mang Chi',title:'Backstreets Rat',t:'He means we owe people. If we go back with nothing, they’ll take it out on us.'},
    {who:'Pete',title:'Backstreets Rat — Leader',t:'Don’t tell our business to strangers, Mang Chi. This corner’s still ours.'},
    {k:'fightHook'}
  ],
  rat_calm_bargain:[
    {who:'Lenny',title:'Backstreets Rat',t:'No money, no corner, and a report that says we backed down. That’s not a deal, Pete.'},
    {who:'Pete',title:'Backstreets Rat — Leader',t:'Exactly. You’ve got the contract, we’ve got the corner. Let’s find out whose claim holds up.'},
    {k:'fightHook'}
  ],
  rat_silent_watch:[
    {t:'You keep your eyes on Pete’s hands. He notices and holds them out, empty, with a nasty little grin.'},
    {who:'Pete',title:'Backstreets Rat — Leader',t:'Good. At least you know who you need to watch. Now do your job.'},
    {k:'fightHook'}
  ],
  rat_silent_stall:[
    {t:'The stall owner slips toward the rear door. Lenny spots it, but for once she does not try to stop them.'},
    {who:'Pete',title:'Backstreets Rat — Leader',t:'Eyes back here, Fixer. You came for the job, not a rescue story.'},
    {k:'fightHook'}
  ],
  rat_silent_paper:[
    {t:'Pete studies the paper a moment longer than he wants you to notice. Lenny leans in to check the seal too.'},
    {who:'Pete',title:'Backstreets Rat — Leader',t:'Fine. You showed me the paper. I’ll show you why I’m not giving up this spot.'},
    {k:'fightHook'}
  ]
};
