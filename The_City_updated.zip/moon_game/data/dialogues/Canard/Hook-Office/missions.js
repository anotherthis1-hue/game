window.CANARD_MISSIONS = Object.assign(window.CANARD_MISSIONS || {}, {
hookOffice: {
    name:'Hook Office — Competing Contract', unlockAfter:'brotherhood', encounter:'hookOffice',
    start:[
      {loc:'Workshop Row',bg:'brotherhood',t:'The Workshop inquiry closes with a report on the missing crate and the altered delivery record. The evidence now leads toward a recovery contract issued by the Hook Office. The same parcel shows up again under a different client name and a broader recovery order issued to the Hook Office.'},
      {loc:'Backstreets — Approach to Hook territory',bg:'city',t:'You go looking for them. Hook Office does not come to you—this is their stretch of the street, and you walk into it with the corrected records in hand.'},
      {loc:'Backstreets — Contract Passage',bg:'hook',t:'Three of them are already arguing over a marked map when you step into the passage. They notice you the moment you produce the papers.'},
      {who:'Naoki',title:'Hook Office',t:'You’re the Fixer with the other report. Let me see it. I’m not giving up a paid job because somebody waves paper around, but I’m not walking in blind either.'},
      {who:'Taein',title:'Hook Office',t:'The seals don’t match. Obviously someone lied. The question is whether we’re wasting time arguing about it or finishing the job we already took.'},
      {who:'McCullin',title:'Hook Office',t:'We can do both. Let them explain the paper, then we decide what it’s worth. If the client lied, the client pays for the lie. If this Fixer is bluffing, we finish the contract the hard way.'},
      {who:'Naoki',title:'Hook Office',t:'Talk. You came into our passage, so you get one clean chance to make the records matter before we decide this is just another interference job.'},
      C('How do you handle the competing contract?',[
        {t:'Show the corrected receipt',d:'Put the conflicting evidence on the table.',say:'Here’s the verified route and the original seal. Your client gave you a false description.',route:'hook_receipt'},
        {t:'Read the contract terms',d:'Check what their client actually authorized.',say:'Let’s read the whole order before we decide what it allows.',route:'hook_terms'},
        {t:'Warn them about the false claim',d:'Give them one chance to withdraw.',say:'Someone used fake records to put two Offices on the same job. You can still walk away.',route:'hook_warn'},
        {t:'Help the Hook Office verify the contract',d:'Resolve the contradiction before anyone gets hurt.',say:'Let’s check the client’s claim against the original records. Nobody needs to fight over a forged order.',route:'hook_help'}
      ])
    ],
    post:[
      {loc:'Backstreets — Contract Passage',bg:'hook',t:'Naoki, Taein, and McCullin are left too badly injured to survive the fight. All three die in the aftermath. No member of the Hook Office survives this contract, and no one remains to dispute the report.'},
      {t:'The false claim and the conflicting contract are attached to the final incident record. The job is complete, but the Hook Office is left with no surviving member from this encounter.'},
      {k:'missionEnd',id:'hookOffice'}
    ],
    postReplay:[
      {loc:'Backstreets — Contract Passage',bg:'hook',t:'The conflicting contract and the false claim are collected as evidence. The job closes with the original records attached to the report.'},
      {k:'missionEnd',id:'hookOffice'}
    ]
  }
});
