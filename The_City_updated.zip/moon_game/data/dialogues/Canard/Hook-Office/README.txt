Hook Office dialogue lives in routes.js and missions.js. The reception uses named characters Taein, McCullin, and Naoki only.
