window.ROUTE_TABLE = Object.assign(window.ROUTE_TABLE || {}, {
hook_receipt:[
    {who:'Taein',title:'Hook Office',t:'Those marks are wrong. Whoever copied them rushed the last stroke. Cheap work. I could have spotted it from across the room.'},
    {who:'Naoki',title:'Hook Office',t:'So our client lied. Great. We still signed for the job, and I’m not walking off until we know what we’re dealing with.'},
    {who:'McCullin',title:'Hook Office',t:'You’ve shown us a problem. You haven’t settled what happens next. Move aside, and we’ll sort it out.'},
    {k:'battle',encounter:'hookOffice'}
  ],
hook_terms:[
    {who:'McCullin',title:'Hook Office',t:'Here. Read it. The client wrote “recover by any means” and paid extra for speed. They left the useful details out. That’s not unusual.'},
    {who:'Taein',title:'Hook Office',t:'The terms don’t make the claim true. They just tell us what the client wanted. I say we stop wasting the afternoon.'},
    {k:'battle',encounter:'hookOffice'}
  ],
hook_warn:[
    {who:'Naoki',title:'Hook Office',t:'I don’t like being used. But I like being told to drop a contract by someone I just met even less. Give me one good reason to trust you.'},
    {who:'McCullin',title:'Hook Office',t:'We’re already here, Naoki. We can talk about trusting people after the job is settled.'},
    {who:'Taein',title:'Hook Office',t:'Finally. Are we moving or not?'},
    {k:'battle',encounter:'hookOffice'}
  ]
});

window.ROUTE_TABLE = Object.assign(window.ROUTE_TABLE || {}, {
  hook_help:[
    {k:'missionOutcome',id:'hookOffice',outcome:'helped'},
    {who:'Naoki',title:'Hook Office',t:'The client gave us a false description. I do not like being used, but I like fighting over forged paperwork even less. We will submit the contract and the corrected receipt together.'},
    {who:'Taein',title:'Hook Office',t:'Then the order is suspended until the client answers for it. That is better than getting ourselves killed for somebody else’s lie.'},
    {who:'McCullin',title:'Hook Office',t:'Good. Let the evidence do the arguing for once.'},
    {t:'The Hook Office withdraws from the disputed recovery job and submits the false contract for review. Naoki, Taein, and McCullin all survive.'},
    {k:'missionEnd',id:'hookOffice'}
  ]
});
