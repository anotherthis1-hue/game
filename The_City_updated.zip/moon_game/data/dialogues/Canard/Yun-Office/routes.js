// Yun's Canard story is intentionally one continuous ledger-dispute reception.
// Older delivery and repeat-confrontation branches were removed to avoid reviving
// characters after multiple contradictory fights.
window.ROUTE_TABLE = Object.assign(window.ROUTE_TABLE || {}, {});

window.ROUTE_TABLE = Object.assign(window.ROUTE_TABLE || {}, {
  yun_fight:[{k:'battle',encounter:'yunOffice'}],
  yun_help:[
    {k:'missionOutcome',id:'yunOffice',outcome:'helped'},
    {who:'Finn',title:"Yun's Office — Grade 9 Fixer",t:'Thank you. I thought this was going to end with us tearing each other apart. The original notes show where the ledger was changed; we can send the evidence to the clerk instead of turning on one another.'},
    {who:'Yun',title:'Office Operator',t:'I will answer for the entries that bear my name. But I will not let a forged record turn my Office against itself. We will submit the ledger, the seal, and Finn’s notes together.'},
    {t:"The dispute is referred for investigation. Yun, Eri, and Finn survive the reception, and the evidence is filed without the Office being destroyed."},
    {k:'missionEnd',id:'yunOffice'}
  ]
});
