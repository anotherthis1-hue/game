Yun's Office and Finn route dialogue lives in routes.js and missions.js. Named characters: Finn, Yun, Eri. Generic enemy sprite placeholders have been removed; Rats reuse the named Rats encounter.
