window.CANARD_MISSIONS = Object.assign(window.CANARD_MISSIONS || {}, {
  yunOffice: {
    name:"Yun's Office — The Ledger Dispute", unlockAfter:'rats', encounter:'yunOffice',
    start:[
      {loc:'Backstreets — Near the ledger stall',bg:'back',t:'The Rats job is already on the record. You are still on the street when three people from a small Office cut across your path and stop you cold. They did not wait for you to find them.'},
      {who:'Finn',title:"Yun's Office — Grade 9 Fixer",t:'Hold on. You’re the Fixer who just cleared the Rats corner, right? I tracked the false payment entries to the same stretch of stalls. If you walk past this, the report is going to look like we were the ones who forged the seal.'},
      {who:'Eri',title:'Grade 8 Fixer',t:'I checked the stamp myself. It is a copy. The money trail is real. We are not leaving this street until someone accounts for the difference.'},
      {who:'Yun',title:'Office Operator',t:'I am Yun. This is my Office’s ledger they are arguing about. You did not come looking for us—we came looking for the person who just finished a contract on this route. If your name is going to appear next to that report, you will hear our side before anyone files another word.'},
      {who:'Finn',title:"Yun's Office — Grade 9 Fixer",t:'I kept the original delivery sheet and the times from the stall. Someone altered the entries after I signed the first pass. I know I have made mistakes before. This is not one of them.'},
      {who:'Eri',title:'Grade 8 Fixer',t:'Yun wants this handled cleanly. Finn wants it handled honestly. I want it handled before another Office turns the whole thing into an accusation against us.'},
      {who:'Yun',title:'Office Operator',t:'So. You are standing here with us whether you planned to or not. We can compare the records and close the dispute, or someone can insist on settling it the hard way in public. Choose carefully.'},
      C('How do you resolve the ledger dispute?', [
        {t:'Force the issue and fight',d:'Refuse to let them control the narrative.',say:'I am not being pulled into your internal mess. If you want a verdict right here, we settle it the hard way.',route:'yun_fight'},
        {t:'Help them submit the evidence',d:'Work with them so the Office is not destroyed over a forged seal.',say:'Show me the original sheet and the copied seal. We document it properly and submit the record. There is no need to turn this into a street fight.',route:'yun_help'}
      ])
    ],
    post:[
      {loc:'Backstreets — Ledger Stall',bg:'back',t:'The fight leaves Yun and Eri with injuries no one walks away from. The ledger and the copied seal stay on the table, evidence in a case that no longer has an Office left to defend it.'},
      {who:'Finn',title:"Yun's Office — Grade 9 Fixer",t:'I made it out. Yun and Eri are gone. I am the only one left. I will hand over the route notes, the ledger, and every statement I kept. Nobody gets to rewrite those now.'},
      {loc:'Backstreets — Ledger Stall',bg:'back',t:'Finn is recorded as the sole survivor of Yun’s Office. He turns the evidence over and leaves alone. In the canonical timeline, the dispute does not repeat.'},
      {k:'missionEnd',id:'yunOffice'}
    ],
    postReplay:[
      {loc:'Backstreets — Ledger Stall',bg:'back',t:'The ledger and copied seal are gathered as evidence. Finn stays long enough to make sure the clerk receives the full record.'},
      {k:'missionEnd',id:'yunOffice'}
    ]
  }
});
