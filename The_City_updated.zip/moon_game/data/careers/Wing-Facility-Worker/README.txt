Wing-Facility-Worker

Reserved career/job system data. This is a planning folder only; no career, pay, mission, or progression mechanics are activated by this placeholder.
