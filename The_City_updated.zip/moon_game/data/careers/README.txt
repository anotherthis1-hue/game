CAREER / JOB SYSTEM PLACEHOLDERS

Prepared for later Syndicate, Fixer/Association, Wing facility worker, L Corp/LCE extraction, R Corp, W Corp cleanup, and Nest Administrator systems. All folders are scaffolding only.
