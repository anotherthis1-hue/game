FACTION SCAFFOLDING ONLY
Separate placeholders are prepared for Associations, Fingers, and Wings, including W Corp, R Corp, and K Corp. Empty folders do not imply playable recruitment/employment features.
