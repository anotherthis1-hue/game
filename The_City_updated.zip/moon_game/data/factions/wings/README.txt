Wing directories are prepared alphabetically; individual folders are placeholders only.
