FINGER PLACEHOLDER: Middle
Reserved for future joinable Finger/faction data. No recruitment or gameplay is implemented by this folder.
