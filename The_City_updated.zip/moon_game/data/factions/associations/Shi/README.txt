ASSOCIATION PLACEHOLDER: Shi
Reserved for future joinable Association data. No joining system or missions are implemented by this folder.
