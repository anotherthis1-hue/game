ABNORMALITY ART ASSETS

Store abnormality sprites here instead of assets/sprites/. Fairy Festival's combat sprite is assets/abnormalities/fairy-festival.webp, and the engine's sprite lookup points to this path.
