THE CITY — PROJECT GUIDE (single source of truth)
Fan-made RPG prototype inspired by Library of Ruina and Limbus Company.
Not affiliated with Project Moon. Prototype focused on Canard → early Urban Myth.

═══════════════════════════════════════════════════════════════
RUNNING
═══════════════════════════════════════════════════════════════
1. Keep the full folder structure.
2. Open index.html in a modern browser, or (preferred) serve the folder with any static HTTP server.
3. Preloader checks assets; missing optional art does not block start. Missing character sprites simply stay absent (no placeholders).
4. Landscape orientation recommended for combat. Test touch on target phones before release.

═══════════════════════════════════════════════════════════════
CODE MAP
═══════════════════════════════════════════════════════════════
index.html                  UI shells + script load order
css/main.css                layout, fades, combat UI, VN stage
js/helpers.js               story helpers O() / C()
js/engine.js                runtime: save, dialogue, battle, inventory, hub, travel, Grade system
js/data/story.js            origin prologue + Grade 9 job
js/data/canon.js            persistent canon fates, save migration, replay-safe API
js/easter-eggs/easter-eggs.js  name messages & optional buffs (loaded before engine)

data/dialogues/Canard/      Rats, Yun’s Office, Brotherhood of Iron, Hook Office
data/dialogues/Urban-Myth/  Hana examination + Fairy Festival
data/pages/                 Combat Pages, Key Pages, weapons, enemy rosters
data/abnormalities/         Fairy Festival definition
assets/bg/                  location backgrounds
assets/sprites/             character sprites (WebP, transparent)
assets/abnormalities/       abnormality combat art
assets/icon/                UI icons (Start Clash, Stagger)

tests/smoke-check.js        syntax + data reference checks
tests/story-canon-check.js  canon / migration / replay safety

═══════════════════════════════════════════════════════════════
STORY FLOW (CURRENT)
═══════════════════════════════════════════════════════════════
Origin → Grade 9 Fixer → Canard receptions → Grade 8 promotion → Urban Myth panel unlocks.

Canard receptions (order + encounter framing):
  • Rats              — player encounters them (Backstreets)
  • Yun’s Office      — they encounter the player
  • Brotherhood of Iron — they encounter the player
  • Hook Office       — player encounters them

After all three office receptions (Yun / Brotherhood / Hook) are officially completed once:
  • Player is promoted to Grade 8.
  • Urban Myth becomes available as its own panel on the Fixer board.
  • Canard panel remains fully accessible for replays.

Urban Myth (current scope):
  • Hana Association black-screen report (adapts to helped vs fight outcomes + Reputation)
  • Zevelyn (Eden Office Fixer) + Han-ul (Hana Association Grade 1) scene
  • Solo Fairy Festival examination
  • Ends after the exam for now; later Urban Myth chapters are scaffolding only.

Canon rules:
  • First official clear of each reception locks character fates.
  • Replays use the same dialogue/choices but cannot overwrite canon or Reputation.
  • Query fates with window.cityCharacterFate(id) or CityCanon.fateFor(flags, id).

Canonical first-clear outcomes:
  Rats          → Pete, Lenny, Mang Chi die
  Yun’s Office  → Yun + Eri die, Finn survives
  Brotherhood   → Mo + Consta die, Arnold sole survivor
  Hook Office   → Naoki, Taein, McCullin die

═══════════════════════════════════════════════════════════════
SYSTEMS
═══════════════════════════════════════════════════════════════
Combat          Speed dice, Combat Pages, Light (hex pips), Clash assignment, multi-Act waves,
                Stagger, Emotion. Enemy pages cycle in fixed order.
Statuses        Bleed, Rupture, Tremor (+Burst), Charge, Strength, Haste, Paralysis, Disarm,
                Protection, Fragile, Burn (simplified fan adaptations).
Inventory       Combat Pages (stack, max 9 equipped), Key Pages (1), Books, Weapons (2 slots),
                Consumables, Body Gear (head/eyes/face/torso/arms/legs/feet/neural).
Shops           Market Street (general) + Nest authorized counter (K Corp Ampule, Nest-grade
                gear, Nest-only weapons).
Progression     Fixer Level 1–30. EXP is pending until mission is officially completed.
Travel          Fixed route slots. Backstreets Fixer board is the hub for reception panels.
Reputation      0–100. Only the first clear of each of the three offices changes it
                (+12 help / –8 fight).
Save            localStorage + JSON export/import. Version 4 accepts 1–3 with migration.

═══════════════════════════════════════════════════════════════
CHARACTERS (NOTABLE)
═══════════════════════════════════════════════════════════════
Han-ul          Grade 1 Hana Association (Northern Branch). Stern, composed, professionally
                blunt. Treats most lower-grade Fixers as temporary and replaceable. Speaks
                with cold certainty; does not soften bad news.
Zevelyn         Eden Office Fixer (self-insert OC). Calm, unhurried, rarely ruffled. Speaks
                plainly and does not dramatize ordinary danger.
Arnold          Brotherhood of Iron leader. Second-wave boss after Mo + Consta.
Fairy Festival  ZAYIN abnormality (F-04-83). Solo examination enemy.

═══════════════════════════════════════════════════════════════
ASSETS
═══════════════════════════════════════════════════════════════
Core backgrounds present: menu, city, apt, school, nest, out, outplace, market,
nest-checkpoint, junction, brotherhood-of-iron, hook-office, hana-association.

Sprites present: pete, rat_a, rat_b, mo, consta, naoki, taein, mccullin, yun, finn,
eri, arnold, han-ul, zevelyn.

Still optional / missing (game falls back gracefully):
  assets/bg/office.webp
  assets/bg/workshop.webp

Abnormality art: assets/abnormalities/fairy-festival.webp

═══════════════════════════════════════════════════════════════
KNOWN LIMITATIONS / NOTES FOR FUTURE UPDATES
═══════════════════════════════════════════════════════════════
• Full interactive browser + phone playtesting is still the primary remaining verification.
• Urban Myth currently ends after the Fairy Festival exam; Grade 8 is the promotion gate,
  but later Urban Myth chapters are not yet written.
• Placeholder folders exist for later story arcs (Urban Legend → Impuritas Civitatis) and
  for Associations / Fingers / Wings. They are scaffolding only.
• Skip button advances all non-choice dialogue until the next choice or a system key that
  requires user action (battle, resumeWave, missionEnd, etc.).
• Brotherhood of Iron uses a multi-wave fight (Mo+Consta → Arnold interlude → Arnold).
  The interlude → second-wave transition must remain robust across saves and skip.

═══════════════════════════════════════════════════════════════
DEVELOPMENT CHECKS
═══════════════════════════════════════════════════════════════
From project root:
  node tests/smoke-check.js
  node tests/story-canon-check.js

These catch syntax, missing references, canon rules, and selected mechanics.
They do not replace real playtesting.

═══════════════════════════════════════════════════════════════
CHANGE LOG (high level)
═══════════════════════════════════════════════════════════════
2026-10-26  Consolidated all root documentation into this single README.
            Fixed Brotherhood second-wave dialogue stuck state.
            Reworked encounter framing (who finds whom).
            Expanded dialogue personality and length; skip stops only at choices / system keys.
            Grade 8 promotion after Canard offices; Fixer board panels for Canard / Urban Myth.
            Han-ul and Zevelyn (Eden Office) dialogue and titles aligned to intended personalities.
            office.webp / workshop.webp remain optional missing backgrounds.
